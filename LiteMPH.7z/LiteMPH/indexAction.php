<?php
	/*
	
	session_start();
	
	$_SESSION['sReelMFGPN'] = trim($_POST['ReelMFGPN']) ;
	// $_SESSION['sReelDateCode'] = trim($_POST['ReelDateCode']) ;
	
	// $_SESSION['sReelLotSize'] = trim($_POST['ReelLotSize']) ;
	$_SESSION['sREEQty'] = trim($_POST['txtReelQty']) ;
	$_SESSION['sDisPRINT'] = trim($_POST['DisablePrint']) ;	
	$_SESSION['iSELECTEDPRINTERORDER'] = trim($_POST['opPrinterSelect']);
	
	if ($_SESSION['iDEPTROLE'] == "INCOMMING"){
		$_SESSION['sNUMOFLABEL'] = trim($_POST['txtNUMOFLABEL']) ;	
		$_SESSION['sReelDLVNPN'] = trim($_POST['txtDLVNPN']) ;
		$_SESSION['iINSLOTNUMBER'] = trim($_POST['txtINSLOTNUMBER']) ;
		
		
		// $_SESSION['iCKNEWDLVNPN'] = trim($_POST['CKNEWDLVNPN']);
		// $_SESSION['iCKNEWMANUPN'] = trim($_POST['CKNEWMANUPN']);
	}
	else{		
		
		$_SESSION['sNUMOFLABEL'] = 1;	
		$_SESSION['iREELID'] = trim($_POST['txtREELID']) ;
		
		if ($_SESSION['iPREVREELID'] != $_SESSION['iREELID'])
		{
			$_SESSION['iACTIVEDLVNPNSCAN'] = "NO";
		}	
		
		$_SESSION['iINSLOTNUMBER'] = "NA" ;
		$_SESSION['iCKNEWDLVNPN'] = "";
		$_SESSION['iCKNEWMANUPN'] = "";
		if ($_SESSION['iACTIVEDLVNPNSCAN'] == "YES"){
			$_SESSION['sReelDLVNPN'] = trim($_POST['txtDLVNPN']) ;
		}
	}
	
	// $_SESSION['iREELPICcode'] = trim($_POST['txtPICCODE']) ;	
	$_SESSION['sWARNING']= 0 ;	
	$_SESSION['MAINPAGESUBMIT']  =  $_POST['ReelIDSetup'];
	
	if ($_SESSION['iDEPTROLE'] == "INCOMMING"){
		$_SESSION['PRINTERSELECTED']  =  "INCOM PRINTER"; //trim($_POST['ckFULLDECLARATION']);
	}
	else{
		$_SESSION['PRINTERSELECTED']  =  "SMT PRINTER";
	}
	
	if (strlen($_SESSION['iREELPICcode']) == 0) {
		$_SESSION['sWARNING'] = 9;		
		header ("Location: SCTmsSQL_ReelIDSetUp.php");
		exit();
	}
	
	$_SESSION['IsPICcodeExisting'] = "NO";
	require_once("SCTmsSQL_isPICcodeExisting.php");
	if ($_SESSION['IsPICcodeExisting'] == "NO"){
		$_SESSION['sWARNING'] = 99;		
		header ("Location: SCTmsSQL_ReelIDSetUp.php");
	exit();
	}	
	
	
	If (( $_SESSION['MAINPAGESUBMIT']  == "Print Reel-ID Label") OR ($_SESSION['iCKNEWDLVNPN'] == "NEW DLVNPN") OR ($_SESSION['iCKNEWMANUPN'] == "NEW MANUPN")){		
		if (($_SESSION['sReelMFGPN'] == "Choose MANUpn.") AND ($_SESSION['iCKNEWMANUPN'] == "NEW MANUPN")){		
			$_SESSION['sReelMFGPN'] = "" ;//"ENTER NEW MANUPN";
		}
		
		if (($_SESSION['iDEPTROLE'] != "INCOMMING") AND ($_SESSION['iACTIVEDLVNPNSCAN'] == "NO")){
			$getReelStart = substr($_SESSION['iREELID'],0,4);
			// if (strlen($_SESSION['iREELID']) < 12) {
			if ($getReelStart != "GREL") {
				$_SESSION['sWARNING'] = 1;		
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}
			$_SESSION['sReelDLVNPN'] = 0;			
			require_once("SCTmsSQL_IsREELIDSetupExisting.php");
			$_SESSION['iPREVREELID'] = $_SESSION['iREELID'];
			
			
			$getReelID = substr($_SESSION['iREELID'],0,12);
			if (strlen($_SESSION['iREELID']) == 12) {
				$getAcc = 1;
			}
			else{
				$getAcc = (int)substr($_SESSION['iREELID'],13,1) + 1 ;
			}
			$_SESSION['iNextREELID'] = $getReelID . "_" . $getAcc;
			$_SESSION['IsNextREELIDExisting'] = "NO";
			require_once("SCTmsSQL_IsNextREELIDSetupExisting.php");
			if ($_SESSION['IsNextREELIDExisting'] == "YES"){
				$_SESSION['sWARNING'] = 111;		
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}

			
		}		
		else{
			if (strlen($_SESSION['sReelDLVNPN']) == 0) {
				$_SESSION['sWARNING'] = 1;		
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}
		}
		
		
		$_SESSION['iSTRBIN'] = "NA";
		$_SESSION['IsDLVNpnExisting'] = "NO";
		require_once("SCTmsSQL_AccessMaterialsStorageBin.php");
		if ($_SESSION['iSTRBIN'] == "NA"){
			$_SESSION['IsDLVNpnExisting'] = "NO";
			// if ($_SESSION['iCKNEWDLVNPN'] != "NEW DLVNPN"){
				$_SESSION['sWARNING'] = 11;		
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			// }
		}
		
		IF ($_SESSION['iFULLDECLARATION'] != "FULL DECLARATION") {
			$numreelQty=(int)$_SESSION['sREEQty'] ;
			if ($numreelQty == 0) {
				$_SESSION['sWARNING'] = 5;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}
			
			if ($numreelQty > 30000) {
				$_SESSION['sWARNING'] = 55;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}
		}		
		ELSE{
			// $_SESSION['IsDLVNpnExisting'] = "NO";
			// require_once("SCTmsSQL_IsDLVNpnExisting.php");
					
			if ((strlen($_SESSION['sReelMFGPN']) == 0) OR ($_SESSION['sReelMFGPN'] == "ENTER NEW MANUPN") OR ($_SESSION['sReelMFGPN'] == "Choose MANUpn.")){		
				$_SESSION['sWARNING'] = 2;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}
			$_SESSION['IsMANUpnExisting'] = "NO";
			require_once("SCTmsSQL_IsMANUpnExisting.php");
			if ($_SESSION['IsMANUpnExisting'] == "NO"){
				if ($_SESSION['iCKNEWMANUPN'] != "NEW MANUPN"){
					$_SESSION['sWARNING'] = 22;		
					header ("Location: SCTmsSQL_ReelIDSetUp.php");
					exit();
				}
			}	
				
			if (strlen($_SESSION['iINSLOTNUMBER']) == 0){
				$_SESSION['sWARNING'] = 4;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}	
			
			$numreelQty=(int)$_SESSION['sREEQty'] ;
			if ($numreelQty == 0) {
				$_SESSION['sWARNING'] = 5;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}
			
			if ($numreelQty > 30000) {
				$_SESSION['sWARNING'] = 55;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}

			$_SESSION['IsIncommingPairPartNumberExisting'] = "NO";		
			require_once("SCTmsSQL_IsIncommingPairPartNumberExisting.php");
			if (($_SESSION['iCKNEWDLVNPN'] == "NO") AND ($_SESSION['iCKNEWMANUPN'] == "NO")){		
				if ($_SESSION['IsIncommingPairPartNumberExisting'] == "NO"){
					$_SESSION['sWARNING'] = 222;		
					header ("Location: SCTmsSQL_ReelIDSetUp.php");
					exit();
				}		
			}
			else{		
				if (($_SESSION['sReelMFGPN'] != "ENTER NEW MANUPN") AND ($_SESSION['sReelMFGPN'] != "Choose MANUpn.")){
					if ($_SESSION['IsIncommingPairPartNumberExisting'] == "NO"){
						$myServer = $_SESSION['ServerInstanceName'];
						$myUser = $_SESSION['ServerUserName'];
						$myPass = $_SESSION['ServerPassword'];
						$myDB = $_SESSION['ServerDB'];
						$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
						//connection to the database
						$dbHandleNewIncommingPackage = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
										or die("Couldn't connect to SQL Server on $myServer");

						//declare the SQL statement that will query the database
						//insert into empty database with new information of REEL COMPONENT;
						$queryNewIncommingPackage = "INSERT INTO IncommingPackageMatrix(PackageDLVNpn,PackageMANUpn,PackageQty) VALUES (" 
										. "'" . $_SESSION['sReelDLVNPN'] . "', "
										. "'" . $_SESSION['sReelMFGPN'] . "', "
										. "'" . $_SESSION['sREEQty'] . "')";
										
						//execute the SQL query and return records
						sqlsrv_query($dbHandleNewIncommingPackage,$queryNewIncommingPackage);		
						//===============================================================
						//===============================================================
						sqlsrv_close($dbHandleNewIncommingPackage);
						//$_SESSION['iQUERRY'] = $queryNewIncommingPackage;
					}
				}
				else{			
					$_SESSION['sWARNING'] = 22;
					header ("Location: SCTmsSQL_ReelIDSetUp.php");
					exit();
				}
			}

			if ($_SESSION['iINSLOTNUMBER'] == "N/A"){		
				$_SESSION['sWARNING'] = 6;
				header ("Location: SCTmsSQL_ReelIDSetUp.php");
				exit();
			}

			//===============================================================
			//===============================================================
			//		UPDATE DATABASE HERE FOR REEL ID LABEL PRINTING	
			//===============================================================
			//=========Get the Reel ID Label=================================
			if ($_SESSION['sNUMOFLABEL'] == 0){
				$_SESSION['sNUMOFLABEL'] = 1;
			}
		}
		
		if ($_SESSION['sNUMOFLABEL'] > 200) {
			$_SESSION['sWARNING'] = 66;
			header ("Location: SCTmsSQL_ReelIDSetUp.php");
			exit();
		}
		
		$_SESSION['iMSL'] = 0;
		$_SESSION['iFL'] = 0;
		require_once("SCTmsSQL_AccessMaterialsMSLnFL.php");
		
		if ($_SESSION['iDEPTROLE'] == "INCOMMING"){
			if (($_SESSION['iREELPICcode'] == "20110345") OR ($_SESSION['iREELPICcode'] == "2011X0542") OR ($_SESSION['iREELPICcode'] == "2012X0715") OR ($_SESSION['iREELPICcode'] == "2015X0886")) {
				require_once("SCTmsSQL_AccessInspectionLotNumberAndManuPN.php");
			}
		}
		else{
			require_once("SCTmsSQL_AccessInspectionLotNumberAndManuPN.php");
		}
		
		
		$myServer = $_SESSION['ServerInstanceName'];
		$myUser = $_SESSION['ServerUserName'];
		$myPass = $_SESSION['ServerPassword'];
		$myDB = $_SESSION['ServerDB'];
		$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
		//connection to the database
		$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
						or die("Couldn't connect to SQL Server on $myServer");

		//declare the SQL statement that will query the database
		//at first; delete the current database if any
		if ($_SESSION['iDEPTROLE'] == "INCOMMING"){
			if (($_SESSION['iREELPICcode'] == "20110345") OR ($_SESSION['iREELPICcode'] == "2011X0542") OR ($_SESSION['iREELPICcode'] == "2012X0715") OR ($_SESSION['iREELPICcode'] == "2015X0886")) {
				$queryDEL = "DELETE PreAssyComponentsTracking_Assign WHERE Sector = '" . "SMT PRINTER" . "' AND "
								. "SectorPrinterOrder = '" . "2ND PRINTER" . "'";
			}
			else{
				$queryDEL = "DELETE PreAssyComponentsTracking_Assign WHERE Sector = '" . $_SESSION['PRINTERSELECTED'] . "'";
			}
		}
		else{
			$queryDEL = "DELETE PreAssyComponentsTracking_Assign WHERE Sector = '" . $_SESSION['PRINTERSELECTED'] . "' AND "
							. "SectorPrinterOrder = '" . $_SESSION['iSELECTEDPRINTERORDER'] . "'";	
		}
		sqlsrv_query($dbhandle,$queryDEL);
		
		$getNumOfLabel = $_SESSION['sNUMOFLABEL'];
		While($getNumOfLabel >= 1){
			$getNumOfLabel = $getNumOfLabel -1;
			
			$getReelID = "";
			if ($_SESSION['iDEPTROLE'] == "INCOMMING"){
				require("SCTmsSQL_GetReelID.php");		// Server will control to create the ReelID and the program access to get that ReelID
				$getReelID = $_SESSION['REELID'] ;	
			}
			else{
				$getReelID = substr($_SESSION['iREELID'],0,12);
				if (strlen($_SESSION['iREELID']) == 12) {
					$getAcc = 1;
				}
				else{
					$getAcc = (int)substr($_SESSION['iREELID'],13,1) + 1 ;
				}
				$getReelID = $getReelID . "_" . $getAcc;
			}
			
			//declare the SQL statement that will query the database
			//at first; delete the current database if any
			//then; insert into empty database with new information of REEL COMPONENT;
			if (($_SESSION['iREELPICcode'] == "20110345") OR ($_SESSION['iREELPICcode'] == "2011X0542") OR ($_SESSION['iREELPICcode'] == "2012X0715") OR ($_SESSION['iREELPICcode'] == "2015X0886")) {
				$query = " INSERT INTO PreAssyComponentsTracking_Assign(ReelID,ReelDLVNpn,ReelMANUpn,ReelInspectionLotNumber,ReelQty,Sector,SectorPrinterOrder,PICcode,MoistureSensitiveLevel,FloorLifeHour,InventoryLocation) VALUES (" 
								. "'" . $getReelID . "', "
								. "'" . $_SESSION['sReelDLVNPN'] . "', "
								. "'" . $_SESSION['sReelMFGPN'] . "', "
								. "'" . $_SESSION['iINSLOTNUMBER'] . "', "
								. "'" . $_SESSION['sREEQty'] . "', "
								. "'" . "SMT PRINTER" . "', "
								. "'" . "2ND PRINTER" . "', "
								. "'" . $_SESSION['iREELPICcode'] . "', "
								. "'" . $_SESSION['iMSL'] . "', "
								. "'" . $_SESSION['iFL'] . "', "
								. "'" . $_SESSION['iSTRBIN'] . "')";
			}
			else{
				IF ($_SESSION['iFULLDECLARATION'] == "FULL DECLARATION") {
					$query = " INSERT INTO PreAssyComponentsTracking_Assign(ReelID,ReelDLVNpn,ReelMANUpn,ReelInspectionLotNumber,ReelQty,Sector,PICcode,MoistureSensitiveLevel,FloorLifeHour,InventoryLocation) VALUES (" 
								. "'" . $getReelID . "', "
								. "'" . $_SESSION['sReelDLVNPN'] . "', "
								. "'" . $_SESSION['sReelMFGPN'] . "', "
								. "'" . $_SESSION['iINSLOTNUMBER'] . "', "
								. "'" . $_SESSION['sREEQty'] . "', "
								. "'" . $_SESSION['PRINTERSELECTED'] . "', "
								. "'" . $_SESSION['iREELPICcode'] . "', "
								. "'" . $_SESSION['iMSL'] . "', "
								. "'" . $_SESSION['iFL'] . "', "
								. "'" . $_SESSION['iSTRBIN'] . "')";
				}
				else{
					// $_SESSION['iSELECTEDPRINTERORDER'];
					$query = " INSERT INTO PreAssyComponentsTracking_Assign(ReelID,ReelDLVNpn,ReelMANUpn,ReelInspectionLotNumber,ReelQty,Sector,SectorPrinterOrder,PICcode,MoistureSensitiveLevel,FloorLifeHour,InventoryLocation) VALUES (" 
								. "'" . $getReelID . "', "
								. "'" . $_SESSION['sReelDLVNPN'] . "', "
								. "'" . $_SESSION['sReelMFGPN'] . "', "
								. "'" . $_SESSION['iINSLOTNUMBER'] . "', "
								. "'" . $_SESSION['sREEQty'] . "', "
								. "'" . $_SESSION['PRINTERSELECTED'] . "', "
								. "'" . $_SESSION['iSELECTEDPRINTERORDER'] . "', "
								. "'" . $_SESSION['iREELPICcode'] . "', "
								. "'" . $_SESSION['iMSL'] . "', "
								. "'" . $_SESSION['iFL'] . "', "
								. "'" . $_SESSION['iSTRBIN'] . "')";
				}
			}
			$_SESSION['iQUERRY'] = $query;
			//execute the SQL query and return records
			sqlsrv_query($dbhandle,$query);	

			if ($_SESSION['iMSL'] > 0){
				if (($_SESSION['iREELPICcode'] == "20110345") OR ($_SESSION['iREELPICcode'] == "2011X0542") OR ($_SESSION['iREELPICcode'] == "2012X0715") OR ($_SESSION['iREELPICcode'] == "2015X0886")) {
					$query = " INSERT INTO PreAssyComponentsTracking_Assign(ReelID,ReelDup,ReelDLVNpn,ReelMANUpn,ReelInspectionLotNumber,ReelQty,Sector,SectorPrinterOrder,PICcode,MoistureSensitiveLevel,FloorLifeHour,InventoryLocation) VALUES (" 
									. "'" . $getReelID . "', "
									. "'" . "2" . "', "
									. "'" . $_SESSION['sReelDLVNPN'] . "', "
									. "'" . $_SESSION['sReelMFGPN'] . "', "
									. "'" . $_SESSION['iINSLOTNUMBER'] . "', "
									. "'" . $_SESSION['sREEQty'] . "', "
									. "'" . "SMT PRINTER" . "', "
									. "'" . "2ND PRINTER" . "', "
									. "'" . $_SESSION['iREELPICcode'] . "', "
									. "'" . $_SESSION['iMSL'] . "', "
									. "'" . $_SESSION['iFL'] . "', "
									. "'" . $_SESSION['iSTRBIN'] . "')";
				}
				else{
					IF ($_SESSION['iFULLDECLARATION'] == "FULL DECLARATION") {
						$query = " INSERT INTO PreAssyComponentsTracking_Assign(ReelID,ReelDup,ReelDLVNpn,ReelMANUpn,ReelInspectionLotNumber,ReelQty,Sector,PICcode,MoistureSensitiveLevel,FloorLifeHour,InventoryLocation) VALUES (" 
									. "'" . $getReelID . "', "
									. "'" . "2" . "', "
									. "'" . $_SESSION['sReelDLVNPN'] . "', "
									. "'" . $_SESSION['sReelMFGPN'] . "', "
									. "'" . $_SESSION['iINSLOTNUMBER'] . "', "
									. "'" . $_SESSION['sREEQty'] . "', "
									. "'" . $_SESSION['PRINTERSELECTED'] . "', "
									. "'" . $_SESSION['iREELPICcode'] . "', "
									. "'" . $_SESSION['iMSL'] . "', "
									. "'" . $_SESSION['iFL'] . "', "
									. "'" . $_SESSION['iSTRBIN'] . "')";
					}
					else{
						// $_SESSION['iSELECTEDPRINTERORDER'];
						$query = " INSERT INTO PreAssyComponentsTracking_Assign(ReelID,ReelDup,ReelDLVNpn,ReelMANUpn,ReelInspectionLotNumber,ReelQty,Sector,SectorPrinterOrder,PICcode,MoistureSensitiveLevel,FloorLifeHour,InventoryLocation) VALUES (" 
									. "'" . $getReelID . "', "
									. "'" . "2" . "', "
									. "'" . $_SESSION['sReelDLVNPN'] . "', "
									. "'" . $_SESSION['sReelMFGPN'] . "', "
									. "'" . $_SESSION['iINSLOTNUMBER'] . "', "
									. "'" . $_SESSION['sREEQty'] . "', "
									. "'" . $_SESSION['PRINTERSELECTED'] . "', "
									. "'" . $_SESSION['iSELECTEDPRINTERORDER'] . "', "
									. "'" . $_SESSION['iREELPICcode'] . "', "
									. "'" . $_SESSION['iMSL'] . "', "
									. "'" . $_SESSION['iFL'] . "', "
									. "'" . $_SESSION['iSTRBIN'] . "')";
					}
				}
				$_SESSION['iQUERRY'] = $query;
				//execute the SQL query and return records
				sqlsrv_query($dbhandle,$query);	
			}
			//$_SESSION['iQUERRY'] = $query;
			//===============================================================
			//===============================================================
		}
		sqlsrv_close($dbhandle);
		
		
		$_SESSION['prevREELID'] = $_SESSION['REELID']  ;
		$_SESSION['prevReelDLVNPN'] = $_SESSION['sReelDLVNPN'] ;
		$_SESSION['prevReelMFGPN'] = $_SESSION['sReelMFGPN'] ;				
		
		// $_SESSION['prevReelDateCode'] = $_SESSION['sReelDateCode'] ;
		// $_SESSION['prevReelLotSize'] = $_SESSION['sReelLotSize'] ;
		$_SESSION['prevINSLOTNUMBER'] = $_SESSION['iINSLOTNUMBER'] ;
		
		$_SESSION['prevREEQty'] = $_SESSION['sREEQty'] ;
		$_SESSION['prevDisPRINT'] = $_SESSION['DisPRINT'] ;
		$_SESSION['iCKNEWDLVNPN'] = "NEW DLVNPN";
		$_SESSION['iCKNEWMANUPN'] = "NEW MANUPN";
		
		$_SESSION['iREELID'] = "" ;
		$_SESSION['iINSLOTNUMBER'] = "" ;
		
		$_SESSION['sReelDLVNPN'] = "" ;
		$_SESSION['sReelMFGPN'] = "" ;				
		
		$_SESSION['sReelDateCode'] = "" ;
		$_SESSION['sReelLotSize'] = "" ;
		$_SESSION['sREEQty'] = "" ;
		$_SESSION['DisPRINT'] = "" ;
		$_SESSION['iACTIVEDLVNPNSCAN'] = "NO";
		header ("Location: SCTmsSQL_ReelIDSetUp.php");
	}
	else{
		$_SESSION['iREELID'] = "";
		$_SESSION['iREELIDDelWar']= 0 ;
		$_SESSION['iQUERY'] = "";
		header ("Location: SCTmsSQL_ReelIDDelete.php");
	}
	*/
?>