<?php
	session_start();	
	$_SESSION['pcbModelAssign'] = trim($_POST['pcbModelAssign']); 
	$_SESSION['LineSMTAssign'] = trim($_POST['SMTLineAssign']);
	$_SESSION['PRORDERAssign'] = trim($_POST['txtPOAssign']);
	$_SESSION['SUBMITAssign']  =  $_POST['ComponentSetupAssign'];
	$_SESSION['PCBReelIDAssignWARNING']= 0 ;
	$_SESSION['SNWARNING']  = 0 ;
	
	$_SESSION['ShortageSiplace'] = "";
	$_SESSION['ShortageTrackDiv'] = "";
	
	if (substr(trim($_SESSION['LineSMTAssign']),0,6) == 'Choose') {	
		$_SESSION['PCBReelIDAssignWARNING'] = 1 ;
		header ("Location: SCTmsSQL_AssignPCBTopModel.php");
		exit();
	}	
		
	if (substr(trim($_SESSION['pcbModelAssign']),0,6) == 'Choose') {
		$_SESSION['PCBReelIDAssignWARNING'] = 2 ;
		header ("Location: SCTmsSQL_AssignPCBTopModel.php");
		exit();
	}
	
	If ( $_SESSION['SUBMITAssign']  == "GO TO PCB SERIAL PANEL ASSIGN" ){
		if (strlen($_SESSION['PRORDERAssign']) < 9) {
			$_SESSION['PCBReelIDAssignWARNING'] = 3 ;
			header ("Location: SCTmsSQL_AssignPCBTopModel.php");
			exit();
		}
		//====================================================
		//first step, check the correct FULL SET UP
		require_once("SCTmsSQL_CheckFullSetUp.php");
		// $_SESSION['FULLSETUP']  = '1';
		if ($_SESSION['FULLSETUP']  == '0') {
			header ("Location: SCTmsSQL_AssignPCBTopModel.php");
			exit();
		}
		
		require_once("SCTmsSQL_ActiveDEMOmode.php");
		
		$_SESSION['pcbTB'] = "";

		$_SESSION['SNvsMODELWar'] = "" ;
		$_SESSION['SNvsSIDEWar'] = "" ;
		$_SESSION['SNWARNING']="";
		
		require_once("SCTmsSQL_DeleteOldPCBSerial.php");
		$_SESSION['STEP'] = 0;
		$_SESSION['MAXSTEP'] = 0;
		
		$_SESSION['iQUERY'] = "";
		$_SESSION['iQUERYII'] = "NA";
		$_SESSION['FULLQTYSETUP'] = "NO";
		$_SESSION['NewReelQtyMatrix'] = 0;
		$_SESSION['ReelIDMatrix'] = "";
		$_SESSION['ShortageSiplace'] = "NA";
		$_SESSION['ShortageTrackDiv'] = "NA";
		header ("Location: SCTmsSQL_AssignPCBSerialPanel.php");
	}
	elseif( $_SESSION['SUBMITAssign']  == "VIEW THE SET-UP TABLE" ){
		$_SESSION['QTYusedSIDE']= 0 ;
		$_SESSION['QTYusedSIDE'] = (int)$getSetUpQty ;
		$_SESSION['TOPQTYusedSIDE']= (int)$getSetUpQty ;
		$_SESSION['BOTQTYusedSIDE']= (int)$getSetUpQty ;
		header ("Location: SCTmsSQL_SetupResult.php");
	}
	elseif( $_SESSION['SUBMITAssign']  == "RESET ALL LOCATION VS MODEL" ){
		$_SESSION['QTYusedSIDE']= 0 ;
		$_SESSION['QTYusedSIDE'] = (int)$getSetUpQty ;
		$_SESSION['TOPQTYusedSIDE']= (int)$getSetUpQty ;
		$_SESSION['BOTQTYusedSIDE']= (int)$getSetUpQty ;
		require_once("SCTmsSQL_ResetAllLocationsOfModelonLine.php");
		header ("Location: SCTmsSQL_SetupResult.php");
	}

?>