<?php
	@session_start();
	
	// POST	localhost:8081/api/Conveyor/Connect_PLC_Default
	if (isset($_SESSION['iCOUNTERSTATUS'])){
		if ($_SESSION['iCOUNTERSTATUS'] == 0){
			$_SESSION['iCOUNTERSTATUS'] = 1;
		}
		else{	
			$_SESSION['iCOUNTERSTATUS'] = 0;			
		}
		
	}
	else{
		$_SESSION['iCOUNTERSTATUS'] = 0;
	}
	
	$_SESSION['iIODATA'] = "DO0=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO1=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO2=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO3=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO4=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO5=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO6=" . $_SESSION['iCOUNTERSTATUS'];
	// $_SESSION['iIODATA'] = "DO0=" . $_SESSION['iCOUNTERSTATUS'] . "&" . "DO1=" . $_SESSION['iCOUNTERSTATUS'];
	echo $_SESSION['iIODATA'];
	echo "</br>";
	
	// ***********************************************************************
	// ***********************************************************************
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'http://192.168.1.10/digitaloutput/all/value',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'POST',
	  // CURLOPT_POSTFIELDS =>'DO0=1&DO01=1&DO2=1&DO3=1&DO4=1&DO5=1&DO6=1',
	  CURLOPT_POSTFIELDS => $_SESSION['iIODATA'],
	  CURLOPT_HTTPHEADER => array(
		'Authorization: Basic cm9vdDowMDAwMDAwMA==',
		'Content-Type: text/plain'
	  ),
	));

	$response = curl_exec($curl);

	curl_close($curl);
	echo $response;
	
		
	
	/*
	// ***********************************************************************
	// ***********************************************************************
	$curl = curl_init();



	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'http://192.168.1.19/digitaloutput/all/value',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'GET',
	  CURLOPT_HTTPHEADER => array(
		'Authorization: Basic cm9vdDowMDAwMDAwMA=='
	  ),
	));

	$response = curl_exec($curl);

	
	if ($response === false) {
		$info = curl_getinfo($curl);
		curl_close($curl);
		
		die(var_export($info));
	}
	else{
		echo "</br>";
		echo "</br>";
		echo "Digtial Output:" . "OK GET Request!";
		echo "</br>";
		curl_close($curl);
	}

	echo $response;
	*/
	
	// ***********************************************************************
	// ***********************************************************************
	/*
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'http://192.168.1.19/counter/all/value',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'GET',
	  CURLOPT_HTTPHEADER => array(
		'Authorization: Basic cm9vdDowMDAwMDAwMA=='
	  ),
	));

	$response = curl_exec($curl);
	
	if ($response === false) {
		$info = curl_getinfo($curl);
		curl_close($curl);
		
		die(var_export($info));
	}
	else{
		echo "</br>";
		echo "</br>";
		echo "Counter Output:" . "OK GET Request!";
		echo "</br>";
		curl_close($curl);
	}

	echo "-** " . "Length of Reponse: " . strlen($response) . ": " . $response . "**-";
	*/
	
	// ***********************************************************************
	// ***********************************************************************
	/*
	$url = 'http://localhost:8081/api/Conveyor/Connect_PLC_Default_Reconnect';
	$curl = curl_init($url);
	
	$postData = array(
		'Comport' => 'COM4',
		'Connectiontimeout' => '3000'
	);
	
	// **************************************************************************
	// **************************************************************************	
	curl_setopt($curl, CURLOPT_POST, 1);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($postData));  ;
	curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type' => 'application/json',
		));
		
	
	$response = curl_exec($curl);
	
	if ($response === false) {
		$info = curl_getinfo($curl);
		curl_close($curl);
		
		die(var_export($info));
	}
	else{
		curl_close($curl);
	}
	
	// echo $response;
	// echo "</br>";
	
	$var = json_decode($response, TRUE);
	$status = ($var);
	
	if ($status == "Okay"){
		echo "Successfully connect to PLC!";
	}
	else{
		echo "Error";
	}
	*/
?>
