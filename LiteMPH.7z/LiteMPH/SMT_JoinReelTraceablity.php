<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
?>

<script type="text/javascript" src="/javaScripts/jquery-1.12.4.min.js">
	$(document).ready(function() {		
		$("#SMT_SetupSheetForm").on("submit", function () {

			$("#response").attr("class", "");
			$("#response").html("");
			var fileType = ".csv";
			var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
			if (!regex.test($("#file").val().toLowerCase())) {
					$("#response").addClass("error");
					$("#response").addClass("display-block");
				$("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
				return false;
			}
			return true;
		});
	});
	
	<style>
		table {
			border-collapse: collapse;
		}
		
		table {border: none;}
	</style>
</script>





<script>
	function GetUserInput(intWarning, strPartNumber, strLastSMTSetupSheet, strListOfPartLocation, cfgLanguage){
		if (intWarning == 0){
			document.getElementById("idSMTLOCATION").focus();
			document.getElementById("idSMTLOCATION").select();
		}
		
		if (intWarning == 6) {
			var locs = strListOfPartLocation.split("_");
			var strloc = "";
			var intloc = 0;
			for (ii = 0; ii < locs.length; ii++){
				intloc = intloc + 1;
				strloc = strloc + "\n" + intloc.toString() + ". " + locs[ii];
			}
			if (cfgLanguage == "English"){
				alert("The Potential SMT Locations are following: " + strloc);
			}
			else{
				alert("Linh Kiện Thuộc Các Vị Trí Sau Trong Setup Sheet: " + strloc);
			}
			
			document.getElementById("idSMTLOCATION").focus();
			document.getElementById("idSMTLOCATION").select();
		}
		
		if (intWarning == 9) {
			if (cfgLanguage == "English"){
				alert("The location of part number **" + strPartNumber + "** is not in the SMT setup sheet!");
			}
			else{
				alert("LỖI! Vị Trí Của Linh Kiện **" + strPartNumber + "** Không Nằm Trong Setup Sheet!");
			}
			document.getElementById("idSMTPARTNUMBER").focus();
			document.getElementById("idSMTPARTNUMBER").select();
		}
		
		if (intWarning == 7) {
			var locs = strListOfPartLocation.split("_");
			var strloc = "";
			var intloc = 0;
			for (ii = 0; ii < locs.length; ii++){
				intloc = intloc + 1;
				strloc = strloc + "\n" + intloc.toString() + ". " + locs[ii];
			}
			if (cfgLanguage == "English"){
				alert("The SMT Location is not in the last SMT Setup Sheet **" + strLastSMTSetupSheet + "**" +
						"\n\n" + "The Potential SMT Locations are following: " + strloc);
			}
			else{
				alert("LỖI! Vị Trí Linh Kiện Không Nằm Trong Setup Sheet **" + strLastSMTSetupSheet + "**!" +
						"\n\n" + "Vị Trí Linh Kiện Có Thể Là: " + strloc);
			}
			document.getElementById("idSMTLOCATION").focus();
			document.getElementById("idSMTLOCATION").select();
		}
		
		// if (intWarning == 10) {
			// alert("Sorry, the part nubmer and location was already in preparation!");
			// document.getElementById("idSMTLOCATION").focus();
			// document.getElementById("idSMTLOCATION").select();
		// }
		
		if (intWarning == 1) {
			document.getElementById("idSMTPARTNUMBER").focus();
			document.getElementById("idSMTPARTNUMBER").select();
		}
		
		if (intWarning == 2) {
			document.getElementById("idSMTPARTQTY").focus();
			document.getElementById("idSMTPARTQTY").select();
		}
		
		if (intWarning == 3) {
			document.getElementById("idSMTPARTQTY").focus();
			document.getElementById("idSMTPARTQTY").select();
		}
		
		if (intWarning == 4) {
			if (cfgLanguage == "English"){
				alert("The quantity is not allowed higher 500,000 pcs!");
			}
			else{
				alert("LỖI! Số Lượng Không Được Vượt Quá 500,000 pcs!");
			}
			document.getElementById("idSMTPARTQTY").focus();
			document.getElementById("idSMTPARTQTY").select();
		}
		
		if (intWarning == 5) {
			if (cfgLanguage == "English"){
				alert("The part number **" + strPartNumber + "** is not in the SMT setup sheet!");
			}
			else{
				alert("LỖI! Tên Linh Kiện **" + strPartNumber + "** Không Thuộc Về Setup Sheet!");
			}
			document.getElementById("idSMTPARTNUMBER").focus();
			document.getElementById("idSMTPARTNUMBER").select();
		}
		
	}
	
	function OnLoadFunction($cfgUserInputonLoad, $cfgPartNumber, $cfgLastSMTSetupSheet, $cfgListOfPartLocation, $cfgLanguage) {
		GetUserInput($cfgUserInputonLoad, $cfgPartNumber, $cfgLastSMTSetupSheet, $cfgListOfPartLocation, $cfgLanguage);		
	}
</script>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgPartNumber = (isset($_SESSION['iSMTPARTNUMBER']) ? $_SESSION['iSMTPARTNUMBER'] : 0);
	$cfgLastSMTSetupSheet = (isset($_SESSION['iLASTSMTSETUPSHEETLOG']) ? $_SESSION['iLASTSMTSETUPSHEETLOG'] : "???");
	$cfgListOfPartLocation = (isset($_SESSION['iLISTOFPARTLOCATION']) ? $_SESSION['iLISTOFPARTLOCATION'] : "");
	$cfgLanguage = $_SESSION['Language'];
?>

<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgPartNumber . "'"; ?>,<?php echo "'" . $cfgLastSMTSetupSheet . "'"; ?>,<?php echo "'" . $cfgListOfPartLocation . "'"; ?>,<?php echo "'" . $cfgLanguage . "'"; ?>)" >
	<div class="row content">
        <div class="col-md-3 sidenav">
			<?php 
				include("index.php");
			?> 
		</div>
		
		<div class="main col-md-9">
			<div>
				<div class="panel panel-success" style="margin-right: 10;">
					<div class="panel-heading" style="text-align: center; font-size: 29pt; clear:both;font-weight:bold">SMT PRODUCTION LOT SIZE PREPARATION MODULE</div>
				</div>
			</div>
			<div>
				<?php 
					echo "<h3>";
					echo "NEW SMT PROD LOT SIZE ID: " . $_SESSION['iSMTPRODLOTSIZEID'];
					echo "</br>";
					echo "Last SMT Setup Sheet: " . $_SESSION['iLASTSMTSETUPSHEETLOG'] . "(" . $_SESSION['IDSMTSetupSheetLog'] . ")";	
					echo "</h3>";
				?>
			</div>
			<div>
				<form name="SMT_JoinReelTraceablityForm" action="SMT_JoinReelTraceablityAction.php" style="display:inline; margin:0;" method="POST">
					<div class="row content">
						<div class="col-md-3" >						
							<?php 										
								echo "Status: " . $_SESSION['sWARNING'];
								echo "</br>";
								echo $_SESSION['iQUERRY'];
								// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
							?>
								<table class="beta1" style="width:360px;">
							<?php 	
								echo "</td></tr>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

								echo "<tr>";
								echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								echo "SMT PART NUMBER:";
								echo "</span><h4></td>";
								echo "<td>";
							?>
								<input type="text" name="txtSMTPARTNUMBER" id="idSMTPARTNUMBER" placeholder="123-45-678" value="<?= $_SESSION['iSMTPARTNUMBER'] ; ?>"  maxlength = "12" style="color:blue; font-size: 15pt;width:160px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
							<?php					
								echo "</td></tr>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

								echo "<tr>";
								echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								echo "SMT LOCATION:";
								echo "</span><h4></td>";
								echo "<td>";
							?>
								<input type="text" name="txtSMTLOCATION" id="idSMTLOCATION" placeholder="SMT Location" value="<?= $_SESSION['iSMTLOCATION'] ; ?>"  style="color:blue; font-size: 15pt;width:160px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
							<?php					
								echo "</td></tr>";
								echo "</br>";
								echo "</br>";
								echo "</br>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)
								echo "<tr>";
								echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								echo "SMT PART QTY:";
								echo "</span><h4></td>";
								echo "<td>";
								
							?>
								<input type="text" name="txtSMTPARTQTY" id="idSMTPARTQTY" placeholder="0" value="<?= $_SESSION['iSMTPARTQTY'] ; ?>"  maxlength = "9" style="color:red; font-size: 15pt;width:110px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
							<?php					
								echo " (pcs)";
								echo "</td></tr>";
								
							?>
								</table>
							<?php
								echo "Previous SMT Location - Part Number - Qty: " . $_SESSION['iPrevSMTLOCATION'] . " - " . $_SESSION['iPrevSMTPARTNUMBER'] . " - " . $_SESSION['iPrevSMTPARTQTY'] . "(pcs)";
							?>
								<table class="beta1">
								
							<?php
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "</br>";
								echo "</br>";
								echo "</br>";
								// echo $_SESSION['iQUERRY'];
								echo "<tr><td>";							
								
							?>			
								<input class="btn btn-outline" type="submit" name="ComponentTraceability" value="Record Component Traceability" style="color:blue; font-size: 12pt;width:360px; height:36px;float:center;clear:both;font-weight:bold;"/>
							<?php	
								echo "</td></tr>";
							?>
								</table>
								<table class="beta1">
								
							<?php
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "</br>";
								echo "</br>";
								echo "</br>";
								// echo $_SESSION['iQUERRY'];
								echo "<tr><td>";							
								
							?>			
								<input class="btn btn-outline" type="submit" name="ComponentTraceability" value="Reset Component Location" style="color:red; font-size: 12pt;width:360px; height:36px;float:center;clear:both;font-weight:bold;"/>
							<?php	
								echo "</td></tr>";
							?>
								</table>
						</div>
						
						<div class="col-md-9" style="padding-left:20px;">
							<div>
								<p>
								<?php 
									require_once("SMT_ShowProdLotSizeTraceabilityV2.php");	
									// require_once("SMT_ShowSMTSetupSheetLog.php"); 
								?>	
								</p>
							</div>							
						</div>
					</div>	
				</form>
			</div>
		</div>
    </div> 
<body>