<?php
	session_start();
	
	$_SESSION['iSMTPRODLOTSIZEID'] = trim($_POST['txtSMTPRODLOTSIZEID']);
	$_SESSION['iEXPORTPRODLOTSIZEDATA'] = trim($_POST['ExportProductionLotSizeData']);
			
	$_SESSION['sWARNING']= 0;	
	
	if (strlen($_SESSION['iSMTPRODLOTSIZEID']) < 6) {
		$_SESSION['sWARNING'] = 1;		
		header ("Location: SMT_ProdLotSizeDataExport.php");
		exit();
	}
	
	// if (substr($_SESSION['iSMTPRODLOTSIZEID'],0,7) != "SMTPLOT") {
		// $_SESSION['sWARNING'] = 2;		
		// header ("Location: SMT_ProdLotSizeDataExport.php");
		// exit();
	// }
	
	$_SESSION['IDSMTSetupSheetLog'] = 0;
	$_SESSION['SMTSetupSheetName'] = "None";
	$_SESSION['FOUNDVALUE'] = "NO";
	require_once("SMT__ProdLotSizeIDInPreparation.php");
	if ($_SESSION['FOUNDVALUE'] == "NO"){
		$_SESSION['sWARNING'] = 5;		
		header ("Location: SMT_ProdLotSizeDataExport.php");
		exit();
	}	
	
	if (($_SESSION['iEXPORTPRODLOTSIZEDATA'] == "Export *.csv Data") OR ($_SESSION['iEXPORTPRODLOTSIZEDATA'] == "Tải File Thông Tin Của Đơn Hàng (*.csv )")){
		$_SESSION['strTIMESTAMP'] = date("Ymd_his");
		$csvName = $_SESSION['iSMTPRODLOTSIZEID'] . "_Data" . $_SESSION['strTIMESTAMP'] . ".csv";
		$fp = fopen($csvName , 'w');
		
		// **********************************************************
		// **********************************************************
		// require_once("SMT_UpdateSMTMachineAndProdLotSize.php");
		$myServer = $_SESSION['ServerInstanceName'];
		$myUser = $_SESSION['ServerUserName'];
		$myPass = $_SESSION['ServerPassword'];
		$myDB = $_SESSION['ServerDB'];
		$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
		
		//connection to the database
		$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
							or die("Couldn't connect to SQL Server on $myServer");						
			
		$query = "SELECT ONE.[ProdLotSizeID],'(' + rtrim(ONE.[Location]) + ')' AS Location,ONE.[PartNumber],ONE.[PartOrgQty],CONVERT(char(19),ONE.[JoinReelTime],120) AS	JoinReelTime,ONE.[JoinReelPIC]"
					. ",THREE.[SMTSetupSheetName],TWO.[IDSMTSetupSheetLog]"
					. "	FROM [dbo].[SMTProdLotSizeJoinReel] AS ONE"
					. " LEFT OUTER JOIN [dbo].[SMTSetupSheetLogControl] AS TWO ON ONE.[IDSMTSetupSheetLog] = TWO.[IDSMTSetupSheetLog]"
					. " LEFT OUTER JOIN [dbo].[SMTSetupSheetMasterList] AS THREE ON TWO.[IDSMTSetupSheet] = THREE.[IDSMTSetupSheet]"
					. " WHERE ONE.[ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
				
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);	
		
		$returnedProdLotSizeID = "";
		while ($row = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC)) {
			if (!isset($headings))
			{
				$headings = array_keys($row);
				fputcsv($fp, $headings, ',', '"');
			}
			fputcsv($fp, $row, ',', '"');
		}
		
		
		// *****************************************************************************************************
		// *****************************************************************************************************
		$query = "SELECT [ProdLotSizeID],[ProdLotSizeQty],'(' + rtrim([Location]) + ')' AS Location,[PartNumber],[PartOrgQty],[IDSMTSetupSheetLog],[MachineName],[PickupQty],[IoTCounterQty],[PartConsumptionQty],[PartRemainQty],[AvailablePanelQty],[TotalPanelQty],[RateQtyStatus],[RateQtyWarning] FROM [dbo].[v_06_SMTProdLotSizeJoinReelStatusWarning] WHERE"
					. " [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
				
		// $_SESSION['iQUERRY'] = $query;
		// execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);	
		
		$returnedProdLotSizeID = "";
		unset($headings);
		fputcsv($fp,array());
		fputcsv($fp,array());
		fputcsv($fp,array());
		
		while ($row = sqlsrv_fetch_array($result,SQLSRV_FETCH_ASSOC)) {
			if (!isset($headings))
			{
				$headings = array_keys($row);
				fputcsv($fp, $headings, ',', '"');
			}
			fputcsv($fp, $row, ',', '"');
		}
		
		fclose($fp);
		
		sqlsrv_close($dbhandle);
		
		
		
		// *************************************************************
		// *************************************************************
		
		// $sqlQuery = 'select * from sqlserver_table';
		// $sqlRresult = odbc_exec($conMsSql, $sql);

		// $fp = fopen(csvName , 'w');

		// while ($export = odbc_fetch_array($sqlRresult)) {
			// if (!isset($headings))
			// {
				// $headings = array_keys($export);
				// fputcsv($fp, $headings, ',', '"');
			// }
			// fputcsv($fp, $export, ',', '"');
		// }
		// fclose($fp);
		$rootFolder = str_replace("\\","/",dirname(__FILE__));
		header('Content-type: plain/text');
		header("Content-Disposition: attachment; filename=\"$csvName\"");
		readfile($rootFolder . "/" . $csvName);
		// **********************************************************
		// **********************************************************
		// header ("Location: SMT_ProdLotSizeDataExport.php");
	}
	
?>