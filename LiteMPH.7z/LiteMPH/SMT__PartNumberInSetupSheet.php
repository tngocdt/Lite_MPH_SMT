<?php
	@session_start();
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//declare the SQL statement that will query the database
	$query = "SELECT TOP(1) * FROM [dbo].[SMTSetupSheetLayoutControl] WHERE"
				. " [IDSMTSetupSheetLog] = '" . $_SESSION['IDSMTSetupSheetLog'] . "'"
				. " AND [MachineMaterials] = '" . $_SESSION['iSMTPARTNUMBER'] . "'";

	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);
	//display the results
	
	$returnedFindingVal = "";
	$_SESSION['FOUNDVALUE'] = "NO";
	While($row = sqlsrv_fetch_array($result)){
		$returnedFindingVal = trim($row['MachinePosition']);
	}

	if ($returnedFindingVal == "") {
		$_SESSION['FOUNDVALUE'] = "NO";
	}
	else{
		$_SESSION['FOUNDVALUE'] = "YES";
		
		//declare the SQL statement that will query the database
		$query = "SELECT * FROM [dbo].[SMTSetupSheetLayoutControl] WHERE"
					. " [IDSMTSetupSheetLog] = '" . $_SESSION['IDSMTSetupSheetLog'] . "'"
					. " AND [MachineMaterials] = '" . $_SESSION['iSMTPARTNUMBER'] . "'"
					. " ORDER BY [MachinePosition]";

		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		//display the results
		
		$_SESSION['iLISTOFPARTLOCATION'] = "";
		While($row = sqlsrv_fetch_array($result)){
			$_SESSION['iLISTOFPARTLOCATION'] = $_SESSION['iLISTOFPARTLOCATION'] . "_" . trim($row['MachinePosition']);
		}
		
		if ($_SESSION['iLISTOFPARTLOCATION'] != ""){
			$_SESSION['iLISTOFPARTLOCATION'] = substr($_SESSION['iLISTOFPARTLOCATION'],1,strlen($_SESSION['iLISTOFPARTLOCATION'])-1);
		}
	}
	sqlsrv_close($dbhandle);		
?>
