<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
	if (isset($_REQUEST["q"])){
		$q = $_REQUEST["q"];
		$_SESSION['sWARNING'] = $q;
		$_SESSION['iSMTPRODLOTSIZEID'] = "";
		$_SESSION['iCOUNTERCONTROL'] = "***";
	}
?>

<script type="text/javascript" src="/javaScripts/jquery-1.12.4.min.js">
	$(document).ready(function() {		
		$("#SMT_SetupSheetForm").on("submit", function () {

			$("#response").attr("class", "");
			$("#response").html("");
			var fileType = ".csv";
			var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
			if (!regex.test($("#file").val().toLowerCase())) {
					$("#response").addClass("error");
					$("#response").addClass("display-block");
				$("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
				return false;
			}
			return true;
		});
	});
	
	<style>
		table {
			border-collapse: collapse;
		}
		
		table {border: none;}
	</style>
</script>





<script>
	function GetUserInput(intWarning, strPartNumber, strLastSMTSetupSheet, cfgLanguage){
		if (intWarning == 0){
			document.getElementById("idSMTPRODLOTSIZEID").focus();
			document.getElementById("idSMTPRODLOTSIZEID").select();
		}
		
		if (intWarning == 1) {
			if (cfgLanguage == "English"){
				alert("Please input the correct value of SMT Production Lot Size ID!");
			}
			else{
				alert("LỖI! Vui Lòng Nhập Vào Đúng Số Đơn Hàng Sản Xuất!");
			}
			
			document.getElementById("idSMTPRODLOTSIZEID").focus();
			document.getElementById("idSMTPRODLOTSIZEID").select();
		}
		
		if (intWarning == 2) {
			if (cfgLanguage == "English"){
				alert("Please input the correct value of SMT Production Lot Size ID!");
			}
			else{
				alert("LỖI! Vui Lòng Nhập Vào Đúng Số Đơn Hàng Sản Xuất!");
			}
			document.getElementById("idSMTPRODLOTSIZEID").focus();
			document.getElementById("idSMTPRODLOTSIZEID").select();
		}
		
		if (intWarning == 5) {
			if (cfgLanguage == "English"){
				alert("Sorry, the SMT Production Lot Size ID is not found!");
			}
			else{
				alert("LỖI! Không Tìm Thấy Số Đơn Hàng Sản Xuất Trong Hệ Thống!");
			}						
			document.getElementById("idSMTPRODLOTSIZEID").focus();
			document.getElementById("idSMTPRODLOTSIZEID").select();
		}

		if (intWarning == 7) {
			if (cfgLanguage == "English"){
				alert("Can not Start Running Lot Size Due To Some Locations Missing Preparation!");
			}
			else{
				alert("LỖI! Không Thể Bắt Đầu Vận Hành Đơn Hàng Sản Xuất Do Một Số Vị Trí Chưa Khai Báo Linh Kiện Cần Chuẩn Bị!");
			}
						
			document.getElementById("idSMTPRODLOTSIZEID").focus();
			document.getElementById("idSMTPRODLOTSIZEID").select();
		}
	}
	
	function OnLoadFunction($cfgUserInputonLoad, $cfgPartNumber, $cfgLastSMTSetupSheet, $cfgLanguage) {
		GetUserInput($cfgUserInputonLoad, $cfgPartNumber, $cfgLastSMTSetupSheet, $cfgLanguage);		
	}
</script>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgPartNumber = (isset($_SESSION['iSMTPRODLOTSIZEID']) ? $_SESSION['iSMTPRODLOTSIZEID'] : 0);
	$cfgLastSMTSetupSheet = (isset($_SESSION['iLASTSMTSETUPSHEETLOG']) ? $_SESSION['iLASTSMTSETUPSHEETLOG'] : "???");
	$cfgLanguage = $_SESSION['Language'];
?>

<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgPartNumber . "'"; ?>,<?php echo "'" . $cfgLastSMTSetupSheet . "'"; ?>,<?php echo "'" . $cfgLanguage . "'"; ?>)" >
	<div class="row content">
        <div class="col-md-3 sidenav">
			<?php 
				include("index.php");
			?> 
		</div>
		
		<div class="main col-md-9">
			<div>
				<div class="panel panel-success" style="margin-right: 10;">
					<div class="panel-heading" style="text-align: center; font-size: 29pt; clear:both;font-weight:bold">SMT PRODUCTION LOT SIZE RUNNING MODULE</div>
				</div>
			</div>
			<div>
				<form name="SMT_RunningProdLotSizeForm" action="SMT_RunningProdLotSizeAction.php" style="display:inline; margin:0;" method="POST">
					<div>
						<?php 
							echo "<h3>";
							// echo "NEW SMT PROD LOT SIZE ID: " . $_SESSION['SMTPRODLOTSIZE'];
							echo "</br>";
							// echo "Last SMT Setup Sheet: " . $_SESSION['iLASTSMTSETUPSHEETLOG'] . "(" . $_SESSION['IDSMTSetupSheetLog'] . ")";	
							echo "</h3>";
						?>
					</div>
					<div class="row content">
						<div class="col-md-6" >						
							<?php 										
								echo "Status: " . $_SESSION['sWARNING'];
								echo "</br>";
								// echo $_SESSION['iQUERRY'];
								// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
							?>
								<table class="beta1" style="width:490px;">
							<?php 	
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

								echo "<tr>";
								echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								if ($_SESSION['Language'] == "English"){
									echo "SMT PRODUCTION LOT SIZE:";
								}
								else{
									echo "MÃ SỐ ĐƠN HÀNG:";
								}
								echo "</span><h4></td>";
								echo "<td>";
							?>
								<input type="text" name="txtSMTPRODLOTSIZEID" id="idSMTPRODLOTSIZEID" placeholder="SMTPLOT***" value="<?= $_SESSION['iSMTPRODLOTSIZEID'] ; ?>"  style="color:blue; font-size: 15pt;width:190px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
							<?php					
								echo "</td></tr>";	
								
							?>
								</table>
								
								<table class="beta1">
								
							<?php
								echo "</br>";
								echo "</br>";
								echo "</br>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL								
								echo "</br>";
								// echo $_SESSION['iQUERRY'];
								echo "<tr><td>";							
								if ($_SESSION['Language'] == "English"){
							?>		
								<input class="btn btn-outline" type="submit" name="RunProductionLotSize" value="Start Running Lot Size" style="color:blue; font-size: 12pt;width:460px; height:36px;float:center;clear:both;font-weight:bold;"/>
							<?php
								}
								else{
							?>		
								<input class="btn btn-outline" type="submit" name="RunProductionLotSize" value="Bắt Đầu Vận Hành Truy Vết Đơn Hàng" style="color:blue; font-size: 12pt;width:460px; height:36px;float:center;clear:both;font-weight:bold;"/>
							<?php
								}
								echo "</td></tr>";
							?>
								</table>
								
								<table class="beta1">
							<?php
								echo "</br>";
								echo "</br>";
								echo "</br>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								// echo $_SESSION['iQUERRY'];
								echo "<tr><td>";							
								if ($_SESSION['Language'] == "English"){
							?>		
								<input class="btn btn-outline" type="submit" name="RunProductionLotSize" value="Join Reels Traceability" style="color:red; font-size: 12pt;width:460px; height:36px;float:center;clear:both;font-weight:bold;"/>
							<?php
								}
								else{
							?>		
								<input class="btn btn-outline" type="submit" name="RunProductionLotSize" value="Truy Vết Nối Reel Linh Kiện" style="color:red; font-size: 12pt;width:460px; height:36px;float:center;clear:both;font-weight:bold;"/>
							<?php
								}
								echo "</td></tr>";
							?>
								</table>
						</div>
						
						<div class="col-md-6" style="padding-left:20px;">
							<div>
								<p>
								<?php 
									// require_once("SMT_ShowProdLotSizeTraceability.php");	
									// require_once("SMT_ShowSMTSetupSheetLog.php"); 
								?>	
								</p>
							</div>							
						</div>
					</div>	
				</form>
			</div>
		</div>
    </div> 
<body>