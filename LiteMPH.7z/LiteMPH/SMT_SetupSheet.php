<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
	if (isset($_REQUEST["q"])){
		$q = $_REQUEST["q"];
		$_SESSION['sWARNING'] = $q;
		$_SESSION['SMTSetupSheetName'] = "***";
		$_SESSION['SMTSetupSheetLogName'] = "***";
		$_SESSION['IDSMTSETUPSHEET'] = 0;
		$_SESSION['IDSMTSetupSheetLog'] = 0;
	}
?>

<script type="text/javascript" src="/javaScripts/jquery-1.12.4.min.js">
	$(document).ready(function() {		
		$("#SMT_SetupSheetForm").on("submit", function () {

			$("#response").attr("class", "");
			$("#response").html("");
			var fileType = ".csv";
			var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
			if (!regex.test($("#file").val().toLowerCase())) {
					$("#response").addClass("error");
					$("#response").addClass("display-block");
				$("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
				return false;
			}
			return true;
		});
	});
</script>

<script language="JavaScript" type="text/javascript"> 
	function AutoSubmit(strSMTSetupSheetLogName){
		// ShowSMTSetupSheetName(strSMTSetupSheetLogName);
		document.SMT_SetupSheetForm.submit();
	} 
	// setInterval('AutoSubmit()', 5000); // refresh div after 5 secs
 </script>

<script>
	function ShowSMTSetupSheetName(strSMTSetupSheetLogName) {
		if (strSMTSetupSheetLogName.length==0) {
				document.getElementById("idSMTSetupSheetNameLog").innerHTML="";
				return;
		}
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("idSMTSetupSheetNameLog").innerHTML=xmlhttp.responseText;
				}
		}
		
		alert("The Setup Sheet **" + strSMTSetupSheetLogName + "** has been downloaded!");
		xmlhttp.open("GET","SMT_ShowSMTSetupSheetLog.php?q="+strSMTSetupSheetLogName,true);
		xmlhttp.send();
	}
</script>

<script>
	function AccessListSMTSetupSheetName(strSMTSetupSheetName) {
		if (strSMTSetupSheetName.length==0) {
				document.getElementById("idSMTSetupSheetName").innerHTML="";
				return;
		}
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("idSMTSetupSheetName").innerHTML=xmlhttp.responseText;
				}
		}
		xmlhttp.open("GET","SMT_AccessListSMTSheetSheetName.php?q="+strSMTSetupSheetName,true);
		xmlhttp.send();
	}
</script>



<script>
	function showUploadSetupSheet() {
		var varUploadSetupSheet = document.getElementById("idUploadSetupSheet");
		var varViewSetupSheet = document.getElementById("idViewSetupSheet");
		varUploadSetupSheet.style.display = "block";
		varViewSetupSheet.style.display = "none";
	}
	
	function showViewSetupSheet() {
		var varUploadSetupSheet = document.getElementById("idUploadSetupSheet");
		var varViewSetupSheet = document.getElementById("idViewSetupSheet");
		varUploadSetupSheet.style.display = "none";
		varViewSetupSheet.style.display = "block";
	}

</script>

<script>
	function GetUserInput(intWarning, cfgFileName, cfgSetupView, cfgLanguage) {	
		if (intWarning == 10) {
			if (cfgLanguage == "English"){
				alert("Sorry, length of filename is not allowed to over 60 characters!");
			}
			else{
				alert("Lỗi! Chiều Dài Tên File Setup Sheet Không Được Vượt Quá 60 Ký Tự!");
			}
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		// if (intWarning == 1) {
			// if (cfgLanguage == "English"){
				// alert("Sorry, file already exists!");
			// }
			// else{
				
			// }
			// document.getElementById("fileToUpload").focus();
			// document.getElementById("fileToUpload").select();
		// }
		
		if (intWarning == 2) {
			if (cfgLanguage == "English"){
				alert("Sorry, your file is too large - over 500KB!");
			}
			else{
				alert("Lỗi! Dung Lượng File Vượt Quá 500KB!");
			}
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 3) {
			if (cfgLanguage == "English"){
				alert("Sorry, there was an error uploading your file! Please select a file again!");
			}
			else{
				alert("LỖI! Chương Trình Không Cập Nhật Được Dữ Liệu Vào Hệ Thống - Vui Lòng Thử Lại!");
			}
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 99) {
			if (cfgLanguage == "English"){
				alert("The file **" + cfgFileName + "** has been uploaded!");
			}
			else{
				alert("OK! File **" + cfgFileName + "** Đã Được Cập Nhật Vào Hệ Thống!");
			}
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
	}
	
	function OnLoadFunction($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgSetupSheetName, $cfgLanguage) {
		var varUploadSetupSheet = document.getElementById("idUploadSetupSheet");
		var varViewSetupSheet = document.getElementById("idViewSetupSheet");
		
		if ($cfgSetupView == "Block"){			
			varUploadSetupSheet.style.display = "Block";
			varViewSetupSheet.style.display = "None";
		}
		else{
			varUploadSetupSheet.style.display = "None";
			varViewSetupSheet.style.display = "Block";
		}
		
		GetUserInput($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgLanguage);
		AccessListSMTSetupSheetName($cfgSetupSheetName);
		
	}
</script>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgFileName = (isset($_SESSION['FILENAME']) ? $_SESSION['FILENAME'] : "***");
	$cfgSetupView = (isset($_SESSION['SETUPSHEETUPLOADVIEW']) ? $_SESSION['SETUPSHEETUPLOADVIEW'] : "***");
	$cfgSetupSheetName = (isset($_SESSION['SMTSetupSheetName']) ? $_SESSION['SMTSetupSheetName'] : "Block");
	$cfgLanguage = $_SESSION['Language'];
?>

<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgFileName . "'"; ?>,<?php echo "'" . $cfgSetupView . "'"; ?>,<?php echo "'" . $cfgSetupSheetName . "'"; ?>,<?php echo "'" . $cfgLanguage . "'"; ?>)" >
	<div class="row content">
        <div class="col-md-3 sidenav">
			<?php 
				include("index.php");
			?> 
		</div>
		
		<div class="main col-md-9">
			<div>
				<div class="panel panel-success" style="margin-right: 10;">
					<div class="panel-heading" style="text-align: center; font-size: 29pt; clear:both;font-weight:bold">SMT SETUP SHEET CONTROL MODULE</div>
				</div>
			</div>
			<div>
				<form name="SMT_SetupSheetForm" action="SMT_SetupSheetAction.php" style="display: inline; margin: 0;" method="POST" enctype="multipart/form-data">
					<div class="row content">
						<div class="col-md-3" style="padding-top: 20px;">						
							<?php 		
								echo "Status: " . $_SESSION['sWARNING'];
								// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "<tr>";							
								echo "<td>";	
							
							?>			
								<?//============SET UP THE INPUT BOX HERE FOR SCANNING SMPN?>
								<input type="file" name="fileToUpload" id="fileToUpload" accept=".csv" style="font-size: 12pt;width:250px;">
							<?php	
								echo "</td></tr>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "<tr>";							
								echo "<td>";
								echo "</br>";
								if ($_SESSION['Language'] == "English"){
							?>
							
								<b><input class="btn btn-outline" type="submit" name="csvData" value="Upload Setup Sheet *.csv" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold" /></b>
								
							<?php
								}
								else{
							?>
							
								<b><input class="btn btn-outline" type="submit" name="csvData" value="Cập Nhật Setup Sheet *.csv" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold" /></b>
								
							<?php	
								}								
								echo "</td></tr>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								
								echo "<tr>";
								echo "<td>";							
								echo "</br>";
								echo "</br>";
								echo "</br>";
								echo "</br>";
								echo "</br>";
								if ($_SESSION['Language'] == "English"){
							?>			
								<b><input class="btn btn-outline" type="submit" name="csvData" value="View Last SetupSheet" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;"/></b>
							<?php
								}
								else{
							?>			
								<b><input class="btn btn-outline" type="submit" name="csvData" value="Xem SetupSheet Gần Nhất" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;"/></b>
							<?php
								}
								echo "</td></tr>";
								// echo "</table>";
								
							?> 
						</div>
						
						<div class="col-md-9">
							<div id = 'idUploadSetupSheet'>
								<?php 
									echo "<h4>";
									echo "Read File Status: ". $_SESSION['sWARNING'];
									echo "</br>";
									echo "Filename: " . $_SESSION['FILENAME'] . " (" . strlen($_SESSION['FILENAME']) . ")";
									echo "</br>";
									echo "Setup Sheet ID: ". $_SESSION['IDSMTSETUPSHEET'] . " (" . $_SESSION['SMTSetupSheetName'] . ")";
									echo "</br>";
									echo "Setup Sheet Log ID: ". $_SESSION['IDSMTSetupSheetLog'] . " (" . $_SESSION['SMTSetupSheetLogName'] . ")";
									echo "</br>";
									echo "Target Filename: " . $_SESSION['strTARGETFILE'];
									echo "</br>";
									echo "</h4>";
									// echo $_SESSION['iQUERRY'];
									echo "</br>";
									echo "</br>";
									
									if ($_SESSION['strTARGETFILE'] <> "***"){
										if ($_SESSION['sWARNING'] == 99){
											echo "<html><body><table class='beta' id='idSetupSheetcsv'>\n\n";
											$f = fopen($_SESSION['strTARGETFILE'], "r") or die("Unable to open file!");
											$row = 1;
											$getStartRow = "NO";
											while (($line = fgetcsv($f)) !== false) {
												if ($line[0] == "Station"){
													$getStartRow = "YES";
												}
												
												if ($getStartRow == "YES"){
													echo "<tr>";
													foreach ($line as $cell) {
														if ($row == 1){
															echo "<th>" . htmlspecialchars($cell) . "</th>";
														}
														else{
															echo "<td>" . htmlspecialchars($cell) . "</td>";
														}
													}
													echo "</tr>\n";
													$row = $row + 1;
												}
											}
											fclose($f);
											echo "\n</table></body></html>";
											
											
											// $f = fopen($_SESSION['strTARGETFILE'], "r") or die("Unable to open file!");
											// $row = 1;
											// while (($data = fgetcsv($f)) !== false) {
												// $num = count($data);
												// for ($c=0; $c < $num; $c++) {
												  // $col[$c] = $data[$c];
												// }
												
												// $row = $row + 1;
											// }
											// fclose($f);
											// echo $num;
										}
									}
									/*
									if ($_SESSION['strTARGETFILE'] <> "***"){	
										echo "<html><body><table>\n\n";
										$myfile = fopen($_SESSION['strTARGETFILE'], "r") or die("Unable to open file!");
										// Output one line until end-of-file
										while(!feof($myfile)) {
										  echo fgets($myfile) . "<br>";
										}
										fclose($myfile);
									}
									*/
									
								?>	
							</div>
							<div id = 'idViewSetupSheet' style="display:None">
								<?php				
									// echo "<table border='0' >";
										//=============================================================
										//=============================================================
										// NEW SECTOR: SHOW LIST OF SMT MACHINE LINE
										echo "<tr>";
										echo "<td> <h4>";
										echo "SMT Setup Sheet:";					
										echo "</h4></td>";

										echo "<td><h4>";
										$myServer = $_SESSION['ServerInstanceName'];
										$myUser = $_SESSION['ServerUserName'];
										$myPass = $_SESSION['ServerPassword'];
										$myDB = $_SESSION['ServerDB'];

										$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
										//connection to the database
										$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
													or die("Couldn't connect to SQL Server on $myServer");

										//declare the SQL statement that will query the database
										$query = "SELECT [SMTSetupSheetName], [IDSMTSetupSheet] FROM [dbo].[SMTSetupSheetMasterList] ORDER BY [IDSMTSetupSheet] DESC";
						
										//execute the SQL query and return records
										$result = sqlsrv_query($dbhandle,$query);
										//display the results
								?>
										<select name="lstSMTSetupSheetName" style="color:blue; width:390px; height:36px;font-size: 15pt;font-weight:bold;background-color:yellow;" onchange = "AccessListSMTSetupSheetName(this.value)" >

								<?php		
										if ($_SESSION['Language'] == "English"){
											echo "<option value='Choose a Setup Sheet Name'>Choose a Setup Sheet Name</option>";
										}
										else{
											echo "<option value='Chọn Tên File Setup Sheet'>Chọn Tên File Setup Sheet</option>";
										}
										While($row = sqlsrv_fetch_array($result)){
											if (trim($row['SMTSetupSheetName']) !== trim($_SESSION['SMTSetupSheetName'])){
												echo "<option value='" . trim($row['SMTSetupSheetName']) . "'>" . trim($row['SMTSetupSheetName']) . "</option>";
											}
											else{
												echo "<option value='" . trim($row['SMTSetupSheetName']) . "' selected>" . trim($row['SMTSetupSheetName']) . "</option>";
											}					
										}			
										sqlsrv_close($dbhandle);												
										echo "</select>";

										//==========================================================================
										//==========================================================================
										// NEW SECTOR: SHOW LIST OF PCB MODEL DEDICATED ON EQUIVALENT SMT LINE
										echo "<tr><td> <h4>";
										echo "SMT Setup Sheet Log:";					
										echo "</h4></td>";
										echo "<td><h4>";
										//echo $_SESSION['pcbModel'];	 
								?>	
										
										<div id="idSMTSetupSheetName"><b><select style="color:blue; width:550px; height:36px;font-size: 15pt;font-weight:bold;background-color:yellow;"></select></b></div>
								<?php		
										
										echo "</select>";
										echo "</h4></td></tr>";
										
										
									// echo "</table>";	//========================END THE TABLE HERE=============================
								?>		
								<?php 
									require_once("SMT_ShowSMTSetupSheetLog.php"); 
									
									// echo $_SESSION['iQUERRY'];
									// echo "</br>";
									// echo $_SESSION['IDSMTSetupSheetLog'];
									// echo "</br>";
									// echo $_SESSION['SMTSetupSheetLogName'];
								?>	
							</div>
						</div>
					</div>	
				</form>
			</div>
		</div>
    </div> 
<body>