<?php 
	@session_start();
	include("sharedPage.php");
	if ($_SERVER['REQUEST_METHOD'] == 'GET'){
		require_once("ServerLogin.php");
	}
	
	if (!isset($_SESSION['Language'])){
		$_SESSION['Language'] = "English";
	}
	else{
		
	}
?> 

<?php
function SideSelected($orgSide,$selected)
{
	if ($selected !==""){	
		if ($orgSide == $selected){
			echo "checked";
		}
	}
	else{
		echo "checked";
	}	
}
?>

<script>
	function showHint(str) {
		if (str.length==0) {
				document.getElementById("txtHint").innerHTML="";
				return;
		}
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
				}
		}
		xmlhttp.open("GET","SMT_getNote.php?q="+str,true);
		xmlhttp.send();
		
		location.reload(true);
	}
</script>

<body>	
    <div class="sidenav">
		<!-- <div id="accordion"> -->
		<div style="padding-right:20;" >
		<?php
			echo "<tr>";
  			echo "<td><h2>";
			if ($_SESSION['Language'] == "English"){
		?>					
				<div id="txtHint"> English
		<?php		
			}
			else{
		?>
				<div id="txtHint"> Tiếng Việt
		<?php			
			}
			echo "</h2></td>";
			echo "</tr>";
		?>			
			<tr>
				<td>
					<input type="radio" id="male" name="gender" value="English" <?php SideSelected("English",$_SESSION['Language']); ?> onclick="showHint('English')">
					<label for="male">English</label><br>
				</td>
				<td>
					<input type="radio" id="male" name="gender" value="Vietnamese" <?php SideSelected("Vietnamese",$_SESSION['Language']); ?> onclick="showHint('Vietnamese')">
					<label for="male">Vietnamese</label><br>
				</td>
			</tr>
		</div>
		<div>
			<ul>				
				<li>
					<div>
						<div class="panel-heading">
							<h5 class="panel-title">
								<button type="button" class="btn btn-lg btn-info" data-toggle="collapse" data-target="#collapse5">MPH</button>
							</h5>
						</div>
						<div id="collapse5" class="collapse in">
							<ul>
								<li>
									<button type="button" class="btn btn-success" data-toggle="collapse" data-target="#collRU">
										SMT
									</button>
									<div id="collRU" class="collapse in">
										<ul>
											<li>
												<?php
													// ****************************************************
													// ****************************************************
													// For **Setup Sheet Control Module**
													if (!isset($_SESSION['sWARNING'])) {		
														$_SESSION['sWARNING'] = 0;
													}

													if (!isset($_SESSION['FILENAME'])) {	
														$_SESSION['FILENAME'] = "***";
														$_SESSION['iQUERRY'] = "***";
													}

													if (!isset($_SESSION['strTARGETFILE'])) {	
														$_SESSION['strTARGETFILE'] = "***";
													}

													if (!isset($_SESSION['IDSMTSETUPSHEET'])) {	
														$_SESSION['IDSMTSETUPSHEET'] = 0;
													}
													
													if (!isset($_SESSION['SETUPSHEETUPLOADVIEW'])) {	
														$_SESSION['SETUPSHEETUPLOADVIEW'] = "Block";
													}
													
													if (!isset($_SESSION['SMTSetupSheetName'])) {	
														$_SESSION['SMTSetupSheetName'] = "***";
													}													
													
													if (!isset($_SESSION['IDSMTSetupSheetLog'])) {	
														$_SESSION['IDSMTSetupSheetLog'] = 0;
													}
													
													if (!isset($_SESSION['SMTSetupSheetLogName'])) {	
														$_SESSION['SMTSetupSheetLogName'] = "***";
													}
													
													if (!isset($_SESSION['SMTMACHINENAME'])) {	
														$_SESSION['SMTMACHINENAME'] = "";
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZEID'])) {	
														$_SESSION['iSMTPRODLOTSIZEID'] = "";
													}
													
													// ****************************************************
													// ****************************************************
													// For **Production Lot Size Preparation Module**
													if (!isset($_SESSION['LASTSMTSETUPSHEETVIEW'])) {	
														$_SESSION['LASTSMTSETUPSHEETVIEW'] = "None";
													}
													
													if (!isset($_SESSION['iLASTSMTSETUPSHEETLOG'])) {	
														$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZEQTY'])) {	
														$_SESSION['iSMTPRODLOTSIZEQTY'] = "";
													}
																										
													if (!isset($_SESSION['iSMTPRODLOTSIZEID'])) {	
														$_SESSION['iSMTPRODLOTSIZEID'] = "";
													}
													
													if (!isset($_SESSION['iPRODLOTSIZEPREP'])) {	
														$_SESSION['iPRODLOTSIZEPREP'] = "";
													}
													
													if (!isset($_SESSION['iLASTSMTSETUPSHEETLOG'])) {	
														$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZEMODEL'])) {	
														$_SESSION['iSMTPRODLOTSIZEMODEL'] = "";
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZEPONUMBER'])) {	
														$_SESSION['iSMTPRODLOTSIZEPONUMBER'] = "";
													}
													
													// ****************************************************
													// ****************************************************
													// For **Run Production Lot Size & IoT Control Module**
													if (!isset($_SESSION['iSMTPRODLOTSIZEID'])) {	
														$_SESSION['iSMTPRODLOTSIZEID'] = "";
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZEQTY'])) {	
														$_SESSION['iSMTPRODLOTSIZEQTY'] = 0;
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZEQTY'])) {	
														$_SESSION['iSMTPRODLOTSIZEQTY'] = 0;
													}
													
													if (!isset($_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'])) {	
														$_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] = 0;
													}
													
													if (!isset($_SESSION['iIOTCONTROLSTATUS'])) {	
														$_SESSION['iIOTCONTROLSTATUS'] = 0;
													}
													
													if (!isset($_SESSION['iPREVIOTCONTROLSTATUS'])) {	
														$_SESSION['iPREVIOTCONTROLSTATUS'] = 0;
													}
													
													if (!isset($_SESSION['iRESETCOUNTER'])) {	
														$_SESSION['iRESETCOUNTER'] = 0;
													}
													
													if (!isset($_SESSION['iCOUNTERCONTROL'])) {	
														$_SESSION['iCOUNTERCONTROL'] = "***";
													}
													
													// ****************************************************
													// ****************************************************
													echo "<b>"."<a href=\"SMT_SetupSheet.php?q=0\">";
													if ($_SESSION['Language'] == "English"){
														echo "Setup Sheet Control";
													}
													else{
														echo "Khai Báo Setup Sheet";
													}	
													echo "</a></b>";
												?>
											</li>
											<li>
												<?php
													echo "<b>"."<a href=\"SMT_ProdLotSizePreparation.php?q=0\">";
													if ($_SESSION['Language'] == "English"){
														echo "Production Lot Size Preparation";
													}
													else{
														echo "Chuẩn Bị Linh Kiện Cho PO";
													}
													echo "</a></b>";
												?>
											</li>
											<li>			
												<div class="btn btn-outline2">
												<?php
													echo "<b>"."<a style=\"color:red; font-size:10pt; float:center; clear:both; font-weight:bold\" href=\"SMT_RunningProdLotSize.php?q=0\">";
													if ($_SESSION['Language'] == "English"){
														echo "Run Prod. Lot Size & IoT Control";
													}
													else{
														echo "Vận Hành Truy Vết Đơn Hàng và IoT";
													}
													echo "</a></b>";
												?>
												</div>
											</li>
											<li>
												<?php
													echo "<b>"."<a href=\"SMT_ProdLotSizeDataExport.php?q=0\">";
													if ($_SESSION['Language'] == "English"){
														echo "Production Lot Size Data Export";
													}
													else{
														echo "Tải Dữ Liệu Truy Vết Linh Kiện";
													}
													echo "</a></b>";
												?>
											</li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</li>
			</ul>
		</div>
		<!-- </div> -->
	</div>
</body>