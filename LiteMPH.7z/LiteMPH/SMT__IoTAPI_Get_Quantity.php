<?php
	// @session_start();
	
	// GET localhost:8081/api/Conveyor/Get_Quantity	
	
	$url = 'localhost:8081/api/Conveyor/Get_Quantity';
	$curl = curl_init($url);
	
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	// curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type' => 'application/json',
		));
		
	$response = curl_exec($curl);
	
	if ($response === false) {
		$info = curl_getinfo($curl);
		curl_close($curl);
		
		die(var_export($info));
	}
	else{
		curl_close($curl);
	}
	
	// echo $response;
	// echo "</br>";
	
	$var = json_decode($response, TRUE);
	
	$status = ($var[0]);
	
	if ($status == "Successful"){
		echo ($var[1]);
	}
	else{
		echo "Error";
	}
?>
