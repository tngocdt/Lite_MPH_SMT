<?php
	session_start();
	
	$_SESSION['iCOMPTRACEABILITY'] = trim($_POST['ComponentTraceability']);	
	$_SESSION['iSMTLOCATION'] = trim($_POST['txtSMTLOCATION']);	
	$_SESSION['iSMTPARTNUMBER'] = trim($_POST['txtSMTPARTNUMBER']);	
	$_SESSION['iSMTPARTQTY'] = trim($_POST['txtSMTPARTQTY']);
	
			
	$_SESSION['sWARNING']= 0;	
	
	// **********************************************************
	// Check for SMT PART NUMBER VALUE
	if (strlen($_SESSION['iSMTPARTNUMBER']) == 0) {
		$_SESSION['sWARNING'] = 1;		
		header ("Location: SMT_JoinReelTraceablity.php");
		exit();
	}
	$_SESSION['FOUNDVALUE'] = "NO";
	$_SESSION['iLISTOFPARTLOCATION'] = "";
	require_once("SMT__PartNumberInSetupSheet.php");
	if ($_SESSION['FOUNDVALUE'] == "NO"){
		$_SESSION['sWARNING'] = 5;		
		header ("Location: SMT_JoinReelTraceablity.php");
		exit();
	}			
	
	// **********************************************************
	// Check for SMT LOCATION VALUE
	if (strlen($_SESSION['iSMTLOCATION']) == 0) {
		$_SESSION['sWARNING'] = 6;		
		header ("Location: SMT_JoinReelTraceablity.php");
		exit();
	}	
	$_SESSION['FOUNDVALUE'] = "NO";
	require_once("SMT__SMTLocationInSetupSheet.php");
	if ($_SESSION['FOUNDVALUE'] == "NO"){
		$_SESSION['sWARNING'] = 7;		
		header ("Location: SMT_JoinReelTraceablity.php");
		exit();
	}
	$_SESSION['FOUNDVALUE'] = "NO";
	require_once("SMT__PartNumberInLocationSetupSheet.php");
	if ($_SESSION['FOUNDVALUE'] == "NO"){
		$_SESSION['sWARNING'] = 9;		
		header ("Location: SMT_JoinReelTraceablity.php");
		exit();
	}
	// $_SESSION['FOUNDVALUE'] = "YES";
	// require_once("SMT__PartNumberInPreparation.php");
	// if ($_SESSION['FOUNDVALUE'] == "YES"){
		// $_SESSION['sWARNING'] = 10;		
		// header ("Location: SMT_JoinReelTraceablity.php");
		// exit();
	// }
	
	// **********************************************************
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	
	if ($_SESSION['iCOMPTRACEABILITY']  == "Record Component Traceability"){
		// Check for SMT Part QUANTITY VALUE
		if (strlen($_SESSION['iSMTPARTQTY']) == 0) {
			$_SESSION['sWARNING'] = 2;		
			header ("Location: SMT_JoinReelTraceablity.php");
			exit();
		}	
		if ((int)($_SESSION['iSMTPARTQTY']) <= 0) {
			$_SESSION['sWARNING'] = 3;		
			header ("Location: SMT_JoinReelTraceablity.php");
			exit();
		}	
		if ((int)($_SESSION['iSMTPARTQTY']) > 500000) {
			$_SESSION['sWARNING'] = 4;		
			header ("Location: SMT_JoinReelTraceablity.php");
			exit();
		}
		
		// **********************************************************
		// **********************************************************					
		$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
		
		//connection to the database
		$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
							or die("Couldn't connect to SQL Server on $myServer");
							
		$query = "INSERT INTO [dbo].[SMTProdLotSizeJoinReel]([ProdLotSizeID],[Location],[PartNumber],[PartOrgQty],[IDSMTSetupSheetLog]) VALUES (" 
				. "'" . $_SESSION['iSMTPRODLOTSIZEID'] . "', "
				. "'" . $_SESSION['iSMTLOCATION'] . "', "
				. "'" . $_SESSION['iSMTPARTNUMBER'] . "', "
				. "'" . $_SESSION['iSMTPARTQTY'] . "', "
				. "'" . $_SESSION['IDSMTSetupSheetLog'] . "')";
				
		// $_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		sqlsrv_query($dbhandle,$query);	
						
		sqlsrv_close($dbhandle);
	}
	else{
		// **********************************************************
		// **********************************************************					
		$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
		
		//connection to the database
		$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
							or die("Couldn't connect to SQL Server on $myServer");
							
		$query = "SELECT TOP(1) * FROM [dbo].[v_06_SMTProdLotSizeJoinReelStatusWarning] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
					. " AND [PartNumber] = '" . $_SESSION['iSMTPARTNUMBER'] . "'"
					. " AND [Location] = '" . $_SESSION['iSMTLOCATION'] . "'";
					
		// $_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);		
		
		$getOrgQty = 0;
		$getMinusQty = 0;
		while ($row = sqlsrv_fetch_array($result)) {		
			$getMinusQty = (int)$row['PartRemainQty'];
			$getOrgQty = (int)$row['PartOrgQty'];
		}
		
		if ($getMinusQty > 0){
			if ($getMinusQty == $getOrgQty){
				/*
				$query = "DELETE FROM [dbo].[SMTProdLotSizePreparation] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
					. " AND [PartNumber] = '" . $_SESSION['iSMTPARTNUMBER'] . "'"
					. " AND [Location] = '" . $_SESSION['iSMTLOCATION'] . "'"; 
					
				// $_SESSION['iQUERRY'] = $query;
				//execute the SQL query and return records
				sqlsrv_query($dbhandle,$query);
				*/
				
				$query = "DELETE FROM [dbo].[SMTProdLotSizeJoinReel] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
					. " AND [PartNumber] = '" . $_SESSION['iSMTPARTNUMBER'] . "'"
					. " AND [Location] = '" . $_SESSION['iSMTLOCATION'] . "'"; 
					
				// $_SESSION['iQUERRY'] = $query;
				//execute the SQL query and return records
				sqlsrv_query($dbhandle,$query);
			}
			else{
				$getMinusQty = 0 - $getMinusQty;
				$query = "INSERT INTO [dbo].[SMTProdLotSizeJoinReel]([ProdLotSizeID],[Location],[PartNumber],[PartOrgQty],[IDSMTSetupSheetLog]) VALUES (" 
							. "'" . $_SESSION['iSMTPRODLOTSIZEID'] . "', "
							. "'" . $_SESSION['iSMTLOCATION'] . "', "
							. "'" . $_SESSION['iSMTPARTNUMBER'] . "', "
							. "'" . $getMinusQty . "', "
							. "'" . $_SESSION['IDSMTSetupSheetLog'] . "')";
							
				// $_SESSION['iQUERRY'] = $query;
				//execute the SQL query and return records
				sqlsrv_query($dbhandle,$query);	
				
			}
					
			
		}
		
		sqlsrv_close($dbhandle);
	}
	
	$_SESSION['iPrevSMTLOCATION'] = $_SESSION['iSMTLOCATION'];
	$_SESSION['iPrevSMTPARTNUMBER'] = $_SESSION['iSMTPARTNUMBER'];
	$_SESSION['iPrevSMTPARTQTY'] = $_SESSION['iSMTPARTQTY'];
	
	$_SESSION['iSMTLOCATION'] = "";
	$_SESSION['iSMTPARTNUMBER']	= "";
	$_SESSION['iSMTPARTQTY'] = "";
	
	header ("Location: SMT_JoinReelTraceablity.php");
?>