 <?php
	@session_start();
	
	//get the q parameter from URL
	$q = $_REQUEST["q"];
	$_SESSION['Language'] = $q;
	// Output "no suggestion" if no hint were found
	// or output the correct values
	echo $_SESSION['Language'];
?>
