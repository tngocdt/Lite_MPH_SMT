<?php	
	// session_start();
	// $q=$_REQUEST["q"];
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//separate the value of $q: linename_pcbmodel	
	// $line= trim(strtok($q, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	// $SMTSetupSheetLogName = $q;
	$SMTSetupSheetLogName = $_SESSION['SMTSetupSheetLogName'];
	$_SESSION['IDSMTSetupSheetLog'] = 0;

	//declare the SQL statement that will query the database
	$query = "SELECT [IDSMTSetupSheetLog] FROM [dbo].[SMTSetupSheetLogControl] WHERE [SMTSetupSheetLogName] = '" . $SMTSetupSheetLogName . "'";
	
	$_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);

	//display the results
	while($row = sqlsrv_fetch_array($result)){
		$_SESSION['IDSMTSetupSheetLog'] = $row['IDSMTSetupSheetLog'];
	}
	
	if ($_SESSION['IDSMTSetupSheetLog'] > 0){
		//declare the SQL statement that will query the database
		$query = "SELECT * FROM [dbo].[SMTSetupSheetLayoutControl] WHERE"
				. " [IDSMTSetupSheetLog] = '" . $_SESSION['IDSMTSetupSheetLog'] . "'"
				. " ORDER BY [MachinePosition]";
				
		$result = sqlsrv_query($dbhandle,$query);
		
		echo "</br>";
		echo "<html><body><table>\n\n";
		echo "<th>
				<tr>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Machine</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Position</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">PartNo</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">FIDL</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Pickup</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Usage</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Reject</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">NoPick</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Error</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Dislodge</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Rescan</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Pickup</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Reject</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Error</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Dislodge</td>
				<td style =\"font-weight:bold\" bgcolor=\"yellow\" color=\"blue\">Success</td>
				</tr>
			</th>";
		$rowCount = 1;
		while ($row = sqlsrv_fetch_array($result)) {
			echo "<tr>";
				// echo "<td>" . trim($row['IDSMTSetupSheetLog']) . "</td>";
				echo "<td>" . trim($row['MachineName']) . "</td>";
				echo "<td>" . trim($row['MachinePosition']) . "</td>";
				echo "<td>" . trim($row['MachineMaterials']) . "</td>";
				echo "<td>" . trim($row['MachineFIDL']) . "</td>";
				echo "<td>" . $row['PickupQty'] . "</td>";
				echo "<td>" . $row['UsageQty'] . "</td>";
				echo "<td>" . $row['RejectQty'] . "</td>";
				echo "<td>" . $row['NoPickQty'] . "</td>";
				echo "<td>" . $row['ErrorQty'] . "</td>";
				echo "<td>" . $row['DislodgeQty'] . "</td>";
				echo "<td>" . $row['RescanQty'] . "</td>";
				echo "<td>" . $row['Pickup2Qty'] . "</td>";
				echo "<td>" . $row['Reject2Qty'] . "</td>";
				echo "<td>" . $row['Error2Qty'] . "</td>";
				echo "<td>" . $row['Dislodge2Qty'] . "</td>";
				echo "<td>" . $row['SuccessQty'] . "</td>";
			echo "</tr>";
			$rowCount = $rowCount + 1;
		}
		echo "\n</table></body></html>";
		
	}
	sqlsrv_close($dbhandle);
	
?>
