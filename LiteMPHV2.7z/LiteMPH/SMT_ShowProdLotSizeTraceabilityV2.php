<?php	
	// session_start();
	// $q=$_REQUEST["q"];
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//separate the value of $q: linename_pcbmodel	
	// $line= trim(strtok($q, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	// $SMTSetupSheetLogName = $q;

	//declare the SQL statement that will query the database
	$query = "SELECT TOP(1) * FROM [dbo].[v_06_SMTProdLotSizeJoinReelStatusWarning] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "' ORDER BY RateQtyStatus";
	
	$_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);		
	
	$getIDSMTSetupSheetLog = 0;
	while ($row = sqlsrv_fetch_array($result)) {		
		$getIDSMTSetupSheetLog = (int)$row['IDSMTSetupSheetLog'];
	}
	
	// if ($getIDSMTSetupSheetLog > 1){
		// $_SESSION['IDSMTSetupSheetLog'] = $getIDSMTSetupSheetLog;
		echo "<h5>";
		echo "SMT PRODUCTION LOT SIZE MATERIALS STATUS - COMPLETED QUANTITY: " . $_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] . " - PRODUCTION LOT SIZE QUANTITY: " . $_SESSION['iSMTPRODLOTSIZEQTY'];
		echo "</h5>";
		echo "<html><body>";
?>
			<table class='beta' style="border:1px solid black; margin-left:0; margin-right:0; width: 100%;">
<?php
		echo "<tr>
				<th>No.</th>
				<th>ProdLotSizeID</th>
				<th>Location</th>
				<th>PartNumber</th>
				<th>PartOrgQty</th>
				<th>Machine</th>
				<th>PartConsumptionLevel</th>
				<th>PartConsumptionQty</th>
				<th>PartAvailableQty</th>
				<th>AvailablePanelQty</th>
				<th>AvailableRateLevel</th>
			</tr>";
			
		//declare the SQL statement that will query the database
		$query = "SELECT * FROM [dbo].[v_06_SMTProdLotSizeJoinReelStatusWarning] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "' ORDER BY RateQtyStatus";
		
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		
		$rowCount = 0;
		$resetIoTControlStatus = 0;
		while ($row = sqlsrv_fetch_array($result)) {
			// $dtProdLotSizeTime = $row['ProdLotSizeTime']->format('Y-m-d H:i:s');
			$strRateQtyWarning = trim($row['RateQtyWarning']);
			
			$getRowRate = (double)$row['RateQtyStatus'];
			if ((double)$getRowRate < (double)$_SESSION['IoTCONTROLRATE']){				
				$resetIoTControlStatus = $resetIoTControlStatus + 1;
			}
			
			$rowCount = $rowCount + 1;
			echo "<tr>";
				if ($strRateQtyWarning == "Green"){
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $rowCount . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['ProdLotSizeID']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['Location']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['PartNumber']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['PartOrgQty']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['MachineName']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['PickupQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['PartConsumptionQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['PartRemainQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['AvailablePanelQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $row['RateQtyStatus']*100 . " %" . "</td>";
				}
				elseif ($strRateQtyWarning == "Yellow"){
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . $rowCount . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . trim($row['ProdLotSizeID']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . trim($row['Location']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . trim($row['PartNumber']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . (int)($row['PartOrgQty']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . trim($row['MachineName']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . (int)($row['PickupQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . (int)($row['PartConsumptionQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . (int)($row['PartRemainQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . (int)($row['AvailablePanelQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='yellow' color='blue'>" . $row['RateQtyStatus']*100 . " %" . "</td>";
				}
				else{
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . $rowCount . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . trim($row['ProdLotSizeID']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . trim($row['Location']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . trim($row['PartNumber']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . (int)($row['PartOrgQty']) . "</td>";
					echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . trim($row['MachineName']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . (int)($row['PickupQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . (int)($row['PartConsumptionQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . (int)($row['PartRemainQty']) . "</td>";
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . (int)($row['AvailablePanelQty']) . "</td>";	
					echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='red' color='white'>" . $row['RateQtyStatus']*100 . " %" . "</td>";
				}
			echo "</tr>";			
		}
?>
			</table>
<?php
			echo "</body></html>";
		
		
	// }
	
	
	sqlsrv_close($dbhandle);
	if ($_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] < $_SESSION['iSMTPRODLOTSIZEQTY']){ 
		if ($resetIoTControlStatus == 0){
			$_SESSION['IoTCONTROLSTATUS'] = 0;	
			require_once("SMT__ResetIoTControlStatusOnMachine.php");	
		}
		else{
			$_SESSION['IoTCONTROLSTATUS'] = 1;	
			require_once("SMT__SetIoTControlStatusOnMachine.php");						
		}
	}
	else{
		$_SESSION['IoTCONTROLSTATUS'] = 1;	
		require_once("SMT__CloseIoTControlStatusOnMachine.php");	
	}
?>
