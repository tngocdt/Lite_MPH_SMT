<?php
	session_start();
	
	
	
	header ("Location: SMT_RunningProdLotSizeConsumption.php");
?>