<?php
	session_start();
		
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	
	$myDB = $_SESSION['ServerDB'];
	
	$_SESSION['iSMTPRODLOTSIZEID'] = 0;
	
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
				or die("Couldn't connect to SQL Server on $myServer");

	// the following code segment will get the ID for reel component
	$getSMTPRODLOTSIZEID = 0;	// initial the REELID
		
	$params = array(
		// array(&$_SESSION['FILENAME'], SQLSRV_PARAM_IN),
		// array(&$_SESSION['strTARGETFILENAME'], SQLSRV_PARAM_IN),
		array(&$getSMTPRODLOTSIZEID, SQLSRV_PARAM_OUT)
	);
	
	$sql = "EXEC [dbo].[speleanAIms_AccessSMTProdLotSize] @result = ?";		
	$stmt = sqlsrv_query($dbhandle, $sql, $params);
	
	if($stmt === false){  
		echo "Sorry, there was an error in accessing SMT Production Lot Size Number!";
		echo "</br>";
		die( print_r( sqlsrv_errors(), true));  
	}  
	else{
		$rowcount = 0;
		while($row = sqlsrv_fetch_array($stmt)){
			$rowcount = $rowcount + 1;
			$_SESSION['iSMTPRODLOTSIZEID'] = trim($row['Result']);
		}
	}
		
	sqlsrv_free_stmt($stmt);
	sqlsrv_close($dbhandle);	
?>