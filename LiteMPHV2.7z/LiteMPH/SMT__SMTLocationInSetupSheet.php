<?php
	@session_start();
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//declare the SQL statement that will query the database
	$query = "SELECT TOP(1) * FROM [dbo].[SMTSetupSheetLayoutControl] WHERE"
				. " [IDSMTSetupSheetLog] = '" . $_SESSION['IDSMTSetupSheetLog'] . "'"
				. " AND [MachinePosition] = '" . $_SESSION['iSMTLOCATION'] . "' ";
	
	$_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);
	//display the results
	
	$returnedFindingVal = "";
	$_SESSION['FOUNDVALUE'] = "NO";
	While($row = sqlsrv_fetch_array($result)){
		$returnedFindingVal = trim($row['MachinePosition']);
	}

	if ($returnedFindingVal == "") {
		$_SESSION['FOUNDVALUE'] = "NO";
	}
	else{
		$_SESSION['FOUNDVALUE'] = "YES";
	}
	sqlsrv_close($dbhandle);		
?>
