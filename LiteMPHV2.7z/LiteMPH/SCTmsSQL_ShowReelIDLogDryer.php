<?php
	@session_start();
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
				or die("Couldn't connect to SQL Server on $myServer");

	//declare the SQL statement that will query the database
	$query = "SELECT ReelID, PICcode, DateTimeRegist FROM PreAssyComponentsTracking_ReelIDDryer WHERE "
			. "ReelID = '" . $_SESSION['sPrevREELID'] . "' "
			. "ORDER BY DateTimeRegist DESC";
			
	//echo $query;		
	echo "<p><b><span style=\"font-size:22;background-color:Yellow;\">";
	echo "<font color=\"blue\">";
	echo "ReelID Logs Into Dryer:";
	echo "<br>";
	echo "</font></span></b></p>";	
	// echo $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);
	// display the results
	
	$getRow = 0;
	echo "<table border='4' CELLSPACING='4' CELLPADDING='4'>
			<tr><b>							
			<td style =\"font-weight:bold\" bgcolor=\"orange\">No.</td>
			<td style =\"font-weight:bold\" bgcolor=\"orange\">ReelID</td>
			<td style =\"font-weight:bold\" bgcolor=\"orange\">PICcode</td>
			<td style =\"font-weight:bold\" bgcolor=\"orange\">DateTime</td>
			</tr></b>";							

			while($row = sqlsrv_fetch_array($result)) {
				$_SESSION['iVerReelID'] = trim($row['ReelID']);			
				$_SESSION['iVerPICCode'] = trim($row['PICcode']);			
				$inDate =  $row['DateTimeRegist']->format('M-d H:i');
				
				$getRow = $getRow + 1;
				
				echo "<tr>"; 		
				echo "<td>" . $getRow . "</td>";
				echo "<td>" . $_SESSION['iVerReelID'] . "</td>";			
				echo "<td>" . $_SESSION['iVerPICCode'] . "</td>";
				echo "<td>" . $inDate . "</td>";			
				echo "</tr>";
		}

		echo "</table>";
	sqlsrv_close($dbhandle);
	
?>
