 <?php
	session_start();
	//get the q parameter from URL
	$q=$_REQUEST["q"];

	// Output "no suggestion" if no hint were found
	// or output the correct values
	
	// echo $q;
	$_SESSION['sWARNING'] = 0;
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//separate the value of $q: linename_pcbmodel	
	// $line= trim(strtok($q, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	$SMTSetupSheetName = $q;
	$_SESSION['SMTSetupSheetName'] = $q;
	$_SESSION['IDSMTSetupSheet'] = 0;
	$_SESSION['IDSMTSetupSheetLog'] = 0;
	$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";

	//declare the SQL statement that will query the database
	$query = "SELECT [IDSMTSetupSheet] FROM [dbo].[SMTSetupSheetMasterList] WHERE [SMTSetupSheetName] = '" . $_SESSION['SMTSetupSheetName'] . "'";
	
	// $_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);

	//display the results
	while($row = sqlsrv_fetch_array($result)){
		$_SESSION['IDSMTSetupSheet'] = $row['IDSMTSetupSheet'];
	}
	
	if ($_SESSION['IDSMTSetupSheet'] > 0){
		//declare the SQL statement that will query the database
		$query = "SELECT TOP(1) * FROM [dbo].[SMTSetupSheetLogControl] WHERE [IDSMTSetupSheet] = '" . $_SESSION['IDSMTSetupSheet'] ."' ORDER BY [SMTSetupSheetLogName] DESC";
		
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		
		While($row = sqlsrv_fetch_array($result)){
			$_SESSION['IDSMTSetupSheetLog'] = $row['IDSMTSetupSheetLog'];
			$_SESSION['iLASTSMTSETUPSHEETLOG'] = trim($row['SMTSetupSheetLogName']);
		}
		$_SESSION['LASTSMTSETUPSHEETVIEW'] = "Block";
	}	
	else{
		$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";
		$_SESSION['LASTSMTSETUPSHEETVIEW'] = "None";
	}
	sqlsrv_close($dbhandle);
	
	echo $_SESSION['iLASTSMTSETUPSHEETLOG'] . "(" . $_SESSION['IDSMTSetupSheetLog'] . ")";
?>
