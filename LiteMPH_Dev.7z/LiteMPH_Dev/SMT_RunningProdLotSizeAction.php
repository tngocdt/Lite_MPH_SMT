<?php
	session_start();
	
	$_SESSION['iSMTPRODLOTSIZEID'] = trim($_POST['txtSMTPRODLOTSIZEID']);
	$_SESSION['iRUNPRODLOTSIZE'] = trim($_POST['RunProductionLotSize']);
			
	$_SESSION['sWARNING']= 0;	
	
	if (strlen($_SESSION['iSMTPRODLOTSIZEID']) < 14) {
		$_SESSION['sWARNING'] = 1;		
		header ("Location: SMT_RunningProdLotSize.php");
		exit();
	}
	
	if (substr($_SESSION['iSMTPRODLOTSIZEID'],0,7) != "SMTPLOT") {
		$_SESSION['sWARNING'] = 2;		
		header ("Location: SMT_RunningProdLotSize.php");
		exit();
	}
	
	$_SESSION['IDSMTSetupSheetLog'] = 0;
	$_SESSION['SMTSetupSheetName'] = "None";
	$_SESSION['FOUNDVALUE'] = "NO";
	require_once("SMT__ProdLotSizeIDInPreparation.php");
	if ($_SESSION['FOUNDVALUE'] == "NO"){
		$_SESSION['sWARNING'] = 5;		
		header ("Location: SMT_RunningProdLotSize.php");
		exit();
	}	
	
	if ($_SESSION['iRUNPRODLOTSIZE'] == "Join Reels Traceability"){
		$_SESSION['iSMTPARTNUMBER'] = "";
		$_SESSION['iSMTLOCATION'] = "";
		$_SESSION['iSMTPARTQTY'] = "";
		header ("Location: SMT_JoinReelTraceablity.php");
	}
	else{
		$_SESSION['IoTCONTROLRATE'] = 0;
		$_SESSION['SMTMACHINENAME'] = "";
		$_SESSION['FOUNDVALUE'] = "NO";
		require_once("SMT__ProdLotSizePrepareFullSetupSheetLocation.php");
		if ($_SESSION['FOUNDVALUE'] == "NO"){
			$_SESSION['sWARNING'] = 7;		
			header ("Location: SMT_RunningProdLotSize.php");
			exit();
		}	
		
		// **********************************************************
		// **********************************************************
		
		$myServer = $_SESSION['ServerInstanceName'];
		$myUser = $_SESSION['ServerUserName'];
		$myPass = $_SESSION['ServerPassword'];
		$myDB = $_SESSION['ServerDB'];
		$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
		
		//connection to the database
		$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
							or die("Couldn't connect to SQL Server on $myServer");						
			
		$query = "SELECT TOP(1) * FROM [dbo].[SMTMachineMonitoring] WHERE"
					. " [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'"
					. " AND [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
				
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		sqlsrv_query($dbhandle,$query);	
		
		$returnedProdLotSizeID = "";
		while ($row = sqlsrv_fetch_array($result)) {		
			$returnedProdLotSizeID = trim($row['ProdLotSizeID']);
		}
		
		if ($returnedProdLotSizeID == ""){
			$query = "UPDATE [dbo].[SMTMachineMonitoring] SET [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
						. " WHERE [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'";
					
			$_SESSION['iQUERRY'] = $query;
			//execute the SQL query and return records
			sqlsrv_query($dbhandle,$query);
			
			$query = "INSERT INTO [dbo].[SMTMachineMonitoringLog]([SMTMachineName],[ProdLotSizeID]) VALUES (" 
						. "'" . $_SESSION['SMTMACHINENAME'] . "', "
						. "'" . $_SESSION['iSMTPRODLOTSIZEID'] . "')";
					
			$_SESSION['iQUERRY'] = $query;
			//execute the SQL query and return records
			sqlsrv_query($dbhandle,$query);	
		}
		
		sqlsrv_close($dbhandle);
		
		// **********************************************************
		// **********************************************************
		header ("Location: SMT_RunningProdLotSizeConsumption.php");
	}
	
?>