<?php
	session_start();
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	
	$myDB = $_SESSION['ServerDB'];
	
	// $_SESSION['REELID'];
	// $_SESSION['LineSMT'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
				or die("Couldn't connect to SQL Server on $myServer");

	$returnedVal = 0;
	
	$query = "SELECT TOP(1) * FROM [dbo].[SMTSetupSheetMasterList] WHERE "
				. " [SMTSetupSheetName] = '" . $_SESSION['FILENAME'] . "'";
	
	$_SESSION['iQUERRY'] = $query;
	$result = sqlsrv_query($dbhandle,$query);
	
	while($row = sqlsrv_fetch_array($result)){
		$returnedVal = $row['IDSMTSetupSheet'];
	}

	if ($returnedVal == 0) {
		$_SESSION['IDSMTSETUPSHEET'] = 0;
	}
	else{
		$_SESSION['IDSMTSETUPSHEET'] = $returnedVal;
	}
		
	// *************************************************************************
	// *************************************************************************
	if ($_SESSION['IDSMTSETUPSHEET'] == 0){
		$query = " INSERT INTO [dbo].[SMTSetupSheetMasterList](SMTSetupSheetName) VALUES (" 
									. "'" . $_SESSION['FILENAME'] . "')";
									
		// $_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		sqlsrv_query($dbhandle,$query);	
		
		// *************************************************************************
		// *************************************************************************
		$query = "SELECT TOP(1) * FROM [dbo].[SMTSetupSheetMasterList] WHERE "
				. " [SMTSetupSheetName] = '" . $_SESSION['FILENAME'] . "'";
				
		$result = sqlsrv_query($dbhandle,$query);
		
		while($row = sqlsrv_fetch_array($result)){
			$returnedVal = $row['IDSMTSetupSheet'];
		}

		if ($returnedVal == 0) {
			$_SESSION['IDSMTSETUPSHEET'] = 0;
		}
		else{
			$_SESSION['IDSMTSETUPSHEET'] = $returnedVal;
		}
	}
	
	sqlsrv_close($dbhandle);
?>