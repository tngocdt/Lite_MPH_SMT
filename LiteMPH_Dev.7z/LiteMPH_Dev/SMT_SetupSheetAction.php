<?php
	session_start();
	
	$_SESSION['iCSVDATA'] = trim($_POST['csvData']) ;
	
	if ($_SESSION['iCSVDATA'] == "Upload Setup Sheet *.csv") {	
		$_SESSION['SETUPSHEETUPLOADVIEW'] = "Block";
		
		// $uploadOk = 1;
		$_SESSION['sWARNING'] = 0;
		
		$_SESSION['FILENAME'] = basename($_FILES["fileToUpload"]["name"], ".csv");
		
		$_SESSION['strTIMESTAMP'] = date("Ymd_his");
		$_SESSION['strTARGETFILENAME'] = $_SESSION['FILENAME'] . "_" . $_SESSION['strTIMESTAMP'] . ".csv";		
		
		$_SESSION['strDIR'] = "SMT_SetupSheet_Log/";
		$_SESSION['strTARGETFILE'] = $_SESSION['strDIR'] . $_SESSION['strTARGETFILENAME'];
		// echo $_SESSION['strTARGETFILE'];
		
		// $imageFileType = strtolower(pathinfo($_SESSION['strTARGETFILE'],PATHINFO_EXTENSION));

		// Check if image file is a actual image or fake image
		// if(isset($_POST["submit"])) {
			// $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			// if($check !== false) {
				// echo "File is an image - " . $check["mime"] . ".";
				// $uploadOk = 1;
			// } else {
			
			// echo "File is not an image.";
			// $uploadOk = 0;
		  // }
		// }
		
		// Check length of filename
		if (strlen($_SESSION['FILENAME']) > 60) {
			$_SESSION['sWARNING'] = 10;
			header ("Location: SMT_SetupSheet.php");
			exit();
		}
		
		// Check if file already exists
		if (file_exists($_SESSION['strTARGETFILE'])) {		
			// echo "Sorry, file already exists.";
			// $uploadOk = 0;
			$_SESSION['sWARNING'] = 1;
			header ("Location: SMT_SetupSheet.php");
			exit();		
		}

		// Check file size
		// If the file is larger than 500KB
		// an error message is displayed
		if ($_FILES["fileToUpload"]["size"] > 500000) {
			// echo "Sorry, your file is too large.";
			// $uploadOk = 0;
			$_SESSION['sWARNING'] = 2;
			header ("Location: SMT_SetupSheet.php");
			exit();		
		}

		// Allow certain file formats
		// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
			// echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			// $uploadOk = 0;
		// }

		// Check if $uploadOk is set to 0 by an error
		// if ($uploadOk == 0) {
		if ($_SESSION['sWARNING'] = 0) {
			echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
		} 
		else {
			if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $_SESSION['strTARGETFILE'])) {
				// echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
				$_SESSION['strTARGETFILENAME'] = $_SESSION['strTARGETFILENAME'];
				$_SESSION['sWARNING'] = 99;
				
				// $_SESSION['FILENAME']
				$_SESSION['IDSMTSETUPSHEET'] = 0;
				// start code here for database CRUD
				require_once("SMT_UpdateSMTSetupSheetMasterList.php");		// Server will control to create the ReelID and the program access to get that ReelID
				$idSMTSetupSheet = $_SESSION['IDSMTSETUPSHEET'];
				$idSMTSetupSheetLog = $_SESSION['IDSMTSetupSheetLog'];
				
				if($idSMTSetupSheetLog > 0){
					// Update [dbo].[SMTSetupSheetLayoutControl]
					
					$f = fopen($_SESSION['strTARGETFILE'], "r") or die("Unable to open file!");
					$row = 1;
					
					$myServer = $_SESSION['ServerInstanceName'];
					$myUser = $_SESSION['ServerUserName'];
					$myPass = $_SESSION['ServerPassword'];
					$myDB = $_SESSION['ServerDB'];
					$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
					
					//connection to the database
					$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
										or die("Couldn't connect to SQL Server on $myServer");
										
					while (($data = fgetcsv($f)) !== false) {
						$num = count($data);
						for ($c=0; $c < $num; $c++) {
							$col[$c] = $data[$c];
						}
						
						
						// ********************************************************************************************************************
						// ********************************************************************************************************************
						// update [dbo].[SMTMachineName]
						$query = "SELECT TOP(1) * FROM [dbo].[SMTMachineMonitoring] WHERE"
									. " [SMTMachineName] = '" . trim($col[0]) . "'";

						//execute the SQL query and return records
						$result = sqlsrv_query($dbhandle,$query);
						//display the results
						
						$returnedFindingVal = "";
						While($row = sqlsrv_fetch_array($result)){
							$returnedFindingVal = ($row['SMTMachineName']);
						}
						
						if ($returnedFindingVal == 0){
							$query = "INSERT INTO [dbo].[SMTMachineMonitoring]([SMTMachineName]) VALUES ("
								. "'" . trim($col[0]) . "')";
								
							// $_SESSION['iQUERRY'] = $query;
							//execute the SQL query and return records
							sqlsrv_query($dbhandle,$query);
						}
												
						// ********************************************************************************************************************
						// ********************************************************************************************************************
						// ********************************************************************************************************************
										
						$query = " INSERT INTO [dbo].[SMTSetupSheetLayoutControl]([IDSMTSetupSheetLog],[MachineName],[MachinePosition],[MachineMaterials],[MachineFIDL],[PickupQty],[UsageQty],[RejectQty],[NoPickQty],[ErrorQty],[DislodgeQty],[RescanQty],[Pickup2Qty],[Reject2Qty],[Error2Qty],[Dislodge2Qty],[SuccessQty]) VALUES (" 
								. "'" . $idSMTSetupSheetLog . "', "
								. "'" .  trim($col[0]) . "', "
								. "'" .  trim($col[1]) . "', "
								. "'" .  trim($col[2]) . "', "
								. "'" .  trim($col[3]) . "', "
								. "'" .  trim($col[4]) . "', "
								. "'" .  (int)$col[5] . "', "
								. "'" .  (int)$col[6] . "', "
								. "'" .  (int)$col[7] . "', "
								. "'" .  (int)$col[8] . "', "
								. "'" .  (int)$col[9] . "', "
								. "'" .  (int)$col[10] . "', "
								. "'" .  (int)$col[11] . "', "
								. "'" .  (int)$col[12] . "', "
								. "'" .  (int)$col[13] . "', "
								. "'" .  (int)$col[14] . "', "
								. "'" .  (int)$col[15]  . "')";
								
						// $_SESSION['iQUERRY'] = $query;
						//execute the SQL query and return records
						sqlsrv_query($dbhandle,$query);	
						
						
						$row = $row + 1;
					}
					fclose($f);
					sqlsrv_close($dbhandle);
				}
				

				header ("Location: SMT_SetupSheet.php");
			} 
			else {
				// echo "Sorry, there was an error uploading your file.";
				$_SESSION['sWARNING'] = 3;
				$_SESSION['FILENAME'] = "***";
				$_SESSION['strTARGETFILE'] = "***";
				header ("Location: SMT_SetupSheet.php");
				exit();	
			}
		}
	}
	else{
		$_SESSION['SMTSetupSheetName'] = trim($_POST['lstSMTSetupSheetName']) ;
		$_SESSION['SMTSetupSheetLogName'] = trim($_POST['lstSMTSetupSheetNameLog']) ;
		
		$_SESSION['sWARNING'] = 999;
		$_SESSION['SETUPSHEETUPLOADVIEW'] = "None";
		header ("Location: SMT_SetupSheet.php");
	}
?>