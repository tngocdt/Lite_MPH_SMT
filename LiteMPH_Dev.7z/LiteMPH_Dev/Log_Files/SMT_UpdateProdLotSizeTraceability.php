<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
?>

<script type="text/javascript" src="/javaScripts/jquery-1.12.4.min.js">
	$(document).ready(function() {		
		$("#SMT_ProdLotSizePrepFrom").on("submit", function () {

			$("#response").attr("class", "");
			$("#response").html("");
			var fileType = ".csv";
			var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
			if (!regex.test($("#file").val().toLowerCase())) {
					$("#response").addClass("error");
					$("#response").addClass("display-block");
				$("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
				return false;
			}
			return true;
		});
	});
</script>



<script>
	function GetUserInput(intWarning, strFileName, $cfgSetupView, reservedPara) {	
		if (intWarning == 10) {
			alert("Sorry, length of filename is not allowed to over 60 characters!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 1) {
			alert("Sorry, file already exists!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 2) {
			alert("Sorry, your file is too large!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 3) {
			alert("Sorry, there was an error uploading your file! Please select a file again!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 99) {
			alert("The file **" + strFileName + "** has been uploaded!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
	}
	
	function OnLoadFunction($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgSetupSheetName, $cfgReservedPara) {
		
		GetUserInput($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgReservedPara);
		
	}
</script>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgFileName = (isset($_SESSION['FILENAME']) ? $_SESSION['FILENAME'] : "***");
	$cfgSetupView = (isset($_SESSION['SETUPSHEETUPLOADVIEW']) ? $_SESSION['SETUPSHEETUPLOADVIEW'] : "***");
	$cfgSetupSheetName = (isset($_SESSION['SMTSetupSheetName']) ? $_SESSION['SMTSetupSheetName'] : "Block");
	$cfgReservedPara = "";
?>

<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgFileName . "'"; ?>,<?php echo "'" . $cfgSetupView . "'"; ?>,<?php echo "'" . $cfgSetupSheetName . "'"; ?>,<?php echo "'" . $cfgReservedPara . "'"; ?>)" >
	<div class="row content">
        <div class="col-md-3 sidenav">
			<?php 
				include("index.php");
			?> 
		</div>
		
		<div class="col-md-9">
			<div class="panel panel-success" style="margin-right: 20px;">
				<div class="panel-heading" style="text-align:center; color:white; font-size:24pt; float:center; clear:both; font-weight:bold">SMT PRODUCTION LOT SIZE PREPARATION MODULE</div>
			</div>
			<div>
				<form name="SMT_ProdLotSizePrepFrom" action="SMT_ProdLotSizePreparationAction.php" style="display: inline; text-align:center; margin: 0;" method="POST" enctype="multipart/form-data">
					<div class="row content">
											
						<?php 		
							// echo $_SESSION['SETUPSHEETUPLOADVIEW'];
							// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
							
							//====================================================================
							//====================================================================
							// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
							echo "<tr>";							
							echo "<td>";
							echo "</br>";
						?>
						
							<b><input class="btn btn-outline" type="submit" name="ProdLotSizePrep" value="Start New Lot Size" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold" /></b>
							
						<?php	
							echo "</td></tr>";
							//====================================================================
							//====================================================================
							// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
							
							echo "<tr>";
							echo "<td>";							
							echo "</br>";
							echo "</br>";
							echo "</br>";
							echo "</br>";
							echo "</br>";
						?>			
							<?//============SET UP THE INPUT BOX HERE FOR SCANNING SMPN?>
							<b><input class="btn btn-outline" type="submit" name="ProdLotSizePrep" value="Update A Lot Size" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;"/></b>
						<?php	
							echo "</td></tr>";
							// echo "</table>";
							
						?> 					
						
					</div>	
				</form>
			</div>
		</div>
    </div> 
<body>