<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
?>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgFileName = (isset($_SESSION['FILENAME']) ? $_SESSION['FILENAME'] : "***");
	$cfgSetupView = (isset($_SESSION['LASTSMTSETUPSHEETVIEW']) ? $_SESSION['LASTSMTSETUPSHEETVIEW'] : "None");
	$cfgSetupSheetName = (isset($_SESSION['SMTSetupSheetName']) ? $_SESSION['SMTSetupSheetName'] : "Block");
	$cfgReservedPara = (isset($_SESSION['iLASTSMTSETUPSHEETLOG']) ? $_SESSION['iLASTSMTSETUPSHEETLOG'] : "Block");
?>

<html>
	<head>	
		<title>MPH</title>			
		<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			
			<link rel="stylesheet" href="/javaScripts/bootstrap.min.css"> 
			
			<script src="/javaScripts/jquery-1.12.4.min.js"></script>
			<script type="text/javascript" src="/javaScripts/jsapi.js"></script>
			<script src="/javaScripts/bootstrap.min.js"></script>
			
		<script>
			function openForm() {
				document.getElementById("prodlotsizeid-popup").style.display = "block";
				document.getElementById("idSMTPRODLOTSIZEID").focus();
				document.getElementById("idSMTPRODLOTSIZEID").select();
			}

			function closeForm() {
				document.getElementById("prodlotsizeid-popup").style.display = "none";
			}
		</script>
		
		<script type="text/javascript">
			
		</script>

		<script>
			function showHint(str) {
				if (str.length == 0) {
						document.getElementById("txtHint").innerHTML="";
						return;
				}
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
							document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
						}
				}
				xmlhttp.open("GET","SCTmsSQL_GetNote.php?q="+str,true);
				xmlhttp.send();
			}
		</script>

		<script>
			function ShowLastSMTSetupSheetName(strSMTSetupSheetName) {
				document.getElementById("idLastSMTSetupSheetLog").style.display = "Block";
				
				if (strSMTSetupSheetName.length==0) {
						document.getElementById("idSMTSetupSheetName").innerHTML="";
						return;
				}
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState==4 && xmlhttp.status==200) {	
							document.getElementById("idSMTSetupSheetName").innerHTML=xmlhttp.responseText;
						}
				}
				
				xmlhttp.open("GET","SMT_ShowLastSMTSetupSheetName.php?q="+strSMTSetupSheetName,true);
				xmlhttp.send();
				
				
				location.reload();
			}
		</script>

		<script>
			function GetUserInput(intWarning, strFileName, $cfgSetupView, reservedPara) {	
				if (intWarning == 10) {
					alert("Sorry, The System Can Not Create SMT Production Lot Size ID For New Lot!");
					document.getElementById("idStartNewLS").focus();
					document.getElementById("idStartNewLS").select();
				}
				
				if (intWarning == 1) {
					alert("Sorry, file already exists!");
					document.getElementById("fileToUpload").focus();
					document.getElementById("fileToUpload").select();
				}
				
				if (intWarning == 2) {
					alert("Sorry, your file is too large!");
					document.getElementById("fileToUpload").focus();
					document.getElementById("fileToUpload").select();
				}
				
				if (intWarning == 3) {
					alert("Sorry, there was an error uploading your file! Please select a file again!");
					document.getElementById("fileToUpload").focus();
					document.getElementById("fileToUpload").select();
				}
				
				if (intWarning == 4) {
					alert("Please input the correct value of SMT Production Lot Size ID!");
					document.getElementById("idSMTPRODLOTSIZE").focus();
					// document.getElementById("idSMTPRODLOTSIZEID").focus();
					// document.getElementById("idSMTPRODLOTSIZEID").select();
				}
				
				if (intWarning == 5) {
					alert("Sorry, the SMT Production Lot Size ID is not found!");			
					document.getElementById("idSMTPRODLOTSIZE").focus();
					// document.getElementById("idSMTPRODLOTSIZEID").focus();
					// document.getElementById("idSMTPRODLOTSIZEID").select();
				}
				
				if (intWarning == 6) {
					if (reservedPara == "???"){
						alert("Current SMT Setup Sheet: " + reservedPara + "." + "\n" + "Please select a SMT Setup Sheet firstly before startning new lot size!");			
						document.getElementById("idLastSMTSetupSheetLog").focus();
						document.getElementById("idLastSMTSetupSheetLog").select();
					}
				}
				
				if (intWarning == 99) {					
					alert("The file **" + strFileName + "** has been uploaded!");
					document.getElementById("fileToUpload").focus();
					document.getElementById("fileToUpload").select();
				}
			}
			
			function OnLoadFunction($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgSetupSheetName, $cfgReservedPara) {
				var varLastSMTSetupSheetLog = document.getElementById("idLastSMTSetupSheetLog");
				if ($cfgSetupView == "None"){			
					varLastSMTSetupSheetLog.style.display = "None";
				}
				else{
					varLastSMTSetupSheetLog.style.display = "Block";
				}
				GetUserInput($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgReservedPara);
				
			}
		</script>
	</head>	
	<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgFileName . "'"; ?>,<?php echo "'" . $cfgSetupView . "'"; ?>,<?php echo "'" . $cfgSetupSheetName . "'"; ?>,<?php echo "'" . $cfgReservedPara . "'"; ?>)" >
			
		
		<div class="row content">
			<div class="col-md-3 sidenav">
				<?php 
					include("index.php");
				?> 
			</div>
			
			<div class="main col-md-9">
				<div>
					<div class="panel panel-success" style="margin-right: 10;">
						<div class="panel-heading" style="text-align: center; font-size: 29pt; clear:both;font-weight:bold">SMT PRODUCTION LOT SIZE PREPARATION MODULE</div>
					</div>
				</div>
				<div style="text-align: left;">
					<form name="SMT_RunningProdLotSizeFrom" action="SMT_RunningProdLotSizeAction.php" style="display: inline; margin: 0;" method="POST">
						<div class="row content" style="padding:20px;">
												
							<?php 	
								echo $_SESSION['sWARNING'];
								echo "</br>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

								echo "<tr>";
								echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								echo "SMT LOCATION:";
								echo "</span><h4></td>";
								echo "<td>";
							?>
								<input type="text" name="txtSMTPRODLOTSIZE" id="idSMTPRODLOTSIZE" placeholder="SMT Location" value="<?= $_SESSION['SMTPRODLOTSIZE'] ; ?>"  style="color:blue; font-size: 15pt;width:160px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
							<?php					
								echo "</td></tr>";							
							?>							
								</div>							
							<?php
								echo "</br>";
								echo "</br>";
								
								// echo $_SESSION['LASTSMTSETUPSHEETVIEW'];
								// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
								
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "<tr>";							
								echo "<td>";
								echo "</br>";
							?>
							
								<b><input id="idStartNewLS" class="btn btn-outline" type="submit" name="buttProdLotSizePrep" value="Start New Lot Size" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold" /></b>
								
							<?php	
								echo "</td></tr>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								
								// echo "<tr>";
								// echo "<td>";							
								// echo "</br>";
								// echo "</br>";
								// echo "</br>";
								// echo "</br>";
								// echo "</br>";
							?>			
								<!--
								<b><input id="idUpdateLS" class="btn btn-outline" type="submit" name="buttProdLotSizePrep" value="Update A Lot Size" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;"/></b>
								-->
							<?php	
								// echo "</td></tr>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)
							?>
								<!-- <table class="beta1" style="width:460px;"> -->
							<?php 
								// echo "<tr>";
								// echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								// echo "SMT PROD. LOT ID:";
								// echo "</span><h4></td>";
								// echo "<td>";
							?>
								<!-- 
								
								-->
							<?php					
								// echo "</td></tr>";
							?>
								<!-- </table> -->
							
							
						</div>	
					</form>
				</div>
				
				<div style="text-align: left;">
					<div style="display: inline; margin: 0;">
						<div class="row content" style="padding:20px;">											
							<button id="idSMTPRODLOTSIZE" class="btn btn-outline" class="open-button" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;" onclick="openForm()">Update A Lot Size</button>
							
							<div class="form-popup" id="prodlotsizeid-popup">
								<form action="SMT_ProdLotSizePreparationAction.php" class="prodlotsizeid-form" id="prodlotsizeid-form" method="POST">
									<h1>INPUT SPECIFIC SMT PRODUCTION LOT SIZE ID</h1>
								<?php
									echo "Status: " . $_SESSION['sWARNING'];
									echo $_SESSION['iPRODLOTSIZEPREP'];
									echo "</br>";
									// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
								?>
									<table class="beta1" style="width:360px;">
								<?php 										
									///==========================================================================
									//==========================================================================					
									//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

									echo "<tr>";								
									echo "<td>";
								?>
									<input class="inputBox" type="text" name="txtSMTPRODLOTSIZEID" id="idSMTPRODLOTSIZEID" placeholder="SMTPLOT***" value="<?= $_SESSION['SMTPRODLOTSIZE'] ; ?>"  maxlength = "14" style="color:blue; font-size: 15pt;width:260px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
								<?php					
									echo "</td></tr>";
									echo "</br>";
									echo "</br>";
									echo "</br>";
									
									
								?>
									</table>
									<input class="btn" type="submit" id="idGO" name="buttProdLotSizePrep" value="GO"/>
									<!-- <button name="buttProdLotSizePrep" type="submit" class="btn">GO</button> -->
									<button type="button" class="btn cancel" onclick="closeForm()">Close</button>
								</form>
							</div>	
						</div>	
					</div>
				</div>				
			</div>
		</div> 
	<body>
</html>
<?php
	// if (!empty($_POST["GO"])) {
		// $_SESSION['SMTPRODLOTSIZE'] = trim($_POST['txtSMTPRODLOTSIZEID']);
			
		// if (strlen($_SESSION['SMTPRODLOTSIZE']) <= 0) {
			// $_SESSION['sWARNING'] = 3;		
			// header ("Location: SMT_ProdLotSizePreparation.php");
			// exit();
		// }
	// }
?>