<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
?>

<script>
	function ShowSMTSetupSheetName(strSMTSetupSheetLogName) {
		if (strSMTSetupSheetLogName.length==0) {
				document.getElementById("idSMTSetupSheetNameLog").innerHTML="";
				return;
		}
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("idSMTSetupSheetNameLog").innerHTML=xmlhttp.responseText;
				}
		}
		
		alert("The Setup Sheet **" + strSMTSetupSheetLogName + "** has been downloaded!");
		xmlhttp.open("GET","SMT_ShowSMTSetupSheetLog.php?q="+strSMTSetupSheetLogName,true);
		xmlhttp.send();
	}
</script>


<script>
	function GetUserInput(intWarning, strFileName, $cfgSetupView, reservedPara) {	
		if (intWarning == 10) {
			alert("Sorry, length of filename is not allowed to over 60 characters!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 1) {
			alert("Sorry, file already exists!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 2) {
			alert("Sorry, your file is too large!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 3) {
			alert("Sorry, there was an error uploading your file! Please select a file again!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 99) {
			alert("The file **" + strFileName + "** has been uploaded!");
			document.getElementById("fileToUpload").focus();
			document.getElementById("fileToUpload").select();
		}
	}
	
	function OnLoadFunction($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgSetupSheetName, $cfgReservedPara) {
						
		//GetUserInput($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgReservedPara);
		
		
	}
</script>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgFileName = (isset($_SESSION['FILENAME']) ? $_SESSION['FILENAME'] : "***");
	$cfgSetupView = (isset($_SESSION['SETUPSHEETUPLOADVIEW']) ? $_SESSION['SETUPSHEETUPLOADVIEW'] : "***");
	$cfgSetupSheetName = (isset($_SESSION['SMTSetupSheetName']) ? $_SESSION['SMTSetupSheetName'] : "Block");
	$cfgReservedPara = "";
?>

<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgFileName . "'"; ?>,<?php echo "'" . $cfgSetupView . "'"; ?>,<?php echo "'" . $cfgSetupSheetName . "'"; ?>,<?php echo "'" . $cfgReservedPara . "'"; ?>)" >
	<div class="row content">
        <div class="col-md-3 sidenav">
			<?php 
				include("index.php");
			?> 
		</div>
		
		<div class="col-md-9">
			<div class="panel panel-success" style="margin-right: 20px;">
				<div class="panel-heading" style="text-align:center; color:white; font-size:24pt; float:center; clear:both; font-weight:bold">SMT PRODUCTION LOT SIZE PREPARATION MODULE</div>
			</div>
			<div>
				<form name="SMTProdLotSizeTraceability" action="SMT_ProdLotSizeTraceabilityAction.php" style="display: inline; margin: 0;" method="POST" enctype="multipart/form-data">
					<div class="row content">
						<div class="col-md-6" style="padding-top: 20px;">						
							<?php 		
								// echo $_SESSION['SETUPSHEETUPLOADVIEW'];
								// echo "<table id='idSMTProdLotSizeTraceability' style=\"border:0;\">";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
							?>
								<div>
							<?php
								echo "<tr><td><span style=\"width:360px; color:white;background-color:blue;font-weight:bold\">";
								echo "SMT Part Number: ";
								echo "</span></td><td>";
							
							?>
								</div>
								<div>
								<input type="text" name="txtSMTPARTNUMBER" id="idSMTPARTNUMBER" value="<?= $_SESSION['iSMTPARTNUMBER'] ; ?>"  maxlength = "12" style="font-size: 12pt;width:290px; height:26px;color:red;font-weight:bold;background-color:yellow;clear:right"/>
								</div>
								<div>
							<?php					
								echo "</td></tr>";
								echo "</br>";
								echo "</br>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "<tr><td><span style=\"width:360px; color:white;background-color:blue;font-weight:bold\">";
								echo "SMT Part Qty: ";
								echo "</span></td><td>";
							
							?>
								</div>
								<div>
								<input type="text" name="txtSMTPARTNUMBER" id="idSMTPARTNUMBER" value="<?= $_SESSION['iSMTPARTQTY'] ; ?>"  maxlength = "12" style="font-size: 12pt;width:290px; height:26px;color:red;font-weight:bold;background-color:yellow;clear:right"/>
								</div>
								<div>
							<?php					
								echo "</td></tr>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								
								echo "<tr>";
								echo "<td>";							
								echo "</br>";
								echo "</br>";
								echo "</br>";
								echo "</br>";
								echo "</br>";
							?>			
								<?//============SET UP THE INPUT BOX HERE FOR SCANNING SMPN?>
								<b><input class="btn btn-outline" type="submit" name="csvData" value="Update Lot Size Preparation" style="color:blue; font-size: 12pt;width:290px; height:36px;float:center;clear:both;font-weight:bold;"/></b>
							<?php	
								echo "</td></tr>";
								
								
							?> 
						</div>
						
						<div class="col-md-6">
							<div id = 'idProdLotSizeTraceability'>
								<?php 
																		
								?>	
							</div>							
						</div>
					</div>	
				</form>
			</div>
		</div>
    </div> 
<body>