USE [DLVNDB]
GO

/****** Object:  Table [dbo].[SMTProdLotSizePreparation]    Script Date: 11/04/2020 10:09:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SMTProdLotSizePreparation](
	[ProdLotSizeID] [char](15) NOT NULL,
	[PartNumber] [char](30) NOT NULL,
	[PartQty] [int] NOT NULL,
	[ProdLotSizeTime] [smalldatetime] NOT NULL,
	[ProdLotSizePIC] [char](30) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SMTProdLotSizePreparation] ADD  CONSTRAINT [DF_SMTProdLotSizePreparation_ProdLotSizeTime]  DEFAULT (getdate()) FOR [ProdLotSizeTime]
GO

ALTER TABLE [dbo].[SMTProdLotSizePreparation] ADD  CONSTRAINT [DF_SMTProdLotSizePreparation_ProdLotSizePIC]  DEFAULT ('None') FOR [ProdLotSizePIC]
GO


