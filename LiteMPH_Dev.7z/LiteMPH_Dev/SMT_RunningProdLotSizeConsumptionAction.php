<?php
	session_start();
	
	$_SESSION['iCOUNTERCONTROL'] = trim($_POST['CounterControl']);
	// $_SESSION['iRUNPRODLOTSIZE'] = trim($_POST['RunProductionLotSize']);
	
	// $_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'];
	// $_SESSION['iSMTPRODLOTSIZEQTY'];
	// **********************************************************************
	// **********************************************************************
	// Access the quantity from IoT ADAM Counter;
	if ($_SESSION['iCOUNTERCONTROL'] == "MANUAL RESET COUNTER"){
		require_once("SMT__ADAM6060_Reset_Counter.php");
	}
	// else{
		$_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] = 0;
		require_once("SMT__ADAM6060_Get_Quantity.php");
		
		$myServer = $_SESSION['ServerInstanceName'];
		$myUser = $_SESSION['ServerUserName'];
		$myPass = $_SESSION['ServerPassword'];
		$myDB = $_SESSION['ServerDB'];
		$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
		
		//connection to the database
		$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
							or die("Couldn't connect to SQL Server on $myServer");						
			
			
		$query = "UPDATE [dbo].[SMTMachineMonitoring] SET [IoTCounterQty] = '" . $_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] . "', [IoTData] ='1', LastUpdate = GETDATE()"
					. " WHERE [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'"
					. " AND [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
					
		$_SESSION['iQUERRY'] = $query;

		//execute the SQL query and return records
		sqlsrv_query($dbhandle,$query);
		//display the results
		
		
		$query = "SELECT TOP(1) * FROM [dbo].[SMTMachineMonitoring] WHERE [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'"
					. " AND [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";

		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		//display the results
		
		$getIoTControlStatus = 0;
		While($row = sqlsrv_fetch_array($result)){
			$getIoTControlStatus = (int)($row['IoTControlStatus']);
		}
		
		sqlsrv_close($dbhandle);
		
		
		$_SESSION['iIOTCONTROLSTATUS'] = $getIoTControlStatus;
		switch ($_SESSION['iIOTCONTROLSTATUS']){
			case 0:
				$_SESSION['iRESETCOUNTER'] = 0;
				$_SESSION['iADAM6256Status'] = "false";		
				require_once("SMT__ADAM6256_Stop_Conveyor.php");
				break;
			case 1:
				// Stop Conveyor
				$_SESSION['iRESETCOUNTER'] = 0;
				$_SESSION['iADAM6256Status'] = "true";		
				require_once("SMT__ADAM6256_Stop_Conveyor.php");
				break;
			case 2:
				// Stop Conveyor & Reset Counter
				$_SESSION['iRESETCOUNTER'] = 1;
				$_SESSION['iADAM6256Status'] = "true";		
				require_once("SMT__ADAM6256_Stop_Conveyor.php");
				// require_once("SMT__ADAM6060_Reset_Counter.php");
				break;
		}
	// }
	
	
	$_SESSION['iPREVIOTCONTROLSTATUS'] = $_SESSION['iIOTCONTROLSTATUS'];
	header ("Location: SMT_RunningProdLotSizeConsumption.php");
?>