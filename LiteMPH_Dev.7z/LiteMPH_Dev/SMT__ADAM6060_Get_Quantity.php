<?php
	@session_start();
	
	// $_SESSION['iADAM6060IP'] = "192.168.1.11";
	// $_SESSION['iADAM6060Port'] = 502;
		
	$_SESSION['iIODATA'] = 	"IP_Adam_ON_OFF=" . $_SESSION['iADAM6060IP'] . "&" . 
							"Port=" . $_SESSION['iADAM6060Port'];
	
	echo $_SESSION['iIODATA'];
	echo "</br>";
	echo "</br>";
	
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'http://localhost:8081/api/Conveyor/Get_Quantity',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'POST',
	  CURLOPT_POSTFIELDS => $_SESSION['iIODATA'],
	  CURLOPT_HTTPHEADER => array(
		'Content-Type' => 'application/json',
	  ),
	));

	$response = curl_exec($curl);
	
	if ($response === false) {
		$info = curl_getinfo($curl);
		curl_close($curl);
		
		die(var_export($info));
	}
	else{
		curl_close($curl);
	}
		
	$var = json_decode($response, TRUE);
	
	$status = ($var[0]);
	
	if ($status == "Successful"){
		echo ($var[1]);
		$_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] = (int)($var[1]);
	}
	// else{
		// echo "Error";
	// }
?>
