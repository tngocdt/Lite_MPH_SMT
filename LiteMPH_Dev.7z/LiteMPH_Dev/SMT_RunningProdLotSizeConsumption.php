<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
?>

<script type="text/javascript" src="/javaScripts/jquery-1.12.4.min.js">
	$(document).ready(function() {		
		$("#SMT_SetupSheetForm").on("submit", function () {

			$("#response").attr("class", "");
			$("#response").html("");
			var fileType = ".csv";
			var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
			if (!regex.test($("#file").val().toLowerCase())) {
					$("#response").addClass("error");
					$("#response").addClass("display-block");
				$("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
				return false;
			}
			return true;
		});
	});
	
	<style>
		table {
			border-collapse: collapse;
		}
		
		table {border: none;}
	</style>
</script>

<script language="JavaScript" type="text/javascript"> 
	function AutoSubmit(){
		document.SMT_RunningProdLotSizeConsumptionForm.submit();
	} 
	
	setInterval('AutoSubmit()', 5000); // refresh div after 60 secs
 </script>
 
<script language="JavaScript" type="text/javascript"> 
	function ProgressCompletionStatus(intSMTProdLotSizeQty, intSMTProdLotSizeComplete) {
		var elem = document.getElementById("myBar");
		var width = 0
		if (intSMTProdLotSizeQty > 0){
			var width = (intSMTProdLotSizeComplete/intSMTProdLotSizeQty)*100;
		}
		
		elem.style.width = width + "%";
		elem.innerHTML = width  + "%";
	}
 </script>
 
<script language="JavaScript" type="text/javascript"> 
	$(document).ready(function () {
		if (localStorage.getItem("colorSwapState") == "swap"){
			// $('#sidebar').addClass('active');
			var x = document.getElementById("infor")
			if (x.style.display === "none") {
				x.style.display = "block";
			} 
			else{
				x.style.display = "none";
			}
			
			var y = document.getElementById("sidebar")
			if (y.style.display === "none") {
				y.style.display = "block";
			} 
			else{
				y.style.display = "none";
			}
		}
		
		$('#sidebarCollapse').click(function () {
			if (localStorage.getItem("colorSwapState") == "swap") {
			  localStorage.removeItem("colorSwapState");
			} 
			else {
			  localStorage.setItem("colorSwapState", "swap");
			}
			
			// $('#sidebar').toggleClass('active');
			var x = document.getElementById("infor")
			if (x.style.display === "none") {
				x.style.display = "block";
			} 
			else{
				x.style.display = "none";
			}
			
			// document.getElementById("infor").style.display = "block";
			var y = document.getElementById("sidebar")
			if (y.style.display === "none") {
				y.style.display = "block";
			} 
			else{
				y.style.display = "none";
			}
		});
		
	});
</script>


<script>
	function GetUserInput(intWarning, strPartNumber, strLastSMTSetupSheet, reservedPara){
		if (intWarning == 0){
			// alert("Refresh Page");
			// document.getElementById("idSMTLOCATION").focus();
			// document.getElementById("idSMTLOCATION").select();
		}
		
		if (intWarning == 10) {
			// alert("Sorry, length of filename is not allowed to over 60 characters!");
			// document.getElementById("fileToUpload").focus();
			// document.getElementById("fileToUpload").select();
		}
		
		if (intWarning == 6) {
			// document.getElementById("idSMTLOCATION").focus();
			// document.getElementById("idSMTLOCATION").select();
		}
		
		if (intWarning == 7) {
			// alert("The SMT Location is not in the last SMT Setup Sheet **" + strLastSMTSetupSheet + "**");
			// document.getElementById("idSMTLOCATION").focus();
			// document.getElementById("idSMTLOCATION").select();
		}
		
		if (intWarning == 1) {
			// document.getElementById("idSMTPARTNUMBER").focus();
			// document.getElementById("idSMTPARTNUMBER").select();
		}
		
		if (intWarning == 2) {
			// document.getElementById("idSMTPARTQTY").focus();
			// document.getElementById("idSMTPARTQTY").select();
		}
		
		if (intWarning == 3) {
			// document.getElementById("idSMTPARTQTY").focus();
			// document.getElementById("idSMTPARTQTY").select();
		}
		
		if (intWarning == 4) {
			// alert("The quantity is not allowed higher 500,000 pcs!");
			// document.getElementById("idSMTPARTQTY").focus();
			// document.getElementById("idSMTPARTQTY").select();
		}
		
		if (intWarning == 5) {
			// alert("The part number **" + strPartNumber + "** is not in the SMT setup sheet!");
			// document.getElementById("idSMTPARTNUMBER").focus();
			// document.getElementById("idSMTPARTNUMBER").select();
		}
		
		if (intWarning == 9) {
			// alert("The location of part number **" + strPartNumber + "** is not in the SMT setup sheet!");
			// document.getElementById("idSMTPARTNUMBER").focus();
			// document.getElementById("idSMTPARTNUMBER").select();
		}
		
		if (intWarning == 99) {
			// alert("The file **" + strPartNumber + "** has been uploaded!");
			// document.getElementById("idSMTPARTNUMBER").focus();
			// document.getElementById("idSMTPARTNUMBER").select();
		}
	}
	
	function OnLoadFunction($cfgUserInputonLoad, $cfgPartNumber, $cfgLastSMTSetupSheet, $cfgSMTProdLotSizeQty, $cfgSMTProdLotSizeComplete, $cfgReservedPara) {
		GetUserInput($cfgUserInputonLoad, $cfgPartNumber, $cfgLastSMTSetupSheet, $cfgReservedPara);		
		ProgressCompletionStatus($cfgSMTProdLotSizeQty, $cfgSMTProdLotSizeComplete);		
	}
</script>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgPartNumber = (isset($_SESSION['iSMTPARTNUMBER']) ? $_SESSION['iSMTPARTNUMBER'] : 0);
	$cfgLastSMTSetupSheet = (isset($_SESSION['iLASTSMTSETUPSHEETLOG']) ? $_SESSION['iLASTSMTSETUPSHEETLOG'] : "???");
	$cfgSMTProdLotSizeQty = (isset($_SESSION['iSMTPRODLOTSIZEQTY']) ? $_SESSION['iSMTPRODLOTSIZEQTY'] : 0);
	$cfgSMTProdLotSizeComplete = (isset($_SESSION['iSMTPRODLOTSIZECOMPLETEQTY']) ? $_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] : 0);
	$cfgReservedPara = "";
?>

<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgPartNumber . "'"; ?>,<?php echo "'" . $cfgLastSMTSetupSheet . "'"; ?>,<?php echo "'" . $cfgSMTProdLotSizeQty . "'"; ?>,<?php echo "'" . $cfgSMTProdLotSizeComplete . "'"; ?>,<?php echo "'" . $cfgReservedPara . "'"; ?>)" >
	
	<!-- <div class="row content"> -->
	<div class="wrapper">
		
        <!-- <div class="col-md-3 sidenav"> -->
		<nav id="sidebar">
			<?php 
				include("index.php");
			?> 
		</nav>
		<!-- </div> -->
		
		<!-- <div class="main col-md-9"> -->
		<div id="content">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<div class="container-fluid">
					<button type="button" id="sidebarCollapse" class="btn btn-info">
						<i class="fas fa-align-left"></i>
						<!-- <span>Toggle Sidebar</span> --> 
						<span><img style="width:25px; " src="Medias/RunningMan.gif" alt="Image 3" /></span>
					</button>

				</div>
			</nav>
			<div>
				<div class="panel panel-success">
					<div class="panel-heading" style="text-align: center; font-size: 29pt; clear:both;font-weight:bold">SMT PRODUCTION LOT SIZE REAL-TIME MONITORING MODULE</div>
				</div>
			</div>
			
			<div id="infor">
				<?php 
					echo "<h3>";
					echo "NEW SMT PROD LOT SIZE ID: " . $_SESSION['iSMTPRODLOTSIZEID'];
					echo "</br>";
					echo "Last SMT Setup Sheet: " . $_SESSION['iLASTSMTSETUPSHEETLOG'] . "(" . $_SESSION['IDSMTSetupSheetLog'] . ")";	
					echo "</h3>";
					echo "Status: " . $_SESSION['sWARNING'] . " - " . date('Y-m-d H:i');
					echo "</br>";
					echo $_SESSION['iCOUNTERCONTROL'];
					// echo $_SESSION['iQUERRY'];
					echo "</br>";
					echo "Machine Name: " . $_SESSION['SMTMACHINENAME'] . " - " . $_SESSION['IoTCONTROLRATE'];
				?>				
			</div>			
			
			
			<div>
				<form name="SMT_RunningProdLotSizeConsumptionForm" action="SMT_RunningProdLotSizeConsumptionAction.php" style="display:inline; margin:0;" method="POST">
					
					<!-- <div class="row content"> -->
						<div class="col-md-3" style="text-align:left; margin-left:0;">							
							<div>
								<p>
								<?php 
									require_once("SMT_ShowProdLotSizeTraceabilityV3.php");	
									// require_once("SMT_ShowSMTSetupSheetLog.php"); 
								?>	
								<!-- <img src="Medias/RunningMan.gif" alt="Image 3" /> --> 
								</p>
							</div>								
							<?php 				
								// echo $_SESSION['iQUERRY'];
								// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
							?>
								<table class="beta1" style="text-align:left; margin-left:-15px; margin-right:auto; width:100%">
							<?php 	
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

								echo "<tr>";
								// echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								// echo "SMT LOCATION:";
								// echo "</span><h4></td>";
								echo "<td>";
							?>
								<b><input class="btn btn-outline" type="submit" name="CounterControl" value="MANUAL RESET COUNTER" style="color:blue; font-size: 12pt;width:100%; height:36px;float:center;clear:both;font-weight:bold;"/></b>
							<?php					
								echo "</td></tr>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

								echo "<tr>";
								// echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								// echo "SMT PART NUMBER:";
								// echo "</span><h4></td>";
								echo "<td>";
							?>
								<!-- <input type="text" name="txtSMTPARTNUMBER" id="idSMTPARTNUMBER" placeholder="123-45-678" value="<?= $_SESSION['iSMTPARTNUMBER'] ; ?>"  maxlength = "12" style="color:blue; font-size: 15pt;width:160px; height:32px; font-weight:bold;background-color:yellow;clear:right"/> -->
							<?php					
								echo "</td></tr>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)
								echo "<tr>";
								// echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								// echo "SMT PART QTY:";
								// echo "</span><h4></td>";
								echo "<td>";
								
							?>
								<!-- <input type="text" name="txtSMTPARTQTY" id="idSMTPARTQTY" placeholder="0" value="<?= $_SESSION['iSMTPARTQTY'] ; ?>"  maxlength = "9" style="color:red; font-size: 15pt;width:110px; height:32px; font-weight:bold;background-color:yellow;clear:right"/> -->
							<?php					
								// echo " (pcs)";
								echo "</td></tr>";
								
							?>
								</table>
							<?php
								// echo "Previous SMT Location - Part Number - Qty: " . $_SESSION['iPrevSMTLOCATION'] . " - " . $_SESSION['iPrevSMTPARTNUMBER'] . " - " . $_SESSION['iPrevSMTPARTQTY'] . "(pcs)";
							?>
								<table class="beta1">
								
							<?php
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								// echo $_SESSION['iQUERRY'];
								echo "<tr><td>";							
								
							?>			
								
								<!-- <input class="btn btn-outline" type="submit" name="ComponentTraceability" value="Record Component Traceability" style="color:blue; font-size: 12pt;width:360px; height:36px;float:center;clear:both;font-weight:bold;"/> -->
							<?php	
								echo "</td></tr>";
							?>
								</table>
						</div>
						<div class="col-md-9" style="border:1px solid black; text-align:center ;margin-left:0; margin-right:0";>								
							<div>
								<p>
									<div id="myProgress">
										<div id="myBar">0%</div>
									</div>
							<?php 
										require_once("SMT_ShowProdLotSizeTraceabilityV2.php");	
										// require_once("SMT_ShowSMTSetupSheetLog.php"); 
							?>	
								</p>
							</div>
						</div>
						
					<!-- </div>	-->
				</form>
				
			</div>
		</div>
    </div> 
<body>