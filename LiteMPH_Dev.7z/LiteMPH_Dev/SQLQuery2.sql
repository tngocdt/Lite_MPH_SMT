USE [DLVNDB]
GO

/****** Object:  StoredProcedure [dbo].[speleanAIms_AccessSMTProdLotSize]    Script Date: 11/04/2020 10:08:25 PM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[speleanAIms_AccessSMTProdLotSize] @result char(20) OUT
AS
--DECLARE
	DECLARE @dt datetime
	DECLARE @pYEAR char(2)
	DECLARE @tmpYEAR char(2)

	DECLARE @tMonth char(1)
	DECLARE @tmpMonth char(2)

	DECLARE @tDay char(1)	
	DECLARE @tmpDay char(2)

	DECLARE @prefix char(4)
	DECLARE @tmpPrefix char(4)
	DECLARE @tmpNumber char(3)
	DECLARE @tmpNumberid char(20)
	
	SET NOCOUNT ON

BEGIN
	SET @dt=GETDATE()
	SET @pYEAR=left(CONVERT(char(4),YEAR(@dt)),2)
	SET @tmpYEAR=right(CONVERT(char(4),YEAR(@dt)),2)
	SET @tmpMonth=CONVERT(char(2),MONTH(@dt))
	SELECT @tMonth=strMonth FROM [dbo].[MonthTable] WHERE intMonth=@tmpMonth
	SET @tmpDay=CONVERT(char(2),DAY(@dt))
	SELECT @tDay=strDay FROM [dbo].[DayTable] WHERE intDay=@tmpDay

	-- get the current system day
	SET @prefix=@tmpYEAR+@tMonth+@tDay

	-- get the day(YEAR + month + day) stored day in database
	SELECT @tmpPrefix=Prefix FROM [dbo].[SMTProdLotSizeID]		

	-- if the system day is different FROM the day stored in database
	if (@tmpPrefix<>@prefix)
		BEGIN
			SET @tmpNumber=0
			UPDATE [dbo].[SMTProdLotSizeID] SET Prefix=@prefix,Number=@tmpNumber
		END

	SELECT @tmpNumber=Number FROM [dbo].[SMTProdLotSizeID]
	UPDATE [dbo].[SMTProdLotSizeID] SET Number=CONVERT(int,@tmpNumber)+1

	SELECT @tmpNumber=Number, @tmpPrefix=Prefix FROM [dbo].[SMTProdLotSizeID]
	SET @tmpNumber=CONVERT(int,@tmpNumber)
	SET @tmpNumberid='SMTPLOT' + rtrim(ltrim(@tmpPrefix))+right('000'+rtrim(ltrim(@tmpNumber)),3)

	SET @result=rtrim(ltrim(@tmpNumberid))
	SELECT @result AS Result

END

/*
DECLARE @result char(20)
EXEC [dbo].[AccessSMTProdLotSize] @result
*/

GO


