<?php
	@session_start();
		
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	
	$myDB = $_SESSION['ServerDB'];
	
	$_SESSION['IDSMTSETUPSHEET'] = 0;
	
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbcnn = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
				or die("Couldn't connect to SQL Server on $myServer");

	// the following code segment will get the ID for reel component
	$getIDSMTSETUPSHEET = 0;	// initial the REELID
		
	$params = array(
		array(&$_SESSION['SMTSetupSheetName'], SQLSRV_PARAM_IN),
		array(&$_SESSION['SMTSetupSheetLogName'], SQLSRV_PARAM_IN),
		array(&$getIDSMTSETUPSHEET, SQLSRV_PARAM_OUT,SQLSRV_PHPTYPE_INT)
	);
	
	$sql = "EXEC [dbo].[speleanAIms_UpdateSMTSetupSheetMasterList] @iSMTSetupSheetName = ?, @iSMTSetupSheetLogName = ?, @result = ?";		
	// $_SESSION['iQUERRY'] = $sql . "-" . $_SESSION['SMTSetupSheetName'] . "-" . $_SESSION['SMTSetupSheetLogName'];
	$stmt = sqlsrv_query($dbcnn, $sql, $params);
	
	if($stmt === false){  
		echo "Sorry, there was an error in recording setup sheet into database!";
		echo "</br>";
		die( print_r( sqlsrv_errors(), true));  
	}  
	else{
		$rowcount = 0;
		while($row = sqlsrv_fetch_array($stmt)){
			$rowcount = $rowcount + 1;
			$_SESSION['IDSMTSETUPSHEET'] = $row['Result'];
		}
	}
	
	sqlsrv_free_stmt($stmt);
	
	//declare the SQL statement that will query the database
	$query = "SELECT [IDSMTSetupSheetLog] FROM [dbo].[SMTSetupSheetLogControl] WHERE [SMTSetupSheetLogName] = '" . $_SESSION['SMTSetupSheetLogName'] . "'";
	
	// $_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbcnn,$query);

	//display the results
	while($row = sqlsrv_fetch_array($result)){
		$_SESSION['IDSMTSetupSheetLog'] = $row['IDSMTSetupSheetLog'];
	}
	
	sqlsrv_close($dbcnn);	
?>