<!DOCTYPE html>
<html>
	<head>	
		<title>MPH</title>			
		<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="stylesheet" href="/javaScripts/bootstrap.min.css">	
			<script src="/javaScripts/jquery-1.12.4.min.js"></script>
			<script type="text/javascript" src="/javaScripts/jsapi.js"></script>
			<script src="/javaScripts/gstatic.charts.loader.js"></script>
			<script src="/javaScripts/bootstrap.min.js"></script>
			
			
			<script type="text/javascript">
				$('#exampleModal').on('show.bs.modal', function (event) {
					var button = $(event.relatedTarget) // Button that triggered the modal
					var recipient = button.data('whatever') // Extract info from data-* attributes
					// If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
					// Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
					var modal = $(this)
					modal.find('.modal-title').text('New message to ' + recipient)
					modal.find('.modal-body input').val(recipient)
				})
				
				$('#exampleModal').on('shown.bs.modal', function () {
					$('#myInput').trigger('focus')
				})
			</script>
			
			<style>							
				html, body {
					height: 100%;
					margin: 0;
				}
				
				/* Remove the navbar's default margin-bottom and rounded borders */
				.navbar {
					margin-bottom: 0;
					border-radius: 0;
				}

				/* Set height of the grid so .sidenav can be 100% (adjust as needed) */
				/*
				.row.content {
					height: 100%;
				}
				*/

				/* Set gray background color and 100% height */
				.sidenav {
					background-color: #f1f1f1;
					height: 100%;
					font-size: 15px;
					position: fixed;
					width: 420px;
					z-index: 1;
				}	
					
				img {
					border: 1px solid #ddd;
					border-radius: 4px;
					padding: 5px;
					display: block;
					margin-left: 0;
					margin-right: auto;
					max-width: 100%;
					height: auto;
				}
				
				div.main {
					margin-left: 450px;
					padding: 1px 16px;
				}
			</style>
			
			<style type="text/css">
				.different-font-color { color: orange; }
				.different-background-color { background-color: limegreen }	
								
				.btn-outline {
				  color: #4fbfa8;
				  background-color: #ffffff;
				  border-color: #4fbfa8;
				  font-weight: bold;
				  border-radius: 10;
				}
				
				.btn-outline2 {
				  color: #4fbfa8;
				  background-color: #FAFAD2;
				  border-color: #4fbfa8;
				  font-weight: bold;
				  letter-spacing: 0.05em;
				  padding-left:5px;
				  padding-right:5px;
				  padding-top:1px;
				  padding-bottom:1px;
				}

				.btn-outline:hover,
				.btn-outline:active,
				.btn-outline:focus,
				.btn-outline.active {
				  background: #FFFF00;
				  color: #ffffff;
				  border-color: #4fbfa8;
				  
				}


				.btn-colour-1 {
				  color: #fff;
				  background-color: #004E64;
				  border-color: #004E64;
				  font-weight: bold;
				  letter-spacing: 0.05em;
				  border-radius: 0;
				}

				.btn-colour-1:hover,
				.btn-colour-1:active,
				.btn-colour-1:focus,
				.btn-colour-1.active {
				  /* let's darken #004E64 a bit for hover effect */
				  background: #003D4F;
				  color: #ffffff;
				  border-color: #003D4F;
				}

				/* for demo purpose only */

				body {
				  padding: 20px 0;
				  font-family: Roboto, sans-serif;
				}
				
			</style>
							
			<style>
				td { 
					padding: 10px;
				}
				
				.beta th, td {
					border: 1px solid black;
					border-collapse: collapse;
					padding: 3px;
				}
				.beta tr:nth-child(even) {
					background-color: #eee;
				}
				.beta tr:nth-child(odd) {
					background-color: #fff;
				}				
				.beta tr:hover {background-color: #ddd;}				
				.beta th {
					padding-top: 6px;
					padding-bottom: 6px;
					text-align: left;
					background-color: #FF6347;
					color: white;
				}
				
				.beta1 th, td {
					border: none;
					border-collapse: collapse;
				}	
								
			</style>
			
			<style>
				.right {
					float: right;
					margin-right: 20;
				}
			</style>
			
			<style>
				body {font-family: Arial, Helvetica, sans-serif;}
				* {box-sizing: border-box;}

				

				/* The popup form - hidden by default */
				.form-popup {
					display: none;
					position: fixed;
					bottom: 0;
					right: 15px;
					border: 3px solid #f1f1f1;
					z-index: 9;
				}

				/* Add styles to the form container */
				.form-container {
					max-width: 300px;
					padding: 10px;
					background-color: white;
				}

				/* Full-width input fields */
				.form-container input[type=text], .form-container input[type=password] {
					width: 100%;
					padding: 15px;
					margin: 5px 0 22px 0;
					border: none;
					background: #f1f1f1;
				}

				/* When the inputs get focus, do something */
				.form-container input[type=text]:focus, .form-container input[type=password]:focus {
					background-color: #ddd;
					outline: none;
				}

				/* Set a style for the submit/login button */
				.form-container .btn {
					background-color: #4CAF50;
					color: white;
					padding: 16px 20px;
					border: none;
					cursor: pointer;
					width: 100%;
					margin-bottom:10px;
					opacity: 0.8;
				}

				/* Add a red background color to the cancel button */
				.form-container .cancel {
					background-color: red;
				}

				/* Add some hover effects to buttons */
				.form-container .btn:hover, .open-button:hover {
					opacity: 1;
				}
			</style>
			
			<style>
				body {
					color: #232323;
					font-size: 0.95em;    
					font-family: arial;
				}

				div#success {
					text-align: center;
					box-shadow: 1px 1px 5px #455644;
					background: #bae8ba;
					padding: 10px;
					border-radius: 3px;
					margin: 0 auto;
					width: 350px;
				}
				
	
				#prodlotsizeqty-popup {
					position: absolute;
					top: 100px;
					left: 0px;
					height: 100%;
					width: 100%;
					background: rgba(0, 0, 0, 0.5);
					display: none;
					color: #676767;
				}
				

				#prodlotsizeid-popup {
					position: absolute;
					top: 100px;
					left: 0px;
					height: 100%;
					width: 100%;
					background: rgba(0, 0, 0, 0.5);
					display: none;
					color: #676767;
				}
				
				.prodlotsizeqty-class {
					width: 390px;
					margin: 0px;
					background-color: white;
					font-family: Arial;
					position: relative;
					left: 50%;
					top: 50%;
					margin-left: -210px;
					margin-top: -255px;
					box-shadow: 1px 1px 5px #444444;
					padding: 20px 40px 40px 40px;
				}

				.prodlotsizeid-class {
					width: 350px;
					margin: 0px;
					background-color: white;
					font-family: Arial;
					position: relative;
					left: 50%;
					top: 50%;
					margin-left: -210px;
					margin-top: -255px;
					box-shadow: 1px 1px 5px #444444;
					padding: 20px 40px 40px 40px;
				}	
				
				.inputBox {
					width: 100%;
					margin: 5px 0px 15px 0px;
					border: #dedede 1px solid;
					box-sizing: border-box;
					padding: 15px;
				}
				.input-error {
					border: #e66262 1px solid;
				}

			</style>
			
			<style>
				#myProgress {
					width: 100%;
					background-color: #ddd;
				}

				#myBar {
					width: 0%;
					height: 30px;
					background-color: #4CAF50;
					text-align: center;
					line-height: 30px;
					color: white;
				}
			
			</style>
			
			<style>
				#myProgress {
					width: 100%;
					background-color: #ddd;
				}

				#myBar {
					width: 0%;
					height: 30px;
					background-color: #4CAF50;
					text-align: center;
					line-height: 30px;
					color: white;
				}
			</style>
			
			<style>
				body {
					font-family: 'Poppins', sans-serif;
					background: #fafafa;
				}

				p {
					font-family: 'Poppins', sans-serif;
					font-size: 1.1em;
					font-weight: 300;
					line-height: 1.7em;
					color: #999;
				}
				
				
				/* -------------------------------------
				a,
				a:hover,
				a:focus {
					color: inherit;
					text-decoration: none;
					transition: all 0.3s;
				}
				------------------------------------- */
				
				.navbar {
					padding: 15px 10px;
					background: #fff;
					border: none;
					border-radius: 0;
					margin-bottom: 40px;
					box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
				}

				.navbar-btn {
					box-shadow: none;
					outline: none !important;
					border: none;
				}

				.line {
					width: 100%;
					height: 1px;
					border-bottom: 1px dashed #ddd;
					margin: 40px 0;
				}
				
				
				/* ---------------------------------------------------
					SIDEBAR STYLE
				----------------------------------------------------- */
				.wrapper {
					display: flex;
					width: 100%;
					align-items: stretch;
				}

				#sidebar {
					min-width: 420px;
					max-width: 420px;
					background: #7386D5;
					color: #fff;
					transition: all 0.3s;
				}

				#sidebar.active {
					margin-left: -420px;
				}
								
				/* ---------------------------------------
				
				#sidebar .sidebar-header {
					padding: 20px;
					background: #6d7fcc;
				}

				#sidebar ul.components {
					padding: 20px 0;
					border-bottom: 1px solid #47748b;
				}

				#sidebar ul p {
					color: #fff;
					padding: 10px;
				}

				#sidebar ul li a {
					padding: 10px;
					font-size: 1.1em;
					display: block;
				}

				#sidebar ul li a:hover {
					color: #7386D5;
					background: #fff;
				}

				#sidebar ul li.active>a,
				a[aria-expanded="true"] {
					color: #fff;
					background: #6d7fcc;
				}

				a[data-toggle="collapse"] {
					position: relative;
				}

				.dropdown-toggle::after {
					display: block;
					position: absolute;
					top: 50%;
					right: 20px;
					transform: translateY(-50%);
				}

				ul ul a {
					font-size: 0.9em !important;
					padding-left: 30px !important;
					background: #6d7fcc;
				}

				ul.CTAs {
					padding: 20px;
				}

				ul.CTAs a {
					text-align: center;
					font-size: 0.9em !important;
					display: block;
					border-radius: 5px;
					margin-bottom: 5px;
				}

				a.download {
					background: #fff;
					color: #7386D5;
				}

				a.article,
				a.article:hover {
					background: #6d7fcc !important;
					color: #fff !important;
				}
				----------------------------------------------------- */
				
				/* ---------------------------------------------------
					CONTENT STYLE
				----------------------------------------------------- */

				#content {
					width: 100%;
					padding: 20px;
					min-height: 100vh;
					transition: all 0.3s;
				}

				/* ---------------------------------------------------
					MEDIAQUERIES
				----------------------------------------------------- */

			
			</style>

	</head>	
	
</html>