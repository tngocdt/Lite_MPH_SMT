<?php 
	session_start();
	// In your "php.ini" file, search for the file_uploads directive, and set it to On:
	if (isset($_REQUEST["q"])){
		$q = $_REQUEST["q"];
		$_SESSION['sWARNING'] = $q;
		$_SESSION['SMTSetupSheetName'] = "***";
		$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";
		$_SESSION['iSMTPRODLOTSIZEMODEL'] = "";
		$_SESSION['iSMTPRODLOTSIZEQTY'] = "";
	}
?>

<?php
	$cfgUserInputonLoad = (isset($_SESSION['sWARNING']) ? $_SESSION['sWARNING'] : 0);
	$cfgFileName = (isset($_SESSION['FILENAME']) ? $_SESSION['FILENAME'] : "***");
	$cfgSetupView = (isset($_SESSION['LASTSMTSETUPSHEETVIEW']) ? $_SESSION['LASTSMTSETUPSHEETVIEW'] : "None");
	$cfgSetupSheetName = (isset($_SESSION['SMTSetupSheetName']) ? $_SESSION['SMTSetupSheetName'] : "Block");
	$cfgReservedPara = (isset($_SESSION['iLASTSMTSETUPSHEETLOG']) ? $_SESSION['iLASTSMTSETUPSHEETLOG'] : "Block");
?>

<html>
	<head>	
		<title>MPH</title>			
		<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			
			<link rel="stylesheet" href="/javaScripts/bootstrap.min.css"> 
			
			<script src="/javaScripts/jquery-1.12.4.min.js"></script>
			<script type="text/javascript" src="/javaScripts/jsapi.js"></script>
			<script src="/javaScripts/bootstrap.min.js"></script>
			
		<script>
			function openUpdateProdLotSizeForm() {
				document.getElementById("prodlotsizeid-popup").style.display = "block";
				document.getElementById("idSMTPRODLOTSIZEID").focus();
				document.getElementById("idSMTPRODLOTSIZEID").select();
			}

			function closeUpdateProdLotSizeForm() {
				document.getElementById("prodlotsizeid-popup").style.display = "none";
			}
			
			function openStartNewProdLotSizeForm(strSMTSetupSheetName) {
				if (strSMTSetupSheetName == "???"){
					alert("Sorry, please select SMT Setup Sheet Name!");
				}
				else{
					document.getElementById("prodlotsizeqty-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEMODEL").focus();
					document.getElementById("idSMTPRODLOTSIZEMODEL").select();
				}
			}

			function closeStartNewProdLotSizeForm() {
				var strModel = document.getElementById("idSMTPRODLOTSIZEMODEL").value;
				var intQty = parseInt(document.getElementById("idSMTPRODLOTSIZEQTY").value);
				
				if ((strModel.length == 0) || (parseInt(intQty) == 0)){
					alert("Missing declaration for NEW SMT Production Lot Size!");
					if (strModel.length == 0){
						document.getElementById("idSMTPRODLOTSIZEMODEL").focus();
						document.getElementById("idSMTPRODLOTSIZEMODEL").select();
					}
					else{
						document.getElementById("idSMTPRODLOTSIZEQTY").focus();
						document.getElementById("idSMTPRODLOTSIZEQTY").select();
					}
				}
				else{				
					document.getElementById("prodlotsizeqty-popup").style.display = "none";
				}
			}
		</script>
		
		<script language="JavaScript" type="text/javascript"> 
			function AutoSubmit(){
				// ShowSMTSetupSheetName(strSMTSetupSheetLogName);
				document.SMT_ProdLotSizePrepFrom.submit();
			} 
			// setInterval('AutoSubmit()', 5000); // refresh div after 5 secs
		</script>

		<script>
			function ShowLastSMTSetupSheetName(strSMTSetupSheetName) {
				document.getElementById("idLastSMTSetupSheetLog").style.display = "Block";
				
				if (strSMTSetupSheetName.length==0) {
						document.getElementById("idSMTSetupSheetName").innerHTML="";
						return;
				}
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState==4 && xmlhttp.status==200) {	
							document.getElementById("idSMTSetupSheetName").innerHTML=xmlhttp.responseText;
						}
				}
				
				xmlhttp.open("GET","SMT_ShowLastSMTSetupSheetName.php?q="+strSMTSetupSheetName,true);
				xmlhttp.send();
				
				
				// location.reload();
				location.href = "SMT_ProdLotSizePreparation.php";
			}
		</script>

		<script>
			function GetUserInput(intWarning, strFileName, $cfgSetupView, reservedPara) {	
				if (intWarning == 1) {
					alert("Sorry, The System Can Not Create SMT Production Lot Size ID For New Lot!");
					document.getElementById("idSMTPRODLOTSIZENEW").focus();
					document.getElementById("idSMTPRODLOTSIZENEW").select();
				}
								
				if (intWarning == 3) {
					alert("Please input the correct value of SMT Production Lot Size ID!");
					// document.getElementById("idSMTPRODLOTSIZEUPDATE").focus();
					document.getElementById("prodlotsizeid-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEID").focus();
					document.getElementById("idSMTPRODLOTSIZEID").select();
				}
				
				if (intWarning == 4) {
					alert("Please input the correct value of SMT Production Lot Size ID!");
					// document.getElementById("idSMTPRODLOTSIZEUPDATE").focus();
					document.getElementById("prodlotsizeid-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEID").focus();
					document.getElementById("idSMTPRODLOTSIZEID").select();
				}
				
				if (intWarning == 5) {
					alert("Sorry, the SMT Production Lot Size ID is not exist!");			
					// document.getElementById("idSMTPRODLOTSIZEUPDATE").focus();
					document.getElementById("prodlotsizeid-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEID").focus();
					document.getElementById("idSMTPRODLOTSIZEID").select();
				}
				
				if (intWarning == 6) {
					if (reservedPara == "???"){
						alert("Current SMT Setup Sheet: " + reservedPara + "." + "\n" + "Please select a SMT Setup Sheet firstly before startning new lot size!");			
						document.getElementById("idLastSMTSetupSheetLog").focus();
						document.getElementById("idLastSMTSetupSheetLog").select();
					}
				}
				
				if (intWarning == 7) {
					alert("Please input the correct MODEL Number of SMT Production Lot Size!");
					// document.getElementById("idSMTPRODLOTSIZENEW").focus();	
					document.getElementById("prodlotsizeqty-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEMODEL").focus();
					document.getElementById("idSMTPRODLOTSIZEMODEL").select();
				}
				
				if (intWarning == 15) {
					alert("Please input the QUANTITY of SMT Production Lot Size!");
					// document.getElementById("idSMTPRODLOTSIZENEW").focus();	
					document.getElementById("prodlotsizeqty-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEQTY").focus();
					document.getElementById("idSMTPRODLOTSIZEQTY").select();
				}
				
				if (intWarning == 17) {
					alert("Please input the correct number for the QUANTITY of SMT Production Lot Size!");
					// document.getElementById("idSMTPRODLOTSIZENEW").focus();
					document.getElementById("prodlotsizeqty-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEQTY").focus();
					document.getElementById("idSMTPRODLOTSIZEQTY").select();
				}
				
				if (intWarning == 19) {
					alert("The QUANTITY is not allowed higher 50,000 pcs!");
					// document.getElementById("idSMTPRODLOTSIZENEW").focus();
					document.getElementById("prodlotsizeqty-popup").style.display = "block";
					document.getElementById("idSMTPRODLOTSIZEQTY").focus();
					document.getElementById("idSMTPRODLOTSIZEQTY").select();
				}
			}
			
			function OnLoadFunction($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgSetupSheetName, $cfgReservedPara) {
				var varLastSMTSetupSheetLog = document.getElementById("idLastSMTSetupSheetLog");
				if ($cfgSetupView == "None"){			
					varLastSMTSetupSheetLog.style.display = "None";
				}
				else{
					varLastSMTSetupSheetLog.style.display = "Block";
				}
				GetUserInput($cfgUserInputonLoad, $cfgFileName, $cfgSetupView, $cfgReservedPara);
				
			}
		</script>
	</head>	
	<body onload="OnLoadFunction(<?php echo "'" .  $cfgUserInputonLoad . "'"; ?>,<?php echo "'" . $cfgFileName . "'"; ?>,<?php echo "'" . $cfgSetupView . "'"; ?>,<?php echo "'" . $cfgSetupSheetName . "'"; ?>,<?php echo "'" . $cfgReservedPara . "'"; ?>)" >
			
		
		<div class="row content">
			<div class="col-md-3 sidenav">
				<?php 
					include("index.php");
				?> 
			</div>
			
			<div class="main col-md-9">
				<div>
					<div class="panel panel-success" style="margin-right: 10;">
						<div class="panel-heading" style="text-align: center; font-size: 29pt; clear:both;font-weight:bold">SMT PRODUCTION LOT SIZE PREPARATION MODULE</div>
					</div>
				</div>
				<div style="text-align: left;">
					<form name="SMT_ProdLotSizePrepFrom" action="SMT_ProdLotSizePreparationAction.php" style="display: inline; margin: 0;" method="POST">
						<div class="row content" style="padding:10px;">
												
							<?php 	
								echo "Status: " . $_SESSION['sWARNING'];
								echo "</br>";
								echo $_SESSION['LASTSMTSETUPSHEETVIEW'];
								echo "</br>";
								echo $_SESSION['SMTSetupSheetName'];
								echo "</br>";
								echo $_SESSION['iPRODLOTSIZEPREP'];
								//=============================================================
								//=============================================================
								// NEW SECTOR: SHOW LIST OF SMT MACHINE LINE
								echo "<tr>";
								echo "<td><h4>";
								echo "SMT Setup Sheet:";					
								echo "</h4></td>";

								echo "<td><h4>";
								$myServer = $_SESSION['ServerInstanceName'];
								$myUser = $_SESSION['ServerUserName'];
								$myPass = $_SESSION['ServerPassword'];
								$myDB = $_SESSION['ServerDB'];

								$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
								//connection to the database
								$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
											or die("Couldn't connect to SQL Server on $myServer");

								//declare the SQL statement that will query the database
								$query = "SELECT [SMTSetupSheetName], [IDSMTSetupSheet] FROM [dbo].[SMTSetupSheetMasterList] ORDER BY [IDSMTSetupSheet] DESC";
							
								//execute the SQL query and return records
								$result = sqlsrv_query($dbhandle,$query);
								//display the results
							?>
								<select id="idSMTSetupSheetName" name="lstSMTSetupSheetName" style="color:blue; width:390px; height:36px;font-size: 15pt;font-weight:bold;background-color:yellow;" onchange = "ShowLastSMTSetupSheetName(this.value)" >

							<?php		
								echo "<option value='Choose a Setup Sheet Name'>Choose a Setup Sheet Name</option>";
								While($row = sqlsrv_fetch_array($result)){
									if (trim($row['SMTSetupSheetName']) !== trim($_SESSION['SMTSetupSheetName'])){
										echo "<option value='" . trim($row['SMTSetupSheetName']) . "'>" . trim($row['SMTSetupSheetName']) . "</option>";
									}
									else{
										echo "<option value='" . trim($row['SMTSetupSheetName']) . "' selected>" . trim($row['SMTSetupSheetName']) . "</option>";
									}					
								}			
								sqlsrv_close($dbhandle);												
								echo "</select>";
								echo "</h4></td></tr>";
							
								echo "<tr><td>";
							?>
								<div id='idLastSMTSetupSheetLog'>
								
							<?php
								echo "Last SMT Setup Sheet: " . $_SESSION['iLASTSMTSETUPSHEETLOG'];	
							?>
								<div ></div>						
							<?php
								echo "</td></tr>";							
							?>							
								</div>							
							<?php
								// echo "</br>";
								// echo "</br>";
								
								// echo $_SESSION['LASTSMTSETUPSHEETVIEW'];
								// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
								
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								echo "<tr>";							
								echo "<td>";
								echo "</br>";
							?>
							
								<!-- <b><input id="idStartNewLS" class="btn btn-outline" type="submit" name="buttProdLotSizePrep" value="Start New Lot Size" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold" /></b> -->
								
							<?php	
								echo "</td></tr>";
								//====================================================================
								//====================================================================
								// NEW SECTOR FOR INPUT THE DATE CODE OF REEL
								
								// echo "<tr>";
								// echo "<td>";							
								// echo "</br>";
								// echo "</br>";
								// echo "</br>";
								// echo "</br>";
								// echo "</br>";
							?>			
								<!--
								<b><input id="idUpdateLS" class="btn btn-outline" type="submit" name="buttProdLotSizePrep" value="Update A Lot Size" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;"/></b>
								-->
							<?php	
								// echo "</td></tr>";
								///==========================================================================
								//==========================================================================					
								//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)
							?>
								<!-- <table class="beta1" style="width:460px;"> -->
							<?php 
								// echo "<tr>";
								// echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
								// echo "SMT PROD. LOT ID:";
								// echo "</span><h4></td>";
								// echo "<td>";
							?>
								<!-- 
								
								-->
							<?php					
								// echo "</td></tr>";
							?>
								<!-- </table> -->
							
							
						</div>	
					</form>
				</div>
				
				<div style="text-align: left;">
					<div style="display: inline; margin: 0;">
						<div class="row content" style="padding:20px;">											
							<!-- <button id="idSMTPRODLOTSIZENEW" class="btn btn-outline" class="open-button" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;" onclick="openStartNewProdLotSizeForm(<?= $_SESSION['iLASTSMTSETUPSHEETLOG']; ?>)">Start New Lot Size</button> -->
							<button id="idSMTPRODLOTSIZENEW" class="btn btn-outline" class="open-button" style="color:red; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;" value="<?= $_SESSION['iLASTSMTSETUPSHEETLOG'] ; ?>" onclick="openStartNewProdLotSizeForm(this.value)">Start New Lot Size</button>
							<div class="form-popup" id="prodlotsizeqty-popup">
								<form action="SMT_ProdLotSizePreparationAction.php" class="prodlotsizeqty-class" id="prodlotsizeqty-form" method="POST">
									<h1>INPUT THE INFORMATION OF NEW SMT PRODUCTION LOT SIZE</h1>
								<?php
									echo "Status: " . $_SESSION['sWARNING'] . " - " . $_SESSION['iPRODLOTSIZEPREP'];
									echo "</br>";
									// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
								?>
									<table class="beta1" style="width:560px;">
								<?php 		
									///==========================================================================
									//==========================================================================					
									//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)
		
									echo "<tr>";
									echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
									echo "MODEL:";
									echo "</span><h4></td>";									
									echo "<td>";
								?>
									<input class="inputBox" type="text" name="txtSMTPRODLOTSIZEMODEL" id="idSMTPRODLOTSIZEMODEL" value="<?= $_SESSION['iSMTPRODLOTSIZEMODEL'] ; ?>" maxlength = "25" style="text-transform:uppercase; color:blue; font-size: 15pt;width:320px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
								<?php	
									echo "</td></tr>";
									///==========================================================================
									//==========================================================================					
									//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)
		
									echo "<tr>";
									echo "<td><h4><span style=\"color:white;background-color:blue;font-weight:bold;\">";
									echo "QUANTITY:";
									echo "</span><h4></td>";									
									echo "<td>";
								?>
									<input class="inputBox" type="text" name="txtSMTPRODLOTSIZEQTY" id="idSMTPRODLOTSIZEQTY" placeholder="0" value="<?= $_SESSION['iSMTPRODLOTSIZEQTY'] ; ?>"  maxlength = "6" style="color:blue; font-size: 15pt;width:120px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
									<span style="font-size: 15pt;height:36px;float:center;clear:both;font-weight:bold;"> (pcs)</span>
								<?php	
									echo "</td></tr>";
									echo "</br>";
									echo "</br>";
									echo "</br>";
									
									
								?>
									</table>
									<input class="btn" type="submit" id="idSTART" name="buttProdLotSizePrep" value="START"/>
									<!-- <button name="buttProdLotSizePrep" type="submit" class="btn">GO</button> -->
									<button type="button" class="btn cancel" onclick="closeStartNewProdLotSizeForm()">Close</button>
								</form>
							</div>	
						</div>	
					</div>
				</div>	
				
				<div style="text-align: left;">
					<div style="display: inline; margin: 0;">
						<div class="row content" style="padding:20px;">											
							<button id="idSMTPRODLOTSIZEUPDATE" class="btn btn-outline" class="open-button" style="color:blue; font-size: 12pt;width:250px; height:36px;float:center;clear:both;font-weight:bold;" onclick="openUpdateProdLotSizeForm()">Update A Lot Size</button>
							
							<div class="form-popup" id="prodlotsizeid-popup">
								<form action="SMT_ProdLotSizePreparationAction.php" class="prodlotsizeid-class" id="prodlotsizeid-form" method="POST">
									<h1>INPUT SPECIFIC SMT PRODUCTION LOT SIZE ID</h1>
								<?php
									echo "Status: " . $_SESSION['sWARNING'] . " - " . $_SESSION['iPRODLOTSIZEPREP'];
									echo "</br>";
									// echo "<table id='formInput' border='0'  cellspacing = '0' cellpadding = '0' >";
								?>
									<table class="beta1" style="width:360px;">
								<?php 										
									///==========================================================================
									//==========================================================================					
									//NEW SECTOR FOR INPUT THE DATALOGIC PART NUMBER (DLPN)

									echo "<tr>";								
									echo "<td>";
								?>
									<input class="inputBox" type="text" name="txtSMTPRODLOTSIZEID" id="idSMTPRODLOTSIZEID" placeholder="SMTPLOT***" value="<?= $_SESSION['iSMTPRODLOTSIZEID'] ; ?>"  maxlength = "14" style="color:blue; font-size: 15pt;width:260px; height:32px; font-weight:bold;background-color:yellow;clear:right"/>
								<?php					
									echo "</td></tr>";
									echo "</br>";
									echo "</br>";
									echo "</br>";
									
									
								?>
									</table>
									<input class="btn" type="submit" id="idUPDATE" name="buttProdLotSizePrep" value="UPDATE"/>
									<!-- <button name="buttProdLotSizePrep" type="submit" class="btn">GO</button> -->
									<button type="button" class="btn cancel" onclick="closeUpdateProdLotSizeForm()">Close</button>
								</form>
							</div>	
						</div>	
					</div>
				</div>				
			</div>
		</div> 
	<body>
</html>