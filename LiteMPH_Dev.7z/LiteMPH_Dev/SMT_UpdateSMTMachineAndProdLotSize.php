<?php
	@session_start();
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
						or die("Couldn't connect to SQL Server on $myServer");						
		
	$query = "SELECT TOP(1) * FROM [dbo].[SMTMachineMonitoring] WHERE"
				. " [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'";
				// . " AND [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
			
	$_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	sqlsrv_query($dbhandle,$query);	
	
	$returnedProdLotSizeID = "";
	while ($row = sqlsrv_fetch_array($result)) {		
		$returnedProdLotSizeID = trim($row['ProdLotSizeID']);
	}
	
	if ($returnedProdLotSizeID == ""){
		$query = "UPDATE [dbo].[SMTMachineMonitoring] SET [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
					. " WHERE [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'";
				
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		sqlsrv_query($dbhandle,$query);
		
		if ($_SESSION['iSMTPRODLOTSIZEID'] == ""){
			$query = "INSERT INTO [dbo].[SMTMachineMonitoringLog]([SMTMachineName]) VALUES (" 
						. "'" . $_SESSION['SMTMACHINENAME'] . "'";
		}
		else{
			$query = "INSERT INTO [dbo].[SMTMachineMonitoringLog]([SMTMachineName],[ProdLotSizeID]) VALUES (" 
						. "'" . $_SESSION['SMTMACHINENAME'] . "', "
						. "'" . $_SESSION['iSMTPRODLOTSIZEID'] . "')";
		}
				
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		sqlsrv_query($dbhandle,$query);	
	}
	
	sqlsrv_close($dbhandle);
?>
