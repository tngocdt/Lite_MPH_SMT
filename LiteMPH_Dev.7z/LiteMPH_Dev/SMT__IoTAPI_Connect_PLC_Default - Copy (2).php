<?php
	// @session_start();
	
	// $myServer = $_SESSION['ServerInstanceName'];
	// $myUser = $_SESSION['ServerUserName'];
	// $myPass = $_SESSION['ServerPassword'];
	// $myDB = $_SESSION['ServerDB'];
	// $connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//// connection to the database
	// $dbcnn = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		// or die("Couldn't connect to SQL Server on $myServer");

	//// declare the SQL statement that will query the database
	// $query = "UPDATE [dbo].[SMTMachineMonitoring] SET IoTControlStatus = '1', [IoTData] = '0', LastUpdate = GETDATE() WHERE"
				// . " [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'"
				// . " AND [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
	
	// $_SESSION['iQUERRY'] = $query;
	//// execute the SQL query and return records
	// sqlsrv_query($dbcnn,$query);
	//// display the results
	
	// sqlsrv_close($dbcnn);	

	// POST localhost:8081/api/Conveyor/Connect_PLC_Default	
	
	// $url = 'http://server.com/path';
	// $url = 'http://eleanaims.ddns.net:9090/LiteMPH_Dev/SMT_IoTAccessProdLotSizeStatus.php?';
	$url = 'http://localhost:8081/api/Conveyor/Connect_PLC_Default';
	 
	//Initiate cURL.
	$ch = curl_init($url);
	 
	//The JSON data.
	$jsonData = array(
		"Comport" => "COM4",
		"Connectiontimeout" => "3000"
	);
	

	//Encode the array into JSON.
	$jsonDataEncoded = json_encode($jsonData);
	// $jsonDataEncoded = $jsonData;
	
	//Tell cURL that we want to send a POST request.
	curl_setopt($ch, CURLOPT_POST, 1);
	 
	//Attach our encoded JSON string to the POST fields.
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	 
	//Set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	 
	//Execute the request
	$result = curl_exec($ch);
	
	echo $result;
?>
