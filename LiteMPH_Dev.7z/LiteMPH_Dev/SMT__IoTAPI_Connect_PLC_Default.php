<?php
	// @session_start();
	
	// POST	localhost:8081/api/Conveyor/Connect_PLC_Default
	$url = 'http://localhost:8081/api/Conveyor/Connect_PLC_Default_Reconnect';
	$curl = curl_init($url);
	
	$postData = array(
		'Comport' => 'COM4',
		'Connectiontimeout' => '3000'
	);
	
	// **************************************************************************
	// **************************************************************************	
	curl_setopt($curl, CURLOPT_POST, 1);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($postData));  ;
	curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type' => 'application/json',
		));
		
	
	$response = curl_exec($curl);
	
	if ($response === false) {
		$info = curl_getinfo($curl);
		curl_close($curl);
		
		die(var_export($info));
	}
	else{
		curl_close($curl);
	}
	
	// echo $response;
	// echo "</br>";
	
	$var = json_decode($response, TRUE);
	$status = ($var);
	
	if ($status == "Okay"){
		echo "Successfully connect to PLC!";
	}
	else{
		echo "Error";
	}
?>
