<?php	
	// session_start();
	// $q=$_REQUEST["q"];
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//separate the value of $q: linename_pcbmodel	
	// $line= trim(strtok($q, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	// $SMTSetupSheetLogName = $q;

	//declare the SQL statement that will query the database
	$query = "SELECT TOP(1) * FROM [dbo].[SMTProdLotSizePreparation] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "' ORDER BY Location";
	
	//$_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);		
	
	$getIDSMTSetupSheetLog = 0;	
	while ($row = sqlsrv_fetch_array($result)) {		
		$getIDSMTSetupSheetLog = (int)$row['IDSMTSetupSheetLog'];
	}
	
	// if ($getIDSMTSetupSheetLog > 0){
		// $_SESSION['IDSMTSetupSheetLog'] = $getIDSMTSetupSheetLog;
		echo "<h5>";
		echo "SMT PRODUCTION LOT SIZE PREPARATION HAS BEEN FINISHED";
		echo "</h5>";
		echo "<html><body><table class='beta'>";
		echo "<tr>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">No.</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">ProdLotSizeID</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">Location</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">PartNumber</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">PartQty</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">PartConsumpQty</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">ProdLotSizeTime</th>
				<th style =\"font-weight:bold\" bgcolor=\"green\" color=\"white\">ProdLotSizePIC</th>
			</tr>";
			
		//declare the SQL statement that will query the database
		$query = "SELECT * FROM [dbo].[SMTProdLotSizePreparation] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "' ORDER BY Location";
		
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		
		$rowCount = 0;
		while ($row = sqlsrv_fetch_array($result)) {
			$dtProdLotSizeTime = $row['ProdLotSizeTime']->format('Y-m-d H:i:s');
			$intPartQty = (int)($row['PartQty']);
			$intPartConsumpQty = (int)($row['PartConsumpQty']);
			$intPartRemainQty = $intPartQty - $intPartConsumpQty;
			//style =\"font-weight:bold\" bgcolor=\"red\"
			
			$rowCount = $rowCount + 1;
			echo "<tr>";
				if ($intPartRemainQty > 0){
					echo "<td>" . $rowCount . "</td>";
					echo "<td>" . trim($row['ProdLotSizeID']) . "</td>";
					echo "<td>" . trim($row['Location']) . "</td>";
					echo "<td>" . trim($row['PartNumber']) . "</td>";
					echo "<td>" . $intPartQty . "</td>";
					echo "<td>" . $intPartConsumpQty . "</td>";
					echo "<td>" . $dtProdLotSizeTime . "</td>";
					echo "<td>" . trim($row['ProdLotSizePIC']) . "</td>";
				}
				else{
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . trim($row['ProdLotSizeID']) . "</td>";
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . trim($row['Location']) . "</td>";
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . trim($row['PartNumber']) . "</td>";
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . $intPartQty . "</td>";
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . $intPartConsumpQty . "</td>";
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . $dtProdLotSizeTime . "</td>";
					echo "<td style =\"font-weight:bold\" bgcolor=\"red\" color=\"white\">" . trim($row['ProdLotSizePIC']) . "</td>";
				}
			echo "</tr>";			
		}
			
		echo "\n</table></body></html>";
		
		$query = "SELECT TOP(1) [IDSMTSetupSheetLog], [MachineName], [MachinePosition], [MachineMaterials], [MachineProgram], [PickupQty] FROM [dbo].[SMTSetupSheetLayoutControl]"
					. " WHERE [IDSMTSetupSheetLog] = '". $_SESSION['IDSMTSetupSheetLog'] . "'"
					. " AND [MachinePosition] NOT IN"
					. " ("
						. "SELECT [Location] FROM [dbo].[SMTProdLotSizePreparation]"
						. " WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
						. " AND [PartQty] - [PartConsumpQty] > 0"
					. ")";
					
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		
		$returnedMachinePosition = "";
		while ($row = sqlsrv_fetch_array($result)) {		
			$returnedMachinePosition = trim($row['MachinePosition']);
		}
		
		if ($returnedMachinePosition !== ""){
			echo "</br>";
			echo "</br>";
			echo "</br>";
			echo "<h5>";
			echo "MISSING LOCATION PREPARATION IN SETUP SHEET:";
			echo "</h5>";
			echo "<html><body>";
?>
			<table class='beta'>
<?php
			echo "<tr>
					<th style =\"border:1px solid gray\" font-weight:\"bold\" bgcolor=\"red\" color=\"white\">No.</th>
					<th style =\"border:1px solid gray\" font-weight:\"bold\" bgcolor=\"red\" color=\"white\">IDSMTSetupSheetLog</th>
					<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachineName</th>
					<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachinePosition</th>
					<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachineMaterials</th>
					<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachineProgram</th>
					<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">PickupQty</th>
				</tr>";
				
			//declare the SQL statement that will query the database
			$query = "SELECT [IDSMTSetupSheetLog], [MachineName], [MachinePosition], [MachineMaterials], [MachineProgram], [PickupQty] FROM [dbo].[SMTSetupSheetLayoutControl]"
						. " WHERE [IDSMTSetupSheetLog] = '". $_SESSION['IDSMTSetupSheetLog'] . "'"
						. " AND [MachinePosition] NOT IN"
						. " ("
							. "SELECT [Location] FROM [dbo].[SMTProdLotSizePreparation]"
							. " WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'"
							. " AND [PartQty] - [PartConsumpQty] > 0"
						. ")"
						. " ORDER BY [MachinePosition]";
			
			$_SESSION['iQUERRY'] = $query;
			//execute the SQL query and return records
			$result = sqlsrv_query($dbhandle,$query);
			
			$rowCount = 0;
			while ($row = sqlsrv_fetch_array($result)) {
				$rowCount = $rowCount + 1;
				echo "<tr>";
					echo "<td style =\"border:1px solid gray\">" . $rowCount . "</td>";
					echo "<td style =\"border:1px solid gray\">" . trim($row['IDSMTSetupSheetLog']) . "</td>";
					echo "<td style =\"border:1px solid gray\">" . trim($row['MachineName']) . "</td>";
					echo "<td style =\"border:1px solid gray\">" . trim($row['MachinePosition']) . "</td>";
					echo "<td style =\"border:1px solid gray\">" . trim($row['MachineMaterials']) . "</td>";
					echo "<td style =\"border:1px solid gray\">" . trim($row['MachineProgram']) . "</td>";
					echo "<td style =\"border:1px solid gray\">" . (int)$row['PickupQty'] . "</td>";
				echo "</tr>";				
			}
				
?>
			</table>
<?php
			echo "</body></html>";
		}
		else{
			if ($getIDSMTSetupSheetLog == 0){
				echo "</br>";
				echo "</br>";
				echo "</br>";
				echo "<h5>";
				echo "MISSING LOCATION PREPARATION IN SETUP SHEET:";
				echo "</h5>";
				echo "<html><body>";
	?>
				<table class='beta'>
	<?php
				echo "<tr>
						<th style =\"border:1px solid gray\" font-weight:\"bold\" bgcolor=\"red\" color=\"white\">IDSMTSetupSheetLog</th>
						<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachineName</th>
						<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachinePosition</th>
						<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachineMaterials</th>
						<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">MachineProgram</th>
						<th style =\"border:1px solid gray\" font-weight:bold\" bgcolor=\"red\" color=\"white\">PickupQty</th>
					</tr>";
					
				//declare the SQL statement that will query the database
				$query = "SELECT [IDSMTSetupSheetLog], [MachineName], [MachinePosition], [MachineMaterials], [MachineProgram], [PickupQty] FROM [dbo].[SMTSetupSheetLayoutControl]"
							. " WHERE [IDSMTSetupSheetLog] = '". $_SESSION['IDSMTSetupSheetLog'] . "'"
							. " ORDER BY [MachinePosition]";
				
				$_SESSION['iQUERRY'] = $query;
				//execute the SQL query and return records
				$result = sqlsrv_query($dbhandle,$query);
				
				$rowCount = 0;
				while ($row = sqlsrv_fetch_array($result)) {
					echo "<tr>";
						echo "<td style =\"border:1px solid gray\">" . trim($row['IDSMTSetupSheetLog']) . "</td>";
						echo "<td style =\"border:1px solid gray\">" . trim($row['MachineName']) . "</td>";
						echo "<td style =\"border:1px solid gray\">" . trim($row['MachinePosition']) . "</td>";
						echo "<td style =\"border:1px solid gray\">" . trim($row['MachineMaterials']) . "</td>";
						echo "<td style =\"border:1px solid gray\">" . trim($row['MachineProgram']) . "</td>";
						echo "<td style =\"border:1px solid gray\">" . (int)$row['PickupQty'] . "</td>";
					echo "</tr>";
					$rowCount = $rowCount + 1;
				}
					
	?>
				</table>
	<?php
				echo "</body></html>";
			}
		}
	// }
	
	
	sqlsrv_close($dbhandle);
?>
