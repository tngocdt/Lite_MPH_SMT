<?php 
	include("sharedPage.php");
	if ($_SERVER['REQUEST_METHOD'] == 'GET'){
		require_once("ServerLogin.php");
	}
?> 

<body>	
    <div class="sidenav">
		<div id="accordion">
            <ul>
                <li>
                    <div>
                       <div class="panel-heading">
                            <h5 class="panel-title">
								<button type="button" class="btn btn-lg btn-info" data-toggle="collapse" data-target="#collapse5">MPH</button>
							</h5>
                        </div>
						<div id="collapse5" class="collapse in">
							<ul>
								<li>
									<button type="button" class="btn btn-success" data-toggle="collapse" data-target="#collRU">
										SMT
									</button>
									<div id="collRU" class="collapse in">
										<ul>
											<li>
												<?php
													// ****************************************************
													// ****************************************************
													// For **Setup Sheet Control Module**
													if (!isset($_SESSION['sWARNING'])) {		
														$_SESSION['sWARNING'] = 0;
													}

													if (!isset($_SESSION['FILENAME'])) {	
														$_SESSION['FILENAME'] = "***";
														$_SESSION['iQUERRY'] = "***";
													}

													if (!isset($_SESSION['strTARGETFILE'])) {	
														$_SESSION['strTARGETFILE'] = "***";
													}

													if (!isset($_SESSION['IDSMTSETUPSHEET'])) {	
														$_SESSION['IDSMTSETUPSHEET'] = 0;
													}
													
													if (!isset($_SESSION['SETUPSHEETUPLOADVIEW'])) {	
														$_SESSION['SETUPSHEETUPLOADVIEW'] = "Block";
													}
													
													if (!isset($_SESSION['SMTSetupSheetName'])) {	
														$_SESSION['SMTSetupSheetName'] = "***";
													}													
													
													if (!isset($_SESSION['IDSMTSetupSheetLog'])) {	
														$_SESSION['IDSMTSetupSheetLog'] = 0;
													}
													
													if (!isset($_SESSION['SMTSetupSheetLogName'])) {	
														$_SESSION['SMTSetupSheetLogName'] = "***";
													}
													
													
													// ****************************************************
													// ****************************************************
													// For **Production Lot Size Preparation Module**
													if (!isset($_SESSION['LASTSMTSETUPSHEETVIEW'])) {	
														$_SESSION['LASTSMTSETUPSHEETVIEW'] = "None";
													}
													
													if (!isset($_SESSION['iLASTSMTSETUPSHEETLOG'])) {	
														$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";
													}
																										
													if (!isset($_SESSION['iSMTPRODLOTSIZEID'])) {	
														$_SESSION['iSMTPRODLOTSIZEID'] = "";
													}
													
													if (!isset($_SESSION['iPRODLOTSIZEPREP'])) {	
														$_SESSION['iPRODLOTSIZEPREP'] = "";
													}
													
													if (!isset($_SESSION['iLASTSMTSETUPSHEETLOG'])) {	
														$_SESSION['iLASTSMTSETUPSHEETLOG'] = "???";
													}
													
													// ****************************************************
													// ****************************************************
													// For **Production Lot Size Preparation Module**
													if (!isset($_SESSION['iSMTPRODLOTSIZEID'])) {	
														$_SESSION['iSMTPRODLOTSIZEID'] = "";
													}
													
													
													// ****************************************************
													// ****************************************************
													echo "<b>"."<a href=\"SMT_SetupSheet.php?q=0\">";
													echo "Setup Sheet Control";
													echo "</a></b>";
												?>
											</li>
											<li>
												<?php
													echo "<b>"."<a href=\"SMT_ProdLotSizePreparation.php?q=0\">";
													echo "Production Lot Size Preparation";
													echo "</a></b>";
												?>
											</li>
											<li>			
												<div class="btn btn-outline2">
												<?php
													echo "<b>"."<a style=\"color:red; font-size:10pt; float:center; clear:both; font-weight:bold\" href=\"SMT_RunningProdLotSize.php?q=0\">";
													echo "Run Prod. Lot Size & IoT Control";
													echo "</a></b>";
												?>
												</div>
											</li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</li>
			</ul>
		</div>
    </div>       
</body>