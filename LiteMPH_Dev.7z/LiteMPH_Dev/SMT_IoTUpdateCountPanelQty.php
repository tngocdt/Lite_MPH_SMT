<?php	
	session_start();
	
	$strMachine = $_REQUEST["Machine"];
	$intCountQty = (int)$_REQUEST["CountQty"];
	
	// http://eleanaims.ddns.net:9090/LiteMPH_Dev/SMT_IoTUpdateCountPanelQty.php?Machine=NXT&CountQty=10
	// echo $strMachine . " - " . $intCountQty;
	
	$_SESSION['ServerInstanceName']="ELEANAIMS";
	$_SESSION['ServerUserName']="eleanAIms";
	$_SESSION['ServerPassword']="ele@nAIms*1024";
	$_SESSION['ServerDB']="ELEANAIMSODB";
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	/*
	//separate the value of $Machine: linename_pcbmodel	
	// $line= trim(strtok($Machine, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	//declare the SQL statement that will query the database
	$query = "UPDATE [dbo].[SMTMachineMonitoring] SET [IoTCounterQty] ='" . $intCountQty . "', [IoTData] ='1', LastUpdate = GETDATE() WHERE [SMTMachineName] = '" . $strMachine . "'";
	

	//execute the SQL query and return records
	sqlsrv_query($dbhandle,$query);

	sqlsrv_close($dbhandle);	
	*/
	
	$params = array(
		// array(&$_SESSION['FILENAME'], SQLSRV_PARAM_IN),
		// array(&$_SESSION['strTARGETFILENAME'], SQLSRV_PARAM_IN),
		array(&$strMachine, SQLSRV_PARAM_IN)
	);
	
	$sql = "UPDATE [dbo].[SMTMachineMonitoring] SET [IoTCounterQty] ='" . $intCountQty . "', [IoTData] ='1', LastUpdate = GETDATE() WHERE [SMTMachineName] = ?";		
	$stmt = sqlsrv_query($dbhandle, $sql, $params);
	
	if($stmt === false){  
		echo "Sorry, there was an error in accessing SMT Production Lot Size Number!";
		echo "</br>";
		die( print_r( sqlsrv_errors(), true));  
	}  
	else{
		$returnedFindingVal = 0;
		while($row = sqlsrv_fetch_array($stmt)){
			$returnedFindingVal = (int)$row['IoTControlStatus'];
		}
	}
		
	sqlsrv_free_stmt($stmt);
	sqlsrv_close($dbhandle);
	
	echo $returnedFindingVal;
?>
