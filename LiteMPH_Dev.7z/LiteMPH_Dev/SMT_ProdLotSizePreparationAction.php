<?php
	session_start();
	
	$_SESSION['iPRODLOTSIZEPREP'] = trim($_POST['buttProdLotSizePrep']);
	
	$_SESSION['sWARNING'] = 0;
	
	$_SESSION['iSMTLOCATION'] = "";
	$_SESSION['iSMTPARTNUMBER'] = "";
	$_SESSION['iSMTPARTQTY'] = "";		
	$_SESSION['iPrevSMTPARTNUMBER'] = "";
	$_SESSION['iPrevSMTPARTQTY'] = "";
	$_SESSION['iPrevSMTLOCATION'] = "";
		
	if ($_SESSION['iPRODLOTSIZEPREP'] == "Start New Lot Size"){
		$_SESSION['iSMTPRODLOTSIZEID'] = "";
		// start code here for database CRUD
		require_once("SMT_AccessSMTProdLotSize.php");		// Server will control to create the SMT Production Lot Size ID and the program access to get that ReelID
		
		if ($_SESSION['iSMTPRODLOTSIZEID'] == ""){
			$_SESSION['sWARNING'] = 1;
			header ("Location: SMT_ProdLotSizePreparation.php");
			exit();	
		}
	}
	elseif ($_SESSION['iPRODLOTSIZEPREP'] == "GO"){
		$_SESSION['iSMTPRODLOTSIZEID'] = trim($_POST['txtSMTPRODLOTSIZEID']);
		
		if (strlen($_SESSION['iSMTPRODLOTSIZEID']) < 14) {
			$_SESSION['sWARNING'] = 3;		
			header ("Location: SMT_ProdLotSizePreparation.php");
			exit();
		}
		
		if (substr($_SESSION['iSMTPRODLOTSIZEID'],0,7) != "SMTPLOT") {
			$_SESSION['sWARNING'] = 4;		
			header ("Location: SMT_RunningProdLotSize.php");
			exit();
		}
		
		$_SESSION['IDSMTSetupSheetLog'] = 0;
		$_SESSION['SMTSetupSheetName'] = "None";
		$_SESSION['FOUNDVALUE'] = "NO";
		require_once("SMT__ProdLotSizeIDInPreparation.php");
		if ($_SESSION['FOUNDVALUE'] == "NO"){
			$_SESSION['sWARNING'] = 5;		
			header ("Location: SMT_ProdLotSizePreparation.php");
			exit();
		}		
		
	}
	else{
		$_SESSION['sWARNING'] = 0;
	}
	
	if ($_SESSION['iLASTSMTSETUPSHEETLOG'] == "???"){
		$_SESSION['sWARNING'] = 6;		
		header ("Location: SMT_ProdLotSizePreparation.php");
		exit();
	}
	
	$_SESSION['iLISTOFPARTLOCATION'] = "";
	header ("Location: SMT_ComponentTraceablity.php");
?>