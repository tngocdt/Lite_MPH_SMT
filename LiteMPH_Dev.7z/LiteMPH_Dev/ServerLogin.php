<?PHP
	@session_start();
	// ========================================================
	// initial DataBase Server and Authentication Log-in Account
	$_SESSION['ServerInstanceName']="ELEANAIMS";
	$_SESSION['ServerUserName']="eleanAIms";
	$_SESSION['ServerPassword']="ele@nAIms*1024";
	$_SESSION['ServerDB']="ELEANAIMSODB";
	// ********************************************************	
	// $_SESSION['ServerInstanceName']="vnmsrv601.dl.net\SIPLACE_2008R2EX";
	// $_SESSION['ServerUserName']="sa";
	// $_SESSION['ServerPassword']="Siplace.1";
	// $_SESSION['ServerDB']="DLVNDB";
?>
