<?PHP
	@session_start();
	// ========================================================
	// initial DataBase Server and Authentication Log-in Account
	$_SESSION['ServerInstanceName']="ELEANAIMS";
	$_SESSION['ServerUserName']="eleanAIms";
	$_SESSION['ServerPassword']="ele@nAIms*1024";
	$_SESSION['ServerDB']="ELEANAIMSODB";
	// ********************************************************	
	// $_SESSION['ServerInstanceName']="vnmsrv601.dl.net\SIPLACE_2008R2EX";
	// $_SESSION['ServerUserName']="sa";
	// $_SESSION['ServerPassword']="Siplace.1";
	// $_SESSION['ServerDB']="DLVNDB";
	
	
	
	// ********************************************************	
	// Config for ADAM-6526
	$_SESSION['iADAM6256IP'] = "192.168.1.10";
	$_SESSION['iADAM6256Port'] = 502;
	$_SESSION['iADAM6256Coil'] = 16;
	$_SESSION['iADAM6256Status'] = "false";
	
	
	// ********************************************************	
	// Config for ADAM-6526
	$_SESSION['iADAM6060IP'] = "192.168.1.11";
	$_SESSION['iADAM6060Port'] = 502;
	$_SESSION['iADAM6060Clear'] = 33;
?>
