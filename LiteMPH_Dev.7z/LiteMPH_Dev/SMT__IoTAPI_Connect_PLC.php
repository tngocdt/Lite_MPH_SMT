<?php
	// @session_start();
	
	// $myServer = $_SESSION['ServerInstanceName'];
	// $myUser = $_SESSION['ServerUserName'];
	// $myPass = $_SESSION['ServerPassword'];
	// $myDB = $_SESSION['ServerDB'];
	// $connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//// connection to the database
	// $dbcnn = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		// or die("Couldn't connect to SQL Server on $myServer");

	//// declare the SQL statement that will query the database
	// $query = "UPDATE [dbo].[SMTMachineMonitoring] SET IoTControlStatus = '1', [IoTData] = '0', LastUpdate = GETDATE() WHERE"
				// . " [SMTMachineName] = '" . $_SESSION['SMTMACHINENAME'] . "'"
				// . " AND [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
	
	// $_SESSION['iQUERRY'] = $query;
	//// execute the SQL query and return records
	// sqlsrv_query($dbcnn,$query);
	//// display the results
	
	// sqlsrv_close($dbcnn);	

	// POST localhost:8081/api/Conveyor/Connect_PLC_Default	
	
	// $url = 'http://server.com/path';
	// $url = 'http://eleanaims.ddns.net:9090/LiteMPH_Dev/SMT_IoTAccessProdLotSizeStatus.php?';
	$url = 'http://eleanaims.ddns.net:9090/LiteMPH_Dev/SMT_IoTUpdateCountPanelQty.php?';
	$data = array('Machine' => 'NXT', 'CountQty' => '24');

	// use key 'http' even if you send the request to https://...
	$options = array(
		'http' => array(
			'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
			'method'  => 'POST',
			'content' => http_build_query($data)
		)
	);
	$context  = stream_context_create($options);
	$result = file_get_contents($url, false, $context);
	if ($result === FALSE) { /* Handle error */ }

	var_dump($result);
?>
