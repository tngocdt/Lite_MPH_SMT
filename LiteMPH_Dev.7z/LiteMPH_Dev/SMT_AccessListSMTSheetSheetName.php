<?php	
	session_start();
	$q=$_REQUEST["q"];
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//separate the value of $q: linename_pcbmodel	
	// $line= trim(strtok($q, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	$SMTSetupSheetName = $q;
	$_SESSION['IDSMTSetupSheet'] = 0;

	//declare the SQL statement that will query the database
	$query = "SELECT [IDSMTSetupSheet] FROM [dbo].[SMTSetupSheetMasterList] WHERE [SMTSetupSheetName] = '" . $SMTSetupSheetName . "'";
	
	// $_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);

	//display the results
	while($row = sqlsrv_fetch_array($result)){
		$_SESSION['IDSMTSetupSheet'] = $row['IDSMTSetupSheet'];
	}
?>
	<!-- <select name="lstSMTSetupSheetNameLog" id="idSMTSetupSheetNameLog" style="color:blue; width:550px; height:36px;font-size: 15pt;font-weight:bold;background-color:yellow;" > -->
	<select name="lstSMTSetupSheetNameLog" id="idSMTSetupSheetNameLog" style="color:blue; width:550px; height:36px;font-size: 15pt;font-weight:bold;background-color:yellow;" onchange = "AutoSubmit(this.value)">
<?php
	echo "<option value='Choose a Setup Sheet Log Name'>Choose a Setup Sheet Log Name</option>";
	if ($_SESSION['IDSMTSetupSheet'] > 0){
		//declare the SQL statement that will query the database
		$query = "SELECT [SMTSetupSheetLogName] FROM [dbo].[SMTSetupSheetLogControl] WHERE [IDSMTSetupSheet] = '" . $_SESSION['IDSMTSetupSheet'] ."' ORDER BY [SMTSetupSheetLogName] DESC";
		
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		
		While($row = sqlsrv_fetch_array($result)){
			if (trim($row['SMTSetupSheetLogName']) !== $_SESSION['SMTSetupSheetLogName']){
				echo "<option value='" . trim($row['SMTSetupSheetLogName']) . "' >" . trim($row['SMTSetupSheetLogName']) . "</option>";
			}
			else{
				echo "<option value='" . trim($row['SMTSetupSheetLogName']) . "' selected>" . trim($row['SMTSetupSheetLogName']) . "</option>";
			}

		}
	}						
	sqlsrv_close($dbhandle);	
	
	echo "</select>";
	
?>
