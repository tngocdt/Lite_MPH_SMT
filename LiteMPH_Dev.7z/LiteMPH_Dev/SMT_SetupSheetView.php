<?PHP
	session_start();
	if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) {
	header ("Location: login.php");
	}
?>

<script>
function GetListPCBModel(lst) {
 	if (lst.length==0) {
    		document.getElementById("lstSMTLineAssign").innerHTML="";
    		return;
  	}
  	var xmlhttp=new XMLHttpRequest();
  	xmlhttp.onreadystatechange=function() {
   		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      			document.getElementById("lstSMTLineAssign").innerHTML=xmlhttp.responseText;
    		}
  	}
  	xmlhttp.open("GET","SCTmsSQL_GetListPCBModelAssign.php?q="+lst,true);
  	xmlhttp.send();
}
</script>

<script>
function GetUserInput(str) {
	if (str == 1) {
		alert("Please Select A SMT Line in SMT Line ListBox!");
	}
	if (str == 2) {
		alert("Please Select A PCB Model in PCB Model ListBox!");
	}
	if (str == 3) {
		alert("Please Scanning The Correct Number of Production Order!");
	}
}
</script>

<script>
function VerFullSetup(str) {
	if (str ==0) {
		alert("Model PCB Chua Duoc Set-up Day Du Cac REELID Linh Kien O Cac Vi Tri SIPLACE Va TRACK-DIV Tren Line SMT!" + "\n" + "The PCB Model Have Not Been Set-up Fully With REELID Components In System of SIPLACE And TRACK-DIV On SMT Line!");
	}	
}
</script>

<?//======THE FOLLOWING FUNCTION WILL CALL AT ON LOADING======?>
<script>
function OnLoadFunction($cfgListPCBonLoad,$cfgUserInputonLoad, cfgFULLSETUP) {	
	//DisableTmpBox();
 	GetListPCBModel($cfgListPCBonLoad);
	GetUserInput($cfgUserInputonLoad);
	VerFullSetup(cfgFULLSETUP);
}
</script>

<html>
<head>
	<title>SCT Program: PCB TOP MODEL</title>
	<!-- Place the above styles in the head (i.e. between the <head></head> tags) -->
	<style type="text/css">
		.different-font-color { color: orange; }
		.different-background-color { background-color: limegreen }
	</style>
</head>	

<?php
$cfgListPCBonLoad = $_SESSION['LineSMTAssign'] . "_" . $_SESSION['pcbModelAssign'] ;
$cfgUserInputonLoad = $_SESSION['PCBReelIDAssignWARNING'] ;
?>

<body onload="OnLoadFunction(<? echo "'" . $cfgListPCBonLoad . "'"; ?>,<? echo "'" . $cfgUserInputonLoad . "'"; ?>,<? echo "'" . $_SESSION['FULLSETUP'] . "'"; ?>)" >
	
	<left>
	<?php
		$uname =$_SESSION['uname'];
		echo "<table >";
			echo "<tr><td>";
			echo "<P align ='left'>";				
			echo "<table border='1' >";
			echo "<b><tr align=\"right\"><td bgcolor=\"#ff00ff\">".
				"<a href=\"Logout.php\">" ;
			echo "Log-out ";
			echo $uname;
			echo "</a></b>";
			echo "</td>";
			echo "</tr>";	
			echo "</table>";
			echo "</P>";
			echo "</td>";
	?>
	</left>

	<right>
	<?php
			echo "<td>";
			echo "<P align ='right'>";	
			echo "<table border='1' >";
			echo "<b><tr align=\"right\"><td bgcolor=\"#ff00ff\">".
				"<a href=\"SCTmsSQL_MainPage.php\">" ;
			echo "GO TO MAIN PAGE";
			echo "</a></b>";
			echo "</td></tr>";	
			echo "</table>";
			echo "</P>";
			echo "</td></tr>";
		echo "</table>";
	?>
	</right>
	
	<center><img src="DATALogiclg2.jpg" alt="Image 3" /></center>	
	<h1><?php
		echo "<center>";
		echo "<p><span style=\"background-color:green;font-weight:bold\">";
		echo "<b><font color=\"white\">";
		echo "PCB SERIAL - REEL ID ASSIGN";
		echo "<br>";
		echo "DECLARE PCB TOP MODEL";
		echo "</font></b></span></p>";	
		echo "</center>";
	?></h1>
		<center>
		<?//=========CALL **SCTmsSQLaction.php** with POST method==============?>
		<form name="STCForm1" action="SCTmsSQL_AssignPCBTopModelAction.php" method="POST">
			<div style="width:490px;">	
					
			<?php									
				echo "<table border='0' >";
					//=============================================================
					//=============================================================
					// NEW SECTOR: SHOW LIST OF SMT MACHINE LINE
					echo "<tr>";
  					echo "<td> <h2><span style=\"background-color:orange;font-weight:bold\">";
					echo "Select SMT Line:";					
					echo "</span></h2></td>";

  					echo "<td><h2>";
					$myServer = $_SESSION['ServerInstanceName'];
					$myUser = $_SESSION['ServerUserName'];
					$myPass = $_SESSION['ServerPassword'];
					$myDB = $_SESSION['ServerDB'];

					$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
					//connection to the database
					$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
								or die("Couldn't connect to SQL Server on $myServer");

					//declare the SQL statement that will query the database
					$query = "SELECT DISTINCT SMTLine ";
					$query .= "FROM PreAssyComponentsTracking_ModelvsMaterialsLayoutMatrix ";
	
					//execute the SQL query and return records
					$result = sqlsrv_query($dbhandle,$query);
					//display the results
			?>
					<select name="SMTLineAssign" style="width:250px; height:40px;font-size: 22pt;font-weight:bold;background-color:yellow;" onchange = "GetListPCBModel(this.value)" >

			<?php		
					echo "<option value='Choose a Line'>Choose a Line</option>";
					While($row = sqlsrv_fetch_array($result)){
						if (trim($row['SMTLine']) !==trim($_SESSION['LineSMTAssign'])){
							echo "<option value='" . $row['SMTLine'] . "'>" . $row['SMTLine'] . "</option>";
						}
						else{
							echo "<option value='" . $row['SMTLine'] . "' selected>" . $row['SMTLine'] . "</option>";
						}					
					}			
					sqlsrv_close($dbhandle);												
					echo "</select>";

					//==========================================================================
					//==========================================================================
					// NEW SECTOR: SHOW LIST OF PCB MODEL DEDICATED ON EQUIVALENT SMT LINE
					echo "<tr><td> <h2><span style=\"background-color:orange;font-weight:bold\">";
					echo "Select PCB Model:";					
					echo "</span></h2></td>";
  					echo "<td><h2>";
					//echo $_SESSION['pcbModel'];	 
			?>	
					
					<div id="lstSMTLineAssign"><b><select style="width:250px; height:40px;font-size: 22pt;font-weight:bold;background-color:yellow;"></select></b></div>
			<?php		
					
					echo "</select>";
					echo "</h2></td></tr>";
					
					//==========================================================================
					//==========================================================================
					//NEW SECTOR FOR INPUT MANUFACTURING PRODUCTION ORDER
					echo "<tr>";
  					echo "<td> <h2><span style=\"color:white;background-color:blue;font-weight:bold\">";
					echo "Production Order:";
					echo "</span></h2></td>";
  					echo "<td>";
					
			?>		<?//============SET UP THE INPUT BOX HERE FOR SCANNING SMPN?>
					<h2><input type="text" name="txtPOAssign" id="focus" value="<?= $_SESSION['PRORDERAssign'] ; ?>"  maxlength = "9" style="font-size: 20pt;width:250px; height:40px;color:red;font-weight:bold;background-color:yellow;clear:right"/></br></h2>
			<?php					
					echo "</td>";
					echo "</tr>";
				echo "</table>";	//========================END THE TABLE HERE=============================
			?>	
			
			<?//================THE SUBMIT BUTTON=========================	?>
			<b><input type="submit" name="ComponentSetupAssign" value="GO TO PCB SERIAL PANEL ASSIGN" style="font-size: 16pt;width:420px; height:50px;float:center;clear:both;font-weight:bold" /></b>		
			<br>
			<br>
			<b><input type="submit" name="ComponentSetupAssign" value="VIEW THE SET-UP TABLE" style="font-size: 16pt;width:420px; height:50px;float:center;clear:both;font-weight:bold" /></b>
			<br>
			<br>
			<b><input type="submit" name="ComponentSetupAssign" value="RESET ALL LOCATION VS MODEL" style="font-size: 16pt;width:420px; height:50px;float:center;clear:both;font-weight:bold" /></b>
			</div>			
		</form>
		</center>

	<?php			
		echo "</b><p align=\"right\"><span style=\"font-size:16;background-color:Yellow;\">";
		echo "<font color=\"blue\">";
		echo "Note: select SMT line, PCB model";
		echo "<br>";
		echo " and PCB side are going to running!";
		echo "</font></span></p>";
	?>	

</body>
</html>