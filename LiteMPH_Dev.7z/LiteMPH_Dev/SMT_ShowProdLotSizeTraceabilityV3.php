<?php	
	// session_start();
	// $q=$_REQUEST["q"];
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	$myDB = $_SESSION['ServerDB'];
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbhandle = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
		or die("Couldn't connect to SQL Server on $myServer");

	//separate the value of $q: linename_pcbmodel	
	// $line= trim(strtok($q, "_"));
	// $pcbmodel=trim(strtok("_"));
	
	// $SMTSetupSheetLogName = $q;

	//declare the SQL statement that will query the database
	$query = "SELECT TOP(1) * FROM [dbo].[v_SMTMachineMonitoring] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
	
	$_SESSION['iQUERRY'] = $query;
	//execute the SQL query and return records
	$result = sqlsrv_query($dbhandle,$query);		
	
	$getIDSMTSetupSheetLog = 0;
	while ($row = sqlsrv_fetch_array($result)) {		
		$getIDSMTSetupSheetLog = (int)$row['ProdLotSizeID'];
	}
	
	// if ($getIDSMTSetupSheetLog > 1){
		// $_SESSION['IDSMTSetupSheetLog'] = $getIDSMTSetupSheetLog;
		// echo "<h5>";
		// echo "SMT PRODUCTION LOT SIZE STATUS";
		// echo "</h5>";
		echo "<html><body>";
?>			
			<table style="text-align:left; border:1px solid black; margin-left:-15px; margin-right:auto; font-size:15pt">
<?php
		// echo "<tr>
				// <th>No.</th>
				// <th>ProdLotSizeID</th>
				// <th>Model</th>
				// <th>IoTCounterQty</th>
			// </tr>";
			
		//declare the SQL statement that will query the database
		$query = "SELECT TOP(1) * FROM [dbo].[v_SMTMachineMonitoring] WHERE [ProdLotSizeID] = '" . $_SESSION['iSMTPRODLOTSIZEID'] . "'";
		
		$_SESSION['iQUERRY'] = $query;
		//execute the SQL query and return records
		$result = sqlsrv_query($dbhandle,$query);
		
		$rowCount = 0;
		while ($row = sqlsrv_fetch_array($result)) {
			// $dtProdLotSizeTime = $row['ProdLotSizeTime']->format('Y-m-d H:i:s');
			$_SESSION['iSMTPRODLOTSIZEQTY'] = (int)($row['ProdLotSizeQty']);
			$_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] = (int)($row['IoTCounterQty']);
			
			$getIoTControlStatus = (int)$row['IoTControlStatus'];
			if ($getIoTControlStatus == 0){
				$getIoTControlStatus = "0: Opened";
			}
			else{
				$getIoTControlStatus = "1: Closed";
			}
			$rowCount = $rowCount + 1;
			echo "<tr>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $rowCount . "</td>";
				echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='#FF6347' color='white'>" . "LOT SIZE ID: " . "</td>";
				echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['ProdLotSizeID']) . "</td>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['IoTCounterQty']) . "</td>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $getIoTControlStatus . "</td>";
			echo "</tr>";	
			
			echo "<tr>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $rowCount . "</td>";
				echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='#FF6347' color='white'>" . "MODEL: " . "</td>";
				echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['ProdLotSizeModel']) . "</td>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['IoTCounterQty']) . "</td>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $getIoTControlStatus . "</td>";
			echo "</tr>";	
			
			echo "<tr>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $rowCount . "</td>";
				echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='#FF6347' color='white'>" . "COUNT QTY: " . "</td>";
				// echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['ProdLotSizeModel']) . "</td>";
				echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $_SESSION['iSMTPRODLOTSIZECOMPLETEQTY'] . "/" . $_SESSION['iSMTPRODLOTSIZEQTY'] . "</td>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $getIoTControlStatus . "</td>";
			echo "</tr>";	
			
			echo "<tr>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $rowCount . "</td>";
				echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='FF6347' color='white'>" . "IoT STATUS: " . "</td>";
				// echo "<td style=\"text-align:left;   font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . trim($row['ProdLotSizeModel']) . "</td>";
				// echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . (int)($row['IoTCounterQty']) . "</td>";
				echo "<td style=\"text-align:center; font-weight:bold; border:1px solid black\" bgcolor='green' color='white'>" . $getIoTControlStatus . "</td>";
			echo "</tr>";	
		}
?>
			</table>
<?php
			echo "</body></html>";
		
		
	// }
	
	
	sqlsrv_close($dbhandle);
?>
