<?php
	@session_start();	
	
	$myServer = $_SESSION['ServerInstanceName'];
	$myUser = $_SESSION['ServerUserName'];
	$myPass = $_SESSION['ServerPassword'];
	
	$myDB = $_SESSION['ServerDB'];
	
		
	$_SESSION['IDSMTSETUPSHEET'] = 0;
	
	$connectionInfo = array("UID" => $myUser, "PWD" => $myPass, "Database"=>$myDB);
	//connection to the database
	$dbIDSMTSETUPSHEET = sqlsrv_connect($_SESSION['ServerInstanceName'],$connectionInfo)
				or die("Couldn't connect to SQL Server on $myServer");

	// the following code segment will get the ID for reel component
	$getIDSMTSETUPSHEET = "";	// initial the REELID
	

	$procedure_params = array(
		array(&$_SESSION['FILENAME'], SQLSRV_PARAM_IN),
		array(&$_SESSION['IDSMTSetupSheet'], SQLSRV_PARAM_OUT)
	);
	
	$sql = "{EXEC [dbo].[speleanAIms_etMasterList] @iSMTSetupSheetName = ?, @result = ?}";
	$stmt = sqlsrv_prepare($dbIDSMTSETUPSHEET, $sql, $procedure_params);
	
	sqlsrv_execute($stmt);
	// if (!sqlsrv_execute($stmt)) {
		// echo "Your code is fail!";
		// die;
	// }
	// else{
		// while($row = sqlsrv_fetch($stmt)){
			// $_SESSION['IDSMTSETUPSHEET'] = $row['Result'];
		// }
	// }
	
	while($row = sqlsrv_fetch($stmt)){
		$_SESSION['IDSMTSETUPSHEET'] = $row['Result'];
	}
	
	// sqlsrv_execute($stmt);
	

	sqlsrv_close($dbIDSMTSETUPSHEET);
?>